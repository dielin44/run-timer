"""Rebuild v3.19.1 from the intact signed 3.18.5 APK and Java route sources."""
from pathlib import Path
import argparse,hashlib,io,json,os,shutil,struct,subprocess,sys,zipfile,zlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import apk_tools as apk
BASE_SHA='c8a4fe852f50f66bb1357c3de923c423dea412d07d99fb9b9026bee33d4b19d0'
def run(args,**kw):
 r=subprocess.run([str(x) for x in args],check=True,capture_output=True,text=True,**kw)
 if r.stdout.strip():print(r.stdout.strip(),flush=True)
 return r.stdout
def manifest(data):
 b=bytearray(data);pool=apk.manifest_pool(b);strings=[x[0] for x in pool];p=8;edits=0
 while p<len(b):
  kind,header,size=struct.unpack_from('<HHI',b,p)
  if kind==0x102:
   ext=p+header;tag=strings[apk.u32(b,ext+4)];start,stride,n=struct.unpack_from('<HHH',b,ext+8)
   for i in range(n):
    at=ext+start+i*stride;name=strings[apk.u32(b,at+4)];typ,value=b[at+15],apk.u32(b,at+16)
    if tag=='manifest' and name=='versionCode':assert typ==16 and value==61;struct.pack_into('<I',b,at+16,63);edits+=1
    elif tag=='manifest' and name=='versionName':
     old,q,nbytes,encoding=pool[value];assert old=='3.18.5';new='3.19.1'.encode(encoding);assert len(new)==nbytes;b[q:q+nbytes]=new;edits+=1
  p+=size
 assert edits==2 and len(b)==len(data);return bytes(b)
def main(args):
 base=Path(args.base).read_bytes();assert hashlib.sha256(base).hexdigest()==BASE_SHA;assert apk.verify_v2(base)==[apk.CERT_SHA256]
 tool=Path(args.tool_dir).resolve();deps=json.loads((ROOT/'DEPENDENCIES.json').read_text())['jars']
 for d in deps:assert hashlib.sha256((tool/d['name']).read_bytes()).hexdigest()==d['sha256'],d['name']
 smali=[d for d in deps if d['name'] not in ['android-35.jar','r8-4.0.48.jar']];cp=':'.join(str(tool/d['name']) for d in sorted(smali,key=lambda d:'fat' in d['name']))
 with zipfile.ZipFile(io.BytesIO(base)) as z:(ROOT/'base.dex').write_bytes(z.read('classes.dex'));new_manifest=manifest(z.read('AndroidManifest.xml'))
 names='Ltw/com/deliverylaw/timer/MainActivity;,Ltw/com/deliverylaw/timer/TrackingService;,Ltw/com/deliverylaw/timer/OrderGrabMerchant;,Ltw/com/deliverylaw/timer/OrderGrabParser;'
 run(['java','-cp',cp,'org.jf.baksmali.Main','disassemble','--classes',names,'-o',ROOT/'original-smali',ROOT/'base.dex'])
 run([sys.executable,ROOT/'patch_routes.py'])
 run(['java',ROOT/'CompileRoutes.java',tool/'android-35.jar',ROOT/'classes',ROOT/'src',ROOT/'stubs'])
 run(['java','-cp',cp,'org.jf.smali.Main','assemble','--api','24','-o',ROOT/'hooks.dex',ROOT/'patched-smali'])
 with zipfile.ZipFile(ROOT/'routes.jar','w') as jar:
  for f in sorted((ROOT/'classes').rglob('Route*.class')):jar.write(f,f.relative_to(ROOT/'classes'))
 (ROOT/'new-dex').mkdir(exist_ok=True)
 run(['java','-cp',tool/'r8-4.0.48.jar','com.android.tools.r8.D8','--min-api','24','--lib',tool/'android-35.jar','--output',ROOT/'new-dex',ROOT/'routes.jar'])
 preservation=run(['java','-cp',cp,ROOT/'MergeRoutes.java',ROOT/'base.dex',ROOT/'hooks.dex',ROOT/'new-dex/classes.dex',ROOT/'classes-fixed.dex'])
 (ROOT/'preservation.txt').write_text(preservation)
 dex=(ROOT/'classes-fixed.dex').read_bytes();assert dex[12:32]==hashlib.sha1(dex[32:]).digest();assert apk.u32(dex,8)==zlib.adler32(dex[12:])&0xffffffff
 assert apk.u32(dex,88)<65536 and apk.u32(dex,64)<65536
 unsigned=apk.rebuild_zip(base,{'classes.dex':dex,'AndroidManifest.xml':new_manifest});key,cert=apk.export_key(args.keystore,args.signing_info);signed=apk.sign_v2(unsigned,key,cert);assert apk.verify_v2(signed)==[apk.CERT_SHA256]
 bad=bytearray(signed);bad[50]^=1
 try:apk.verify_v2(bad)
 except AssertionError:pass
 else:raise AssertionError('Tampered APK accepted')
 resources=0
 with zipfile.ZipFile(io.BytesIO(base)) as before,zipfile.ZipFile(io.BytesIO(signed)) as after:
  assert after.testzip() is None
  for item in after.infolist():
   if item.filename not in ('classes.dex','AndroidManifest.xml'):assert before.read(item.filename)==after.read(item.filename);resources+=1
   if item.compress_type==0:
    n,e=struct.unpack_from('<HH',signed,item.header_offset+26);offset=item.header_offset+30+n+e;assert offset%(16384 if item.filename.endswith('.so') else 4)==0
 out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(signed)
 report={'version':'3.19.1','version_code':63,'package':'tw.com.deliverylaw.timer','base_sha256':BASE_SHA,'sha256':hashlib.sha256(signed).hexdigest(),'size_bytes':len(signed),'certificate_sha256':apk.CERT_SHA256,'signature_v2_verified':True,'tampering_rejected':True,'zip_integrity':True,'unchanged_noncode_entries':resources,'native_zip_alignment_16kb':True,'preservation':preservation.strip(),'physical_device_tested':False,'emulator_tested':False}
 Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--tool-dir',required=True);p.add_argument('--keystore',required=True);p.add_argument('--signing-info',required=True);p.add_argument('--output',required=True);p.add_argument('--report',required=True);main(p.parse_args())
