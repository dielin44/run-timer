import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.dexbacked.*;
import org.jf.dexlib2.writer.pool.*;
import org.jf.dexlib2.writer.io.*;
import org.jf.baksmali.*;
import org.jf.baksmali.Adaptors.*;
import org.jf.baksmali.formatter.*;
class MergeRoutes {
 static final String P="Ltw/com/deliverylaw/timer/";
 static final Map<String,Set<String>> EDIT=Map.of(P+"MainActivity;",Set.of("buildScreen","saveState(Ljava/lang/String;)Z","toggleGpsMonitoring","onRequestPermissionsResult","createOrderCard","orderStoreLabel","lambda$showOrderStoreForm$10$tw-com-deliverylaw-timer-MainActivity","showMiniMapSettings"),P+"TrackingService;",Set.of("onLocationChanged","onDestroy","onProviderDisabled","onStartCommand","notification"),P+"OrderGrabMerchant;",Set.of("find"),P+"OrderGrabParser;",Set.of("parse","parseRegion"));
 static String dump(ClassDef c)throws Exception {var s=new StringWriter();var w=new BaksmaliWriter(s);new ClassDefinition(new BaksmaliOptions(),c).writeTo(w);w.flush();return s.toString();}
 static String normalize(ClassDef c)throws Exception{return dump(c).replaceAll("(?m)^(\\.field [^\\n]+) = (?:false|null|0x0|0x0L|0\\.0f|0\\.0)$","$1");}
 static Map<String,String> methods(String s){Map<String,String> out=new TreeMap<>();var m=Pattern.compile("(?ms)^\\.method ([^\\n]+)\\n.*?^\\.end method").matcher(s);while(m.find())out.put(m.group(1),m.group());return out;}
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);}
 public static void main(String[] a)throws Exception{
  var base=new DexBackedDexFile(null,Files.readAllBytes(Path.of(a[0])));var hooks=new DexBackedDexFile(base.getOpcodes(),Files.readAllBytes(Path.of(a[1])));var feature=new DexBackedDexFile(base.getOpcodes(),Files.readAllBytes(Path.of(a[2])));
  Map<String,ClassDef> changed=new TreeMap<>();for(var c:hooks.getClasses())changed.put(c.getType(),c);check(changed.keySet().equals(EDIT.keySet()),"Unexpected hooked classes");
  var pool=new DexPool(base.getOpcodes());Set<String> original=new HashSet<>();int count=0;for(var c:base.getClasses()){original.add(c.getType());pool.internClass(changed.getOrDefault(c.getType(),c));}
  for(var c:feature.getClasses()){check(c.getType().startsWith(P+"Route"),"Unexpected feature class "+c.getType());check(!original.contains(c.getType()),"Feature overwrites existing class");pool.internClass(c);count++;}
  var output=new FileDataStore(new File(a[3]));try{pool.writeTo(output);}finally{output.close();}
  var result=new DexBackedDexFile(base.getOpcodes(),Files.readAllBytes(Path.of(a[3])));Map<String,ClassDef> after=new HashMap<>();for(var c:result.getClasses())after.put(c.getType(),c);check(after.size()==original.size()+count,"Class count");int untouched=0,methods=0,edited=0;
  for(var c:base.getClasses()){var actual=after.get(c.getType());if(!EDIT.containsKey(c.getType())){check(normalize(c).equals(normalize(actual)),"Unrelated class changed "+c.getType());untouched++;}else{var before=methods(dump(c));var last=methods(dump(actual));check(before.keySet().equals(last.keySet()),"Existing method set changed");for(var e:before.entrySet()){String full=e.getKey().replaceFirst("^.* ",""),name=full.substring(0,full.indexOf('('));boolean expected=EDIT.get(c.getType()).contains(name)||EDIT.get(c.getType()).contains(full);if(expected){check(!e.getValue().equals(last.get(e.getKey())),"Missing hook "+full);edited++;}else{check(e.getValue().equals(last.get(e.getKey())),"Unrelated method changed "+full);methods++;}}}}
  check(edited==16,"Hook count "+edited);System.out.println("PASS: "+untouched+" unrelated classes and "+methods+" unrelated methods unchanged; "+edited+" changed methods; "+count+" added feature classes");
 }
}
