package tw.com.deliverylaw.timer;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.*;
import android.location.*;
import android.os.*;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;

/** Independent local route database. Never changes financial records or mileage. */
public final class RouteTrace {
  static final ExecutorService WORK=Executors.newSingleThreadExecutor();
  static final Handler MAIN=new Handler(Looper.getMainLooper());
  static volatile String error="";
  static volatile long lastFix;
  private static Database database;
  private static boolean active;
  static final String PREFS="runlion_route_trace";
  static SharedPreferences prefs(Context c) {return c.getApplicationContext().getSharedPreferences(PREFS,0);}
  public static boolean enabled(Context c) {return prefs(c).getBoolean("enabled",false);}
  static boolean permitted(Context c) {return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;}
  static synchronized Database db(Context c) {if(database==null)database=new Database(c.getApplicationContext());return database;}
  static final class Database extends SQLiteOpenHelper {
    RouteCore.Filter filter;
    Database(Context c) {super(c,"runlion_routes.db",null,1);}
    public void onCreate(SQLiteDatabase d) {
      d.execSQL("CREATE TABLE points(id INTEGER PRIMARY KEY,t INTEGER NOT NULL,e INTEGER NOT NULL,lat REAL NOT NULL,lon REAL NOT NULL,acc REAL NOT NULL,seg INTEGER NOT NULL)");
      d.execSQL("CREATE INDEX points_time ON points(t)");
      d.execSQL("CREATE TABLE route_orders(k TEXT PRIMARY KEY,s INTEGER NOT NULL,p INTEGER NOT NULL,f INTEGER NOT NULL,c INTEGER NOT NULL,n TEXT NOT NULL,r TEXT NOT NULL,store TEXT NOT NULL,platform TEXT NOT NULL,seq INTEGER NOT NULL)");
      d.execSQL("CREATE INDEX orders_time ON route_orders(s,f)");
    }
    public void onUpgrade(SQLiteDatabase d,int old,int n) {throw new IllegalStateException("Unsupported route database; retained original");}
    RouteCore.Filter filter() {
      if(filter==null){long s=1;try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(MAX(seg),0)+1 FROM points",null)){if(c.moveToFirst())s=c.getLong(0);}filter=new RouteCore.Filter(s);}
      return filter;
    }
  }
  public static void record(Context context,Location location) {
    if(location==null||!enabled(context)||!SpeedMonitorStore.gpsEnabled(context))return;
    final Context c=context.getApplicationContext();
    final long wall=System.currentTimeMillis(),now=SystemClock.elapsedRealtime(),e=location.getElapsedRealtimeNanos()/1000000;
    final double lat=location.getLatitude(),lon=location.getLongitude();
    final float acc=location.hasAccuracy()?location.getAccuracy():999;
    WORK.execute(new Runnable(){public void run(){
      if(!enabled(c)||!SpeedMonitorStore.gpsEnabled(c)){resetInside(c);return;}
      try {
        Database helper=db(c);
        RouteCore.Point p=helper.filter().accept(wall,now,e,lat,lon,acc);
        if(p==null)return;
        ContentValues v=new ContentValues();v.put("t",p.time);v.put("e",p.elapsed);v.put("lat",p.lat);v.put("lon",p.lon);v.put("acc",p.accuracy);v.put("seg",p.segment);
        helper.getWritableDatabase().insertOrThrow("points",null,v);
        lastFix=p.time;error="";active=true;
      } catch(RuntimeException ex){error="軌跡無法儲存，請確認手機空間";resetInside(c);}
    }});
  }
  private static void resetInside(Context c) {if(database!=null&&database.filter!=null)database.filter.reset();active=false;}
  public static void gap(Context context) {final Context c=context.getApplicationContext();WORK.execute(new Runnable(){public void run(){resetInside(c);}});}
  public static void sync(Context context,String payload) {
    if(payload==null||payload.length()==0)return;
    final Context c=context.getApplicationContext();final String json=payload;
    WORK.execute(new Runnable(){public void run(){
      try {
        LinkedHashMap<String,RouteCore.Order> orders=parseOrders(new JSONObject(json));
        SQLiteDatabase d=db(c).getWritableDatabase();d.beginTransaction();
        try {
          // Close an orphaned active interval after state reset; never classify future idle travel as an old order.
          ArrayList<String> orphan=new ArrayList<>();
          try(Cursor q=d.rawQuery("SELECT k FROM route_orders WHERE f=0",null)){while(q.moveToNext())if(!orders.containsKey(q.getString(0)))orphan.add(q.getString(0));}
          for(String key:orphan){ContentValues v=new ContentValues();v.put("f",System.currentTimeMillis());d.update("route_orders",v,"k=?",new String[]{key});}
          for(RouteCore.Order o:orders.values()) {
            ContentValues v=new ContentValues();v.put("k",o.key);v.put("s",o.start);v.put("p",o.pickup);v.put("f",o.end);v.put("c",o.cancelled?1:0);v.put("n",o.number);v.put("r",o.reference);v.put("store",o.name);v.put("platform",o.platform);v.put("seq",o.sequence);
            if(d.insertWithOnConflict("route_orders",null,v,SQLiteDatabase.CONFLICT_REPLACE)<0)throw new SQLiteException("Route order was not saved");
          }
          d.setTransactionSuccessful();
        }finally{d.endTransaction();}
      } catch(Exception ex){error="訂單路線資料暫時無法更新";}
    }});
  }
  static LinkedHashMap<String,RouteCore.Order> parseOrders(JSONObject root) throws JSONException {
    LinkedHashMap<String,RouteCore.Order> out=new LinkedHashMap<>();
    JSONObject history=root.optJSONObject("history");
    if(history!=null){Iterator<String> days=history.keys();while(days.hasNext()){JSONArray trips=history.optJSONArray(days.next());if(trips!=null)for(int i=0;i<trips.length();i++){JSONObject t=trips.optJSONObject(i);if(t!=null)add(out,t.optJSONArray("orderResults"),true);}}}
    add(out,root.optJSONArray("sessionCompleted"),true);
    JSONArray trips=root.optJSONArray("activeTrips");if(trips!=null)for(int i=0;i<trips.length();i++){JSONObject t=trips.optJSONObject(i);if(t!=null)add(out,t.optJSONArray("completed"),true);}
    add(out,root.optJSONArray("orders"),false);
    return out;
  }
  private static void add(Map<String,RouteCore.Order> out,JSONArray list,boolean completed) {
    if(list==null)return;
    for(int i=0;i<list.length();i++){
      JSONObject j=list.optJSONObject(i);if(j==null)continue;
      if(!completed&&!j.optBoolean("active",false)&&!j.optBoolean("finished",false))continue;
      RouteCore.Order o=new RouteCore.Order();o.start=j.optLong("startedAt");o.sequence=j.optInt("sequence");
      if(o.start<=0||o.sequence<=0)continue;
      // startedAt is persisted for both slot and completed result, unlike a reusable card number.
      o.key=o.start+":"+o.sequence;o.pickup=j.optLong("pickupAt");o.end=j.optLong("completedAt");
      o.cancelled=j.optBoolean("cancelled");o.number=j.optString("orderNumber","");o.reference=j.optString("platformReference","");o.name=j.optString("storeName","");o.platform=j.optString("platform","");
      RouteCore.Order prior=out.get(o.key);
      if(prior!=null&&prior.end>0&&o.end==0)continue;
      out.put(o.key,o);
    }
  }
  static void syncCurrent(Context c) {try{RunStateStore.Snapshot s=RunStateStore.get(c).read();if(s!=null)sync(c,s.payload);}catch(RuntimeException ex){error="訂單資料無法讀取，請先確認跑單紀錄";}}
  static void setEnabled(Activity a,boolean value) {
    if(value&&!permitted(a)) {a.requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},4186);return;}
    if(!prefs(a).edit().putBoolean("enabled",value).commit()){error="軌跡開關無法儲存";return;}
    gap(a);error="";
    if(value){
      if(!SpeedMonitorStore.setGpsEnabled(a,true)){prefs(a).edit().putBoolean("enabled",false).commit();error="GPS 開關無法儲存";return;}
      syncCurrent(a);
      try{Intent i=new Intent().setClassName(a,a.getPackageName()+".TrackingService").setAction("tw.com.deliverylaw.timer.REFRESH_GPS");if(Build.VERSION.SDK_INT>=26)a.startForegroundService(i);else a.startService(i);}
      catch(RuntimeException ex){prefs(a).edit().putBoolean("enabled",false).commit();error="無法啟動 GPS 記錄，請重新開啟";}
    }
  }
  public static void permissionResult(Activity a,int code) {
    if(code!=4186)return;
    if(permitted(a))setEnabled(a,true);else error="需要精確位置權限才能記錄路線；可再次開啟軌跡設定";
  }
  static String status(Context c) {
    if(error.length()>0)return error;
    if(!enabled(c))return "軌跡記錄已關閉";
    if(!SpeedMonitorStore.gpsEnabled(c))return "已暫停：上方 GPS 已關閉";
    if(!permitted(c))return "已暫停：需要精確位置權限";
    LocationManager lm=(LocationManager)c.getSystemService(Context.LOCATION_SERVICE);
    try{if(lm==null||!lm.isProviderEnabled(LocationManager.GPS_PROVIDER))return "已暫停：手機定位未開啟";}catch(RuntimeException ex){return "等待手機定位";}
    long age=System.currentTimeMillis()-lastFix;
    if(!active||age>60000||age<0)return "等待新的 GPS 定位";
    return "記錄中 · 訂單與未接單路線皆保留";
  }
  public static String notificationLine(Context c,String base) {return enabled(c)?base+" · "+status(c):base;}
  static final class Data {
    List<RouteCore.Point> points=new ArrayList<>();
    List<RouteCore.Order> orders=new ArrayList<>();
    List<Integer> phases=new ArrayList<>();
    List<Boolean> links=new ArrayList<>();
    double meters;long from,to;String message="";
  }
  interface Callback {void done(Data d);}
  static void load(Context context,final long from,final long to,final String selected,final boolean whole,final Callback cb) {
    final Context c=context.getApplicationContext();
    WORK.execute(new Runnable(){public void run(){final Data result=new Data();result.from=from;result.to=to;
      try {
        SQLiteDatabase d=db(c).getReadableDatabase();List<RouteCore.Order> all=new ArrayList<>();RouteCore.Order chosen=null;
        try(Cursor q=d.rawQuery("SELECT k,s,p,f,c,n,r,store,platform,seq FROM route_orders ORDER BY s,seq",null)){
          while(q.moveToNext()){RouteCore.Order o=new RouteCore.Order();o.key=q.getString(0);o.start=q.getLong(1);o.pickup=q.getLong(2);o.end=q.getLong(3);o.cancelled=q.getInt(4)!=0;o.number=q.getString(5);o.reference=q.getString(6);o.name=q.getString(7);o.platform=q.getString(8);o.sequence=q.getInt(9);all.add(o);if(o.key.equals(selected))chosen=o;}
        }
        long lo=from,hi=to;
        if(whole&&chosen!=null){lo=chosen.start;hi=chosen.end>0?chosen.end+1:System.currentTimeMillis()+1;}
        result.from=lo;result.to=hi;
        long optionFrom=RouteCore.dayStart(from,TimeZone.getDefault()),optionTo=Math.max(to,RouteCore.nextDay(optionFrom,TimeZone.getDefault()));
        for(RouteCore.Order o:all)if(o.key.equals(selected)||(o.start<optionTo&&(o.end==0||o.end>=optionFrom)))result.orders.add(o);
        List<RouteCore.Point> raw=new ArrayList<>();
        try(Cursor q=d.rawQuery("SELECT t,e,lat,lon,acc,seg FROM points WHERE t>=? AND t<? ORDER BY id",new String[]{Long.toString(lo),Long.toString(hi)})){
          while(q.moveToNext())raw.add(new RouteCore.Point(q.getLong(0),q.getLong(1),q.getDouble(2),q.getDouble(3),q.getFloat(4),q.getLong(5)));
        }
        RouteCore.Point prev=null;int prevPhase=-2;boolean prevKept=false;
        for(RouteCore.Point p:raw){int phase=RouteCore.phase(p.time,all,chosen);
          boolean keep=selected.equals("idle")?phase==0:selected.length()==0?true:chosen!=null&&phase>=1;
          if(keep){boolean link=prev!=null&&prevKept&&RouteCore.connect(prev,p)&&prevPhase==phase;
            result.points.add(p);result.phases.add(phase);result.links.add(link);if(link)result.meters+=RouteCore.meters(prev.lat,prev.lon,p.lat,p.lon);
          }
          prev=p;prevPhase=phase;prevKept=keep;
        }
        if(result.points.isEmpty())result.message="這個區段沒有已記錄的 GPS 軌跡\n開啟記錄後才會保留路線";
      }catch(RuntimeException ex){result.message="軌跡暫時無法讀取，原資料保留";}
      MAIN.post(new Runnable(){public void run(){cb.done(result);}});
    }});
  }
  static void delete(Context context,final long from,final long to,final Runnable done) {
    final Context c=context.getApplicationContext();WORK.execute(new Runnable(){public void run(){try{
      SQLiteDatabase d=db(c).getWritableDatabase();d.beginTransaction();
      try{
        d.delete("points","t>=? AND t<?",new String[]{Long.toString(from),Long.toString(to)});
        long shift=1;try(Cursor q=d.rawQuery("SELECT COALESCE(MAX(seg),0)+1 FROM points",null)){if(q.moveToFirst())shift=q.getLong(0);}
        d.execSQL("UPDATE points SET seg=seg+? WHERE t>=?",new Object[]{shift,to});d.setTransactionSuccessful();
      }finally{d.endTransaction();}
      database.filter=null;active=false;error="";
    }catch(RuntimeException ex){error="軌跡刪除失敗";}MAIN.post(done);}});
  }
  private RouteTrace() {}
}
