package tw.com.deliverylaw.timer;

import java.util.*;

/** GPS observations only. No road snapping or inferred travel across missing data. */
public final class RouteCore {
  public static final class Point {
    public long time, elapsed, segment;
    public double lat, lon;
    public float accuracy;
    public Point(long t,long e,double a,double o,float ac,long s) {time=t;elapsed=e;lat=a;lon=o;accuracy=ac;segment=s;}
  }
  public static final class Order {
    public String key="",number="",reference="",name="",platform="";
    public long start,pickup,end;
    public int sequence;
    public boolean cancelled;
    public boolean contains(long t) {return start>0 && t>=start && (end==0 || t<=end);}
    public int phase(long t) {return !contains(t)?-1:pickup>0 && t>=pickup?2:1;}
    public String label() {
      String n=number.length()==0?"第"+sequence+"單":number;
      if (reference.length()>0 && platform.equals("熊貓")) n="#"+reference.replaceFirst("^#+", "")+"，"+n;
      return (name.length()==0?"未填店名":name)+" · "+n+(cancelled?"（取消）":"");
    }
  }
  public static final class Filter {
    private Point previous;
    private long segment;
    public Filter(long s) {segment=s;}
    public void reset() {previous=null;segment++;}
    public Point accept(long wall,long nowElapsed,long fixElapsed,double lat,double lon,float accuracy) {
      if (!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>85.05112878||Math.abs(lon)>180
          || !Float.isFinite(accuracy)||accuracy<=0||accuracy>75||fixElapsed<=0
          ||nowElapsed-fixElapsed>15000||fixElapsed-nowElapsed>2000) return null;
      long t=wall-(nowElapsed-fixElapsed);
      if (previous!=null) {
        long dt=fixElapsed-previous.elapsed;
        if (dt<=0) return null;
        boolean gap=dt>60000 || Math.abs((t-previous.time)-dt)>5000;
        double distance=meters(previous.lat,previous.lon,lat,lon);
        if (!gap && distance>Math.max(100,dt*0.060+previous.accuracy+accuracy)) return null;
        if (!gap && dt<1000) return null;
        if (!gap && distance<2 && dt<30000) return null;
        if (gap) segment++;
      }
      previous=new Point(t,fixElapsed,lat,lon,accuracy,segment);
      return previous;
    }
  }
  public static int phase(long t,List<Order> orders,Order selected) {
    if (selected!=null) return selected.phase(t);
    int phase=0;
    for (Order o:orders) if (o.contains(t)) {int p=o.phase(t);if(p==2)return 2;phase=1;}
    return phase;
  }
  public static boolean connect(Point a,Point b) {
    return a.segment==b.segment && b.elapsed>a.elapsed && b.elapsed-a.elapsed<=60000
      && b.time>a.time && Math.abs((b.time-a.time)-(b.elapsed-a.elapsed))<=5000;
  }
  public static double meters(double a,double o,double b,double p) {
    double d1=Math.toRadians(b-a),d2=Math.toRadians(p-o);
    double h=Math.sin(d1/2)*Math.sin(d1/2)+Math.cos(Math.toRadians(a))*Math.cos(Math.toRadians(b))*Math.sin(d2/2)*Math.sin(d2/2);
    return 6371008.8*2*Math.atan2(Math.sqrt(h),Math.sqrt(Math.max(0,1-h)));
  }
  public static long dayStart(long time,TimeZone tz) {
    Calendar c=Calendar.getInstance(tz);c.setTimeInMillis(time);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);return c.getTimeInMillis();
  }
  public static long nextDay(long day,TimeZone tz) {Calendar c=Calendar.getInstance(tz);c.setTimeInMillis(day);c.add(Calendar.DATE,1);return c.getTimeInMillis();}
  private RouteCore() {}
}
