package tw.com.deliverylaw.timer;
import java.util.*;
import java.util.regex.Pattern;
/** Only leading platform chrome is removed. Real name, branch and internal words remain. */
public final class RouteMerchantText {
  static final Pattern PREFIX=Pattern.compile("^(?:(?:偏好設定|無法離線)[\\s　|｜:：·•\\-]*)+");
  public static String clean(String name){if(name==null)return "";return PREFIX.matcher(name.trim()).replaceFirst("").trim();}
  public static String label(String name,String note){String n=clean(name),t=note==null?"":note;return n.isEmpty()?t:n+(t.isEmpty()?"":"｜"+t);}
  public static OrderGrabMerchant.Selection selection(OrderGrabMerchant.Selection s){
    if(s==null)return null;
    LinkedHashSet<String> list=new LinkedHashSet<>();if(s.candidates!=null)for(String v:s.candidates){String n=clean(v);if(!n.isEmpty())list.add(n);}
    return new OrderGrabMerchant.Selection(clean(s.storeName),new ArrayList<String>(list));
  }
  public static OrderGrabParser.Result result(OrderGrabParser.Result r){return r==null?null:new OrderGrabParser.Result(r.platform,clean(r.storeName),r.reference,r.numbers);}
  private RouteMerchantText(){}
}
