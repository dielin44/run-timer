package tw.com.deliverylaw.timer;

import android.content.Context;
import android.graphics.*;
import android.view.*;
import android.widget.Toast;
import java.util.*;

/** OSM basemap uses the existing visible-tile cache. Route coordinates stay local. */
final class RouteMapView extends View {
  static final int PICKUP=0xffffb458,DELIVERY=0xff35d4f4,IDLE=0xffbd9aff;
  final Paint paint=new Paint(3);final MapTileCache tiles;final ScaleGestureDetector scale;
  RouteTrace.Data data=new RouteTrace.Data();double cx,cy;int zoom=14;boolean ready=false,fitPending=false,detailed;
  float lastX,lastY,downX,downY;boolean moved;
  final Runnable redraw=new Runnable(){public void run(){if(isAttachedToWindow())invalidate();}};
  RouteMapView(Context c){super(c);tiles=MapTileCache.get(c);detailed=RouteTrace.prefs(c).getBoolean(RouteMapStyle.KEY,RouteMapStyle.DEFAULT);setBackgroundColor(0xff0c1a2b);setContentDescription("GPS 路線地圖，可拖曳與雙指縮放");setFocusable(true);
    scale=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){float factor=1;public boolean onScaleBegin(ScaleGestureDetector d){factor=1;return true;}public boolean onScale(ScaleGestureDetector d){factor*=d.getScaleFactor();if(factor>1.3f){zoom(1);factor=1;}else if(factor<.77f){zoom(-1);factor=1;}return true;}});
  }
  static double x(double lon){return (lon+180)/360;}
  static double y(double lat){double s=Math.sin(Math.toRadians(Math.max(-85.05112878,Math.min(85.05112878,lat))));return .5-Math.log((1+s)/(1-s))/(4*Math.PI);}
  int dp(float n){return RouteTraceUi.dp(getContext(),n);}
  void setData(RouteTrace.Data d){data=d;fitPending=true;invalidate();}
  void setDetailed(boolean value){detailed=value;RouteTrace.prefs(getContext()).edit().putBoolean(RouteMapStyle.KEY,value).apply();setContentDescription(RouteMapStyle.label(value)+"，可拖曳與雙指縮放");invalidate();}
  boolean isDetailed(){return detailed;}
  void zoom(int delta){zoom=Math.max(3,Math.min(19,zoom+delta));fitPending=false;invalidate();}
  void fit(){fitPending=true;invalidate();}
  void fitInside(){fitPending=false;if(data.points.isEmpty()){cx=x(120.683);cy=y(24.147);ready=true;return;}
    double minX=1,maxX=0,minY=1,maxY=0;for(RouteCore.Point p:data.points){double a=x(p.lon),b=y(p.lat);minX=Math.min(minX,a);maxX=Math.max(maxX,a);minY=Math.min(minY,b);maxY=Math.max(maxY,b);}cx=(minX+maxX)/2;cy=(minY+maxY)/2;
    for(zoom=19;zoom>3;zoom--){double world=256*(1<<zoom);if((maxX-minX)*world<Math.max(32,getWidth()-dp(80))&&(maxY-minY)*world<Math.max(32,getHeight()-dp(90)))break;}ready=true;
  }
  protected void onSizeChanged(int w,int h,int ow,int oh){super.onSizeChanged(w,h,ow,oh);fitPending=true;}
  float sx(RouteCore.Point p,double world){return (float)((x(p.lon)-cx)*world+getWidth()/2.0);}
  float sy(RouteCore.Point p,double world){return (float)((y(p.lat)-cy)*world+getHeight()/2.0);}
  int color(int phase){return phase==1?PICKUP:phase==2?DELIVERY:IDLE;}
  protected void onDraw(Canvas canvas){super.onDraw(canvas);if(!ready||fitPending)fitInside();int w=getWidth(),h=getHeight(),n=1<<zoom;double world=256.0*n;double left=cx*world-w/2.0,top=cy*world-h/2.0;int tx=(int)Math.floor(left/256),ty=(int)Math.floor(top/256);paint.setStyle(Paint.Style.FILL);
    if(detailed){
      for(int yy=ty;yy<=Math.floor((top+h)/256);yy++)for(int xx=tx;xx<=Math.floor((left+w)/256);xx++){
        if(yy<0||yy>=n)continue;int wrapped=((xx%n)+n)%n;Bitmap tile=tiles.tile(zoom,wrapped,yy,redraw);float px=(float)(xx*256-left),py=(float)(yy*256-top);
        if(tile!=null)canvas.drawBitmap(tile,null,new RectF(px,py,px+256,py+256),paint);else{paint.setColor(((xx+yy)&1)==0?0xff12263b:0xff162d44);canvas.drawRect(px,py,px+256,py+256,paint);}
      }
    }else{
      paint.setColor(0xff0c1a2b);canvas.drawRect(0,0,w,h,paint);paint.setColor(0xff203850);paint.setStrokeWidth(dp(1));
      for(int yy=ty;yy<=Math.floor((top+h)/256);yy++){float py=(float)(yy*256-top);canvas.drawLine(0,py,w,py,paint);}
      for(int xx=tx;xx<=Math.floor((left+w)/256);xx++){float px=(float)(xx*256-left);canvas.drawLine(px,0,px,h,paint);}
      paint.setColor(RouteTraceUi.MUTED);paint.setTextSize(dp(11));canvas.drawText("N ↑",dp(10),dp(20),paint);
    }
    paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);
    for(int pass=0;pass<2;pass++){paint.setStrokeWidth(dp(pass==0?6:3));for(int i=1;i<data.points.size();i++)if(data.links.get(i)){RouteCore.Point a=data.points.get(i-1),b=data.points.get(i);paint.setColor(pass==0?0xdd07101e:color(data.phases.get(i)));canvas.drawLine(sx(a,world),sy(a,world),sx(b,world),sy(b,world),paint);}}
    for(int i=0;i<data.points.size();i++)if(i==0||!data.links.get(i)){RouteCore.Point p=data.points.get(i);paint.setColor(color(data.phases.get(i)));canvas.drawCircle(sx(p,world),sy(p,world),dp(3),paint);}
    if(!data.points.isEmpty()){marker(canvas,data.points.get(0),"起",0xff349d78,world);marker(canvas,data.points.get(data.points.size()-1),"末",0xffc65773,world);}
    if(!data.message.isEmpty()){paint.setColor(0xe6102440);float boxH=dp(90);canvas.drawRoundRect(new RectF(dp(10),h/2f-boxH/2,w-dp(10),h/2f+boxH/2),dp(12),dp(12),paint);paint.setColor(RouteTraceUi.TEXT);paint.setTextSize(dp(13));paint.setTextAlign(Paint.Align.CENTER);String[] lines=data.message.split("\n");for(int i=0;i<lines.length;i++)canvas.drawText(lines[i],w/2f,h/2f+dp(i*22-5),paint);paint.setTextAlign(Paint.Align.LEFT);}
    paint.setColor(0xee07101e);canvas.drawRect(0,h-dp(22),w,h,paint);paint.setColor(0xffd5e4f3);paint.setTextSize(dp(10));paint.setTextAlign(Paint.Align.RIGHT);canvas.drawText(detailed?"© OpenStreetMap contributors":"簡易軌跡 · 北向上",w-dp(6),h-dp(7),paint);paint.setTextAlign(Paint.Align.LEFT);
    if(!detailed){double mpp=RouteMapStyle.metresPerPixel(cy,zoom),metres=RouteMapStyle.scaleMetres(dp(65)*mpp);float len=(float)(metres/mpp),start=dp(10),yy=h-dp(30);paint.setColor(RouteTraceUi.TEXT);paint.setStrokeWidth(dp(2));canvas.drawLine(start,yy,start+len,yy,paint);canvas.drawLine(start,yy-dp(3),start,yy+dp(3),paint);canvas.drawLine(start+len,yy-dp(3),start+len,yy+dp(3),paint);paint.setTextSize(dp(10));canvas.drawText(metres>=1000?String.format(Locale.TAIWAN,"%.1f km",metres/1000):String.format(Locale.TAIWAN,"%.0f m",metres),start,yy-dp(6),paint);}
  }
  void marker(Canvas c,RouteCore.Point p,String label,int color,double world){float x=sx(p,world),y=sy(p,world);paint.setColor(0xff07101e);c.drawCircle(x,y,dp(12),paint);paint.setColor(color);c.drawCircle(x,y,dp(10),paint);paint.setColor(Color.WHITE);paint.setTextSize(dp(11));paint.setTextAlign(Paint.Align.CENTER);c.drawText(label,x,y+dp(4),paint);paint.setTextAlign(Paint.Align.LEFT);}
  public boolean onTouchEvent(android.view.MotionEvent event){scale.onTouchEvent(event);switch(event.getActionMasked()){
    case MotionEvent.ACTION_DOWN:lastX=downX=event.getX();lastY=downY=event.getY();moved=false;getParent().requestDisallowInterceptTouchEvent(true);return true;
    case MotionEvent.ACTION_POINTER_DOWN:moved=true;return true;
    case MotionEvent.ACTION_MOVE:if(!scale.isInProgress()&&event.getPointerCount()==1){double world=256.0*(1<<zoom);cx-=(event.getX()-lastX)/world;cy-=(event.getY()-lastY)/world;cx=Math.max(0,Math.min(1,cx));cy=Math.max(0,Math.min(1,cy));fitPending=false;invalidate();}if(Math.hypot(event.getX()-downX,event.getY()-downY)>dp(6))moved=true;lastX=event.getX();lastY=event.getY();return true;
    case MotionEvent.ACTION_POINTER_UP:lastX=event.getX(event.getActionIndex()==0?1:0);lastY=event.getY(event.getActionIndex()==0?1:0);return true;
    case MotionEvent.ACTION_UP:if(!moved){performClick();inspect(event.getX(),event.getY());}getParent().requestDisallowInterceptTouchEvent(false);return true;
    case MotionEvent.ACTION_CANCEL:getParent().requestDisallowInterceptTouchEvent(false);return true;
  }return true;}
  public boolean performClick(){super.performClick();return true;}
  void inspect(float x,float y){double world=256.0*(1<<zoom),best=dp(32);int nearest=-1;for(int i=0;i<data.points.size();i++){RouteCore.Point p=data.points.get(i);double d=Math.hypot(sx(p,world)-x,sy(p,world)-y);if(d<best){best=d;nearest=i;}}if(nearest>=0){RouteCore.Point p=data.points.get(nearest);int phase=data.phases.get(nearest);Toast.makeText(getContext(),RouteTraceUi.fmt(p.time,"MM/dd HH:mm:ss")+" · "+(phase==1?"取餐中":phase==2?"送餐中":"未接單")+String.format(Locale.TAIWAN,"\n%.5f, %.5f · 精度約 %.0f m",p.lat,p.lon,p.accuracy),Toast.LENGTH_SHORT).show();}}
}
