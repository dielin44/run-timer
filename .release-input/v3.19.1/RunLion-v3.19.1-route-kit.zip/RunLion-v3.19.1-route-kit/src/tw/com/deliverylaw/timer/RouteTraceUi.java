package tw.com.deliverylaw.timer;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public final class RouteTraceUi {
  static final int BG=0xff07101e,CARD=0xff102440,TEXT=0xffedf5ff,MUTED=0xff9fb8d7,BLUE=0xff40d2f2;
  static int dp(Context c,float x){return (int)(x*c.getResources().getDisplayMetrics().density+.5f);}
  static String fmt(long t,String f){return new SimpleDateFormat(f,Locale.TAIWAN).format(new Date(t));}
  static GradientDrawable bg(Context c,int color){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,16));d.setStroke(dp(c,1),0xff345679);return d;}
  static TextView text(Context c,String s,int size,int color){TextView v=new TextView(c);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
  static Button button(Context c,String s){Button b=new Button(c);b.setText(s);b.setTextColor(TEXT);b.setTextSize(14);b.setAllCaps(false);b.setMinHeight(dp(c,44));b.setMinimumHeight(dp(c,44));b.setPadding(dp(c,5),dp(c,4),dp(c,5),dp(c,4));b.setBackground(bg(c,0xff16344f));return b;}
  static LinearLayout row(Context c){LinearLayout r=new LinearLayout(c);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
  static void weighted(LinearLayout r,View v){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);p.setMargins(dp(r.getContext(),2),dp(r.getContext(),3),dp(r.getContext(),2),dp(r.getContext(),3));r.addView(v,p);}
  static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(1);return l;}
  static final class Card extends LinearLayout implements Runnable {
    final Activity activity;final Switch toggle;final TextView state;boolean updating;
    Card(Activity a){super(a);activity=a;setOrientation(1);int p=dp(a,10);setPadding(p,p,p,p);setBackground(bg(a,CARD));
      LinearLayout r=row(a);toggle=new Switch(a);toggle.setText("GPS 軌跡");toggle.setTextColor(TEXT);toggle.setTextSize(16);toggle.setThumbTintList(ColorStateList.valueOf(BLUE));toggle.setTrackTintList(ColorStateList.valueOf(0xff386377));toggle.setMinHeight(dp(a,44));
      r.addView(toggle,new LinearLayout.LayoutParams(0,-2,1));Button view=button(a,"查看路線");r.addView(view,new LinearLayout.LayoutParams(dp(a,116),-2));addView(r);state=text(a,"",12,MUTED);addView(state);refresh();
      toggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){public void onCheckedChanged(CompoundButton v,boolean checked){if(!updating){RouteTrace.setEnabled(activity,checked);refresh();}}});
      view.setOnClickListener(new View.OnClickListener(){public void onClick(View v){new Browser(activity).show();}});
    }
    void refresh(){updating=true;toggle.setChecked(RouteTrace.enabled(activity));state.setText(RouteTrace.status(activity));updating=false;}
    public void run(){if(isAttachedToWindow()){refresh();postDelayed(this,2000);}}
    protected void onAttachedToWindow(){super.onAttachedToWindow();removeCallbacks(this);post(this);}
    protected void onDetachedFromWindow(){removeCallbacks(this);super.onDetachedFromWindow();}
  }
  /** Main screen only synchronizes state. Route controls live under Map settings. */
  public static void install(Activity a,View root){
    RouteTrace.syncCurrent(a);
  }
  public static void settings(Activity a,LinearLayout column){
    Card card=new Card(a);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(a,4),0,dp(a,14));column.addView(card,0,p);
  }
  static final class Browser {
    final Activity a;final Dialog dialog;final LinearLayout root;final RouteMapView map;final TextView status,stats,legend;
    final Button date,from,to,wholeButton,detailsButton,simpleButton;final Spinner scope;final ArrayList<String> keys=new ArrayList<>();
    long day;int fromMinute=0,toMinute=1440;String selected="";boolean whole=false,binding=false,followToday=true;int generation=0;String optionStamp="";
    final Runnable ticker=new Runnable(){public void run(){if(!dialog.isShowing())return;status.setText(RouteTrace.status(a));long today=RouteCore.dayStart(System.currentTimeMillis(),TimeZone.getDefault());if(followToday&&day!=today){day=today;selected="";whole=false;optionStamp="";load();}RouteTrace.MAIN.postDelayed(this,2000);}};
    Browser(Activity activity){a=activity;day=RouteCore.dayStart(System.currentTimeMillis(),TimeZone.getDefault());dialog=new Dialog(a);dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);root=column(a);root.setBackgroundColor(BG);int p=dp(a,10);root.setPadding(p,p,p,p);
      LinearLayout title=row(a);TextView heading=text(a,"GPS 移動軌跡",19,TEXT);heading.setTypeface(null,Typeface.BOLD);title.addView(heading,new LinearLayout.LayoutParams(0,-2,1));Button close=button(a,"關閉");title.addView(close,new LinearLayout.LayoutParams(dp(a,66),-2));close.setOnClickListener(new View.OnClickListener(){public void onClick(View v){dialog.dismiss();}});root.addView(title);
      LinearLayout styles=row(a);detailsButton=button(a,"詳細地圖");simpleButton=button(a,"簡易地圖");weighted(styles,detailsButton);weighted(styles,simpleButton);root.addView(styles);
      status=text(a,RouteTrace.status(a),12,MUTED);status.setPadding(0,dp(a,4),0,dp(a,4));root.addView(status);
      LinearLayout dates=row(a);Button prev=button(a,"‹");date=button(a,"");Button next=button(a,"›");dates.addView(prev,new LinearLayout.LayoutParams(dp(a,46),-2));weighted(dates,date);dates.addView(next,new LinearLayout.LayoutParams(dp(a,46),-2));root.addView(dates);
      prev.setOnClickListener(new View.OnClickListener(){public void onClick(View v){shift(-1);}});next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){shift(1);}});date.setOnClickListener(new View.OnClickListener(){public void onClick(View v){Calendar c=Calendar.getInstance();c.setTimeInMillis(day);new DatePickerDialog(a,new DatePickerDialog.OnDateSetListener(){public void onDateSet(DatePicker v,int y,int m,int d){Calendar c=Calendar.getInstance();c.clear();c.set(y,m,d);day=c.getTimeInMillis();changedDay();}},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE)).show();}});
      LinearLayout times=row(a);from=button(a,"00:00");to=button(a,"24:00");weighted(times,from);TextView dash=text(a," 至 ",13,MUTED);times.addView(dash);weighted(times,to);root.addView(times);
      from.setContentDescription("區段開始時間");to.setContentDescription("區段結束時間");from.setOnClickListener(new View.OnClickListener(){public void onClick(View v){pickTime(true);}});to.setOnClickListener(new View.OnClickListener(){public void onClick(View v){pickTime(false);}});
      LinearLayout actions=row(a);Button allDay=button(a,"全日");Button apply=button(a,"套用區段");wholeButton=button(a,"完整本單");weighted(actions,allDay);weighted(actions,apply);weighted(actions,wholeButton);root.addView(actions);
      allDay.setOnClickListener(new View.OnClickListener(){public void onClick(View v){fromMinute=0;toMinute=1440;whole=false;load();}});apply.setOnClickListener(new View.OnClickListener(){public void onClick(View v){whole=false;load();}});wholeButton.setOnClickListener(new View.OnClickListener(){public void onClick(View v){whole=true;load();}});
      scope=new Spinner(a);scope.setBackgroundTintList(ColorStateList.valueOf(MUTED));root.addView(scope,new LinearLayout.LayoutParams(-1,dp(a,48)));
      scope.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> v,View child,int i,long id){if(binding||i>=keys.size())return;String key=keys.get(i);if(!key.equals(selected)){selected=key;whole=!key.isEmpty()&&!key.equals("idle");load();}}public void onNothingSelected(AdapterView<?> v){}});
      legend=text(a,"● 取餐　● 送餐　● 未接單",12,MUTED);android.text.SpannableString colored=new android.text.SpannableString("● 取餐　● 送餐　● 未接單");colored.setSpan(new android.text.style.ForegroundColorSpan(RouteMapView.PICKUP),0,4,0);colored.setSpan(new android.text.style.ForegroundColorSpan(RouteMapView.DELIVERY),5,9,0);colored.setSpan(new android.text.style.ForegroundColorSpan(RouteMapView.IDLE),10,colored.length(),0);legend.setText(colored);root.addView(legend);
      stats=text(a,"讀取中…",12,MUTED);stats.setPadding(0,dp(a,4),0,dp(a,4));root.addView(stats);
      map=new RouteMapView(a);root.addView(map,new LinearLayout.LayoutParams(-1,0,1));updateMapStyleButtons();
      detailsButton.setOnClickListener(new View.OnClickListener(){public void onClick(View v){map.setDetailed(true);updateMapStyleButtons();}});simpleButton.setOnClickListener(new View.OnClickListener(){public void onClick(View v){map.setDetailed(false);updateMapStyleButtons();}});
      LinearLayout bottom=row(a);Button fit=button(a,"全覽");Button minus=button(a,"−");Button plus=button(a,"＋");Button refresh=button(a,"更新");Button delete=button(a,"刪除區段");weighted(bottom,fit);weighted(bottom,minus);weighted(bottom,plus);weighted(bottom,refresh);weighted(bottom,delete);root.addView(bottom);
      fit.setOnClickListener(new View.OnClickListener(){public void onClick(View v){map.fit();}});minus.setOnClickListener(new View.OnClickListener(){public void onClick(View v){map.zoom(-1);}});plus.setOnClickListener(new View.OnClickListener(){public void onClick(View v){map.zoom(1);}});refresh.setOnClickListener(new View.OnClickListener(){public void onClick(View v){load();}});delete.setOnClickListener(new View.OnClickListener(){public void onClick(View v){deleteRange();}});
      TextView note=text(a,"詳細：道路地名；簡易：軌跡與比例尺。\n空白／斷線表示未記錄，點路線可看時間。",11,MUTED);root.addView(note);
      dialog.setContentView(root);dialog.setOnDismissListener(new DialogInterface.OnDismissListener(){public void onDismiss(DialogInterface d){generation++;RouteTrace.MAIN.removeCallbacks(ticker);}});
    }
    void updateMapStyleButtons(){boolean detail=map.isDetailed();detailsButton.setSelected(detail);simpleButton.setSelected(!detail);detailsButton.setBackground(bg(a,detail?0xff1f5874:0xff16344f));simpleButton.setBackground(bg(a,detail?0xff16344f:0xff1f5874));detailsButton.setContentDescription("詳細地圖"+(detail?"，已選擇":""));simpleButton.setContentDescription("簡易地圖"+(!detail?"，已選擇":""));}
    void show(){dialog.show();Window w=dialog.getWindow();if(w!=null){w.setBackgroundDrawableResource(android.R.color.transparent);w.setLayout((int)(a.getResources().getDisplayMetrics().widthPixels*.97),(int)(a.getResources().getDisplayMetrics().heightPixels*.92));}RouteTrace.syncCurrent(a);load();ticker.run();}
    void shift(int n){Calendar c=Calendar.getInstance();c.setTimeInMillis(day);c.add(Calendar.DATE,n);day=c.getTimeInMillis();changedDay();}
    void changedDay(){selected="";whole=false;optionStamp="";followToday=day==RouteCore.dayStart(System.currentTimeMillis(),TimeZone.getDefault());load();}
    String time(int m){return String.format(Locale.ROOT,"%02d:%02d",m/60,m%60);}
    void pickTime(final boolean start){int m=start?fromMinute:toMinute%1440;new TimePickerDialog(a,new TimePickerDialog.OnTimeSetListener(){public void onTimeSet(TimePicker v,int h,int min){if(start)fromMinute=h*60+min;else toMinute=h*60+min;whole=false;load();}},m/60,m%60,true).show();}
    long at(int minute){Calendar c=Calendar.getInstance();c.setTimeInMillis(day);if(minute==1440){c.add(Calendar.DATE,1);return c.getTimeInMillis();}c.set(Calendar.HOUR_OF_DAY,minute/60);c.set(Calendar.MINUTE,minute%60);return c.getTimeInMillis();}
    long end(){long t=at(toMinute);if(t<=at(fromMinute)){Calendar c=Calendar.getInstance();c.setTimeInMillis(t);c.add(Calendar.DATE,1);t=c.getTimeInMillis();}return t;}
    void load(){final int request=++generation;date.setText(fmt(day,"yyyy/MM/dd（E）"));from.setText(time(fromMinute));to.setText(time(toMinute));wholeButton.setEnabled(!selected.isEmpty()&&!selected.equals("idle"));status.setText(RouteTrace.status(a));
      final String key=selected;final boolean complete=whole;stats.setText("讀取路線…");
      RouteTrace.load(a,at(fromMinute),end(),key,complete,new RouteTrace.Callback(){public void done(RouteTrace.Data data){if(!dialog.isShowing()||request!=generation)return;bindOptions(data.orders);map.setData(data);String range=fmt(data.from,"MM/dd HH:mm")+"–"+fmt(data.to-1,"MM/dd HH:mm");String kind=complete&&!key.isEmpty()&&!key.equals("idle")?"本單完整路線 · ":"";
        stats.setText(kind+range+"\n"+String.format(Locale.TAIWAN,"已記錄 %.2f km · %d 個定位點",data.meters/1000,data.points.size()));
      }});
    }
    void bindOptions(List<RouteCore.Order> orders){ArrayList<String> labels=new ArrayList<>(),newKeys=new ArrayList<>();labels.add("全部路線（含未接單）");newKeys.add("");labels.add("僅未接單／空檔路線");newKeys.add("idle");for(RouteCore.Order o:orders){labels.add(o.label());newKeys.add(o.key);}String stamp=labels.toString()+newKeys.toString();if(stamp.equals(optionStamp))return;optionStamp=stamp;keys.clear();keys.addAll(newKeys);binding=true;
      ArrayAdapter<String> adapter=new ArrayAdapter<String>(a,android.R.layout.simple_spinner_item,labels){public View getView(int p,View v,ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);t.setTextColor(TEXT);t.setTextSize(14);t.setSingleLine(false);t.setMaxLines(2);return t;}public View getDropDownView(int p,View v,ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);t.setTextColor(TEXT);t.setBackgroundColor(CARD);t.setTextSize(14);t.setSingleLine(false);t.setPadding(dp(a,12),dp(a,12),dp(a,12),dp(a,12));return t;}};
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);scope.setAdapter(adapter);int pos=keys.indexOf(selected);scope.setSelection(Math.max(0,pos));binding=false;
    }
    void deleteRange(){final long lo=at(fromMinute),hi=end();new AlertDialog.Builder(a).setTitle("刪除此時間區段的軌跡？").setMessage(fmt(lo,"yyyy/MM/dd HH:mm")+" 至 "+fmt(hi-1,"yyyy/MM/dd HH:mm")+"\n將刪除此段所有訂單及空檔的 GPS 點。收入與跑單紀錄仍保留。").setNegativeButton("取消",null).setPositiveButton("刪除",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){RouteTrace.delete(a,lo,hi,new Runnable(){public void run(){load();}});}}).show();}
  }
  private RouteTraceUi(){}
}
