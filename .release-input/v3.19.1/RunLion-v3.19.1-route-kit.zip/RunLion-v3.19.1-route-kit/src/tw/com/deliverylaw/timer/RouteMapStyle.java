package tw.com.deliverylaw.timer;
/** Shared preference key and labels for the two renderings of the same observations. */
public final class RouteMapStyle {
  public static final String KEY="map_detail";
  public static final boolean DEFAULT=true;
  public static String label(boolean detailed){return detailed?"詳細地圖":"簡易地圖";}
  public static double metresPerPixel(double normalizedY,int zoom){
    double lat=Math.atan(Math.sinh(Math.PI*(1-2*normalizedY)));
    return Math.cos(lat)*2*Math.PI*6371008.8/(256.0*(1<<zoom));
  }
  public static double scaleMetres(double maximumMetres){
    if(!(maximumMetres>0)||!Double.isFinite(maximumMetres))return 1;
    double base=Math.pow(10,Math.floor(Math.log10(maximumMetres))),v=maximumMetres/base;
    return (v>=5?5:v>=2?2:1)*base;
  }
  private RouteMapStyle(){}
}
