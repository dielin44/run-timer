"""Fetch pinned public build tools; verify SHA-256 before writing each JAR."""
import argparse,hashlib,json,subprocess,tempfile
from pathlib import Path

def main(destination):
 root=Path(__file__).resolve().parent;out=Path(destination).resolve();out.mkdir(parents=True,exist_ok=True)
 deps=json.loads((root/'DEPENDENCIES.json').read_text())['jars'];groups={}
 for dep in deps:
  p=out/dep['name']
  if p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==dep['sha256']:continue
  groups.setdefault((dep['repository'],dep['commit']),[]).append(dep)
 with tempfile.TemporaryDirectory(prefix='runlion-public-deps-') as temp:
  for i,((repository,commit),items) in enumerate(groups.items()):
   repo=Path(temp)/str(i)
   subprocess.run(['git','init','--bare',str(repo)],check=True,capture_output=True)
   subprocess.run(['git','-C',str(repo),'fetch','--depth','1','--filter=blob:none','https://github.com/'+repository+'.git',commit],check=True,capture_output=True)
   for dep in items:
    data=subprocess.check_output(['git','-C',str(repo),'show',commit+':'+dep['path']])
    assert hashlib.sha256(data).hexdigest()==dep['sha256'],dep['name']
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==dep['git_blob_sha']
    (out/dep['name']).write_bytes(data);print('Verified',dep['name'])

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('destination');main(p.parse_args().destination)
