# 跑單大獅 v3.19.1：Map 設定整合與詳細／簡易軌跡地圖

這是基於完整 v3.18.5 APK 的可重建更新套件。新增功能的 Java 原始碼、精確修補腳本及檢查皆包含在內；這不是已遺失的完整原始專案。套件不含私鑰、簽章密碼、建置工具或使用者軌跡。

## 使用

- 軌跡記錄開關及「查看路線」收進 Map 設定：長按主畫面的 Map 即可開啟。主畫面移除獨立軌跡卡片，記錄預設關閉。開啟時需要精確定位；上方 GPS 總開關關閉也會暫停軌跡，明確顯示暫停原因。
- 查看路線時有「詳細地圖／簡易地圖」兩個按鍵。詳細顯示 OpenStreetMap 道路與地名；簡易僅顯示軌跡、北向與比例尺，不請求底圖。此處採用「同一視窗切換底圖詳簡」；不是大視窗與浮動小視窗的切換。
- 地圖樣式可隨時切換並記住上次選擇，保留同一組日期、訂單、時間區段、路線、縮放與拖曳位置，不改變記錄開關。
- 同時保留進單至取餐、取餐至送達／取消，以及未接單空檔的實際定位點。併單以各單保存的開始、取餐、結束時間分別回看；共同移動的一段會出現在各自訂單的路線中。
- 按手機當地日期查看，跨午夜會自動換日，保留前日資料。選指定訂單可查看本單全部已記錄區段，跨日也會顯示。
- 可以選開始／結束時間，結束早於或等於開始時視為跨到隔日，畫面會列出實際日期時間。可選全天、單一訂單、空檔；地圖可拖曳、雙指縮放、全覽，點定位點可看時間和精度。
- 橘色是取餐、藍色是送餐、紫色是空檔。GPS 中斷、開關切換、服務重啟、調整時鐘及刪除區段後保留斷點，不推測未記錄路線。
- 軌跡另存手機內的 SQLite，不改收入、原本里程或跑單紀錄。底圖沿用原本 OpenStreetMap 可見圖磚快取；離線時已保存的路線仍能畫出，未快取底圖可能留白。可刪除指定時間的軌跡點，確認畫面說明會刪除該區段所有訂單與空檔的點。
- 軌跡從開啟後開始保存；舊訂單無法補回先前未記錄的 GPS。

## 店名

- 已在原 v3.18.5 DEX 的卡片建立流程重現確切問題：同一個暫存變數先被設定為兩行上限數字 `2`，之後又拿去當店名字色，形成 `0x00000002`（全透明）。本版明確指定不透明字色，保留兩行店名顯示。
- 清除抓單結果、候選與保存時店名前方混入的「偏好設定／無法離線」。原有已保存店名在卡片顯示時也會清理這些前綴。店名中間的相同字詞、分店名稱、備註、完整單號與熊貓編號保留。
- 保留 v3.18.4 取消單收入統計、v3.18.5 店名讀取及候選確認修正。

## 檢查

323 項程式檢查：37 GPS／訂單／空檔與日期、12 真實 JSON 訂單狀態、22 店名前綴與備註、11 真實 SQLite 查詢與刪除、25 組譯後 DEX 整合檢查（含 Map 設定入口、主畫面不增卡片，以及切換時保留路線／視角／記錄狀態）、8 項地圖樣式比例尺檢查；另有原版顯示問題檢查（包含原版透明字色重現），以及原有 64 收入／卡片、39 店名流程、30 無障礙與 75 店名排除檢查。Android API 以替身執行，未在手機或模擬器測試；背景連續定位、權限介面與實際排版仍需手機實測。

確認 8,497 個其他類別及 406 個其他方法不變，只更動 16 個方法、新增 49 個功能類別。502 個非程式資源保留。維持原套件、原簽章，versionCode 63，能直接更新；清理舊版本累積的零值 ZIP 對齊填充，避免 local extra 長度溢位，其他 extra 欄位保留；驗證 APK v2 簽章、竄改拒絕、ZIP／DEX 完整性及原生庫 ZIP 16 KiB 對齊。

## 重建

需要 Java 17（含 JDK 編譯器）、Python 3.10+、cryptography、Git。建置工具來源與雜湊在 DEPENDENCIES.json。

```bash
python3 download_dependencies.py tools
python3 build_routes.py --base /absolute/RunLion-v3.18.5.apk --tool-dir tools --keystore /private/RunLion-signing.jks --signing-info /private/RunLion-signing-info.txt --output /absolute/RunLion-v3.19.1.apk --report VERIFICATION.json
git clone --depth 1 --branch 20240303 https://github.com/stleary/JSON-java.git json-java
python3 run_tests.py --tool-dir tools --json-source json-java/src/main/java
```

JSON-java 僅用於 JVM 測試（commit f9b5587c87aaf02e4a5ed1991d48d6c05993624a），不打包進 APK；手機使用 Android 的 org.json。編譯連結用 stubs 不會打包，只打包 Route 開頭的新增功能類別。輸入 APK SHA-256 與輸出雜湊記錄在 VERIFICATION.json。

Android 背景定位參考：https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start 。沿用既有 location 前景服務與通知，由可見 Activity 啟動；未增加獨立背景定位服務或新的定位權限種類。
