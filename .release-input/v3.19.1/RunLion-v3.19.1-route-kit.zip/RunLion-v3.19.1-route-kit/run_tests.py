"""Tests use JVM/SQLite and explicit Android API substitutes, not an emulator."""
from pathlib import Path
import argparse,json,os,shutil,subprocess,sys,re
ROOT=Path(__file__).resolve().parent
def run(argv,env=None):
 r=subprocess.run([str(x) for x in argv],check=True,capture_output=True,text=True,env=env);print(r.stdout.strip(),flush=True);return r.stdout
def main(args):
 tools=Path(args.tool_dir).resolve();out=ROOT/'testclasses';out.mkdir(exist_ok=True)
 env=os.environ.copy();env['RUNLION_COMPILE_CLASSPATH']=str(out)+':'+str(ROOT/'classes')
 run(['java',ROOT/'CompileRoutes.java',tools/'android-35.jar',out,Path(args.json_source).resolve(),ROOT/'tests'],env)
 cp=':'.join(str(x) for x in [out,ROOT/'classes',tools/'android-35.jar']);reports={}
 for test in ['TestRouteCore','TestRouteOrders','TestRouteMerchant','TestRouteMapStyle']:
  result=run(['java','-cp',cp,'tw.com.deliverylaw.timer.'+test]);reports[test]=int(re.search(r'PASS: (\d+)',result).group(1))
 for name in ['test_route_sql.py','test_route_hooks.py']:
  result=run([sys.executable,ROOT/'tests'/name]);reports[name]=int(re.search(r'PASS: (\d+)',result).group(1))
 shutil.copy2(ROOT/'classes-fixed.dex',ROOT/'regression/classes-fixed.dex')
 result=run([sys.executable,ROOT/'regression/test_store_dex.py']);reports['accounting_and_card']=64;reports['merchant_flow']=39
 env['RUNLION_DEX_PATH']=str(ROOT/'classes-fixed.dex');env['RUNLION_CONNECTION_REPORT']=str(ROOT/'regression/connection-tests.json')
 run([sys.executable,ROOT/'regression/tests/test_connection_dex.py'],env);reports['accessibility']=30
 run(['java',ROOT/'regression/tests/TestMerchantFilter.java']);reports['merchant_status_filter']=75
 report={'passed':sum(reports.values()),'groups':reports,'physical_device_tested':False,'emulator_tested':False,'limitations':'Location delivery, Android views, permission dialogs and vendor background process restrictions require phone testing. DEX integration tests substitute Android APIs. JVM tests run the shipped Java filtering/merchant logic. SQLite tests execute production SQL against Python SQLite.'}
 (ROOT/'TEST_RESULTS.json').write_text(json.dumps(report,indent=2)+'\n')
 verified=ROOT/'VERIFICATION.json'
 if verified.exists():v=json.loads(verified.read_text());v['tests']=report;verified.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(report,ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--tool-dir',required=True);p.add_argument('--json-source',required=True);main(p.parse_args())
