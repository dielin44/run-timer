"""Reproducible merchant-label fix using the intact, original signed APK.

This is a patch kit, not a replacement for the missing complete Java source.
No private key or credential is included. Use the existing release keystore.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import tempfile
import zipfile
import zlib
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

BASE_SHA256 = 'e7322f66da6771cd8cd0eb4117e276b25bce59497f785e67010d0797121c9b5a'
CERT_SHA256 = '30ab839d8235382de5584f58c76f9919a461243f11fcb8808be9592394098d05'
OLD_PATTERN = '(?:導航|開始導航|結束導航|返回導航|開啟導航|路線|地圖|目前位置|左轉|右轉|直行|繼續直行|迴轉|靠左|靠右|目的地|確認訂單|完成取單|完成取餐|顯示更多|商家|餐廳|地址|備註|店家照片|商家照片|照片|圖片)'
# The equivalent grouped existing alternatives leave room for the new label.
# The empty noncapturing suffix preserves the original DEX byte length.
NEW_PATTERN = OLD_PATTERN.replace('完成取單|完成取餐', '完成取[單餐]').replace('店家照片|商家照片|照片', '(?:[店商]家)?照片')[:-1] + '|無法離線)(?:|)'

def u32(b, p): return struct.unpack_from('<I', b, p)[0]
def p32(v): return struct.pack('<I', v)
def p64(v): return struct.pack('<Q', v)
def lp(b): return p32(len(b)) + b

def take(b, p=0):
    n = u32(b, p)
    assert p + 4 + n <= len(b)
    return b[p + 4:p + 4 + n], p + 4 + n

def sequence(b):
    p = 0
    while p < len(b):
        x, p = take(b, p)
        yield x
    assert p == len(b)

def eocd(b):
    p = b.rfind(b'PK\x05\x06')
    assert p >= 0 and p + 22 + struct.unpack_from('<H', b, p + 20)[0] == len(b)
    assert struct.unpack_from('<HH', b, p + 4) == (0, 0)
    cd = u32(b, p + 16)
    assert cd + u32(b, p + 12) == p
    return p, cd

def signature_blocks(b):
    end, cd = eocd(b)
    assert b[cd - 16:cd] == b'APK Sig Block 42'
    size = struct.unpack_from('<Q', b, cd - 24)[0]
    start = cd - size - 8
    assert struct.unpack_from('<Q', b, start)[0] == size
    pairs = {}
    p = start + 8
    while p < cd - 24:
        n = struct.unpack_from('<Q', b, p)[0]
        assert n >= 4 and p + 8 + n <= cd - 24
        pairs[u32(b, p + 8)] = b[p + 12:p + 8 + n]
        p += 8 + n
    assert p == cd - 24
    return pairs, start, cd, end

def content_digest(parts, hash_name='sha256'):
    chunks = []
    for part in parts:
        for p in range(0, len(part), 1 << 20):
            chunk = part[p:p + (1 << 20)]
            chunks.append(hashlib.new(hash_name, b'\xa5' + p32(len(chunk)) + chunk).digest())
    return hashlib.new(hash_name, b'\x5a' + p32(len(chunks)) + b''.join(chunks)).digest()

def verify_v2(b):
    b = bytes(b)
    blocks, start, cd, end = signature_blocks(b)
    signers, pos = take(blocks[0x7109871a])
    assert pos == len(blocks[0x7109871a])
    identities = []
    for signer in sequence(signers):
        signed, p = take(signer)
        sigs, p = take(signer, p)
        pub, p = take(signer, p)
        assert p == len(signer)
        digests, p = take(signed)
        certs, p = take(signed, p)
        attrs, p = take(signed, p)
        # apksig may append zero padding to its signed-data buffer.
        assert not any(signed[p:])
        dr = list(sequence(digests))
        sr = list(sequence(sigs))
        assert [u32(x, 0) for x in dr] == [u32(x, 0) for x in sr]
        alg = u32(sr[0], 0)
        assert alg in (0x101, 0x103, 0x102, 0x104)
        digest, _ = take(dr[0], 4)
        sig, _ = take(sr[0], 4)
        cert = x509.load_der_x509_certificate(list(sequence(certs))[0])
        key = cert.public_key()
        assert key.public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo) == pub
        h = hashes.SHA256() if alg in (0x101, 0x103) else hashes.SHA512()
        pad = padding.PKCS1v15() if alg in (0x103, 0x104) else padding.PSS(mgf=padding.MGF1(h), salt_length=h.digest_size)
        key.verify(sig, signed, pad, h)
        adjusted_end = bytearray(b[end:])
        struct.pack_into('<I', adjusted_end, 16, start)
        assert content_digest((b[:start], b[cd:end], adjusted_end), h.name) == digest
        identities.append(cert.fingerprint(hashes.SHA256()).hex())
    assert identities
    return identities

def uleb(b, p):
    n = shift = 0
    while True:
        byte = b[p]
        p += 1
        n |= (byte & 127) << shift
        if byte < 128: return n, p
        shift += 7

def patch_dex(data):
    b = bytearray(data)
    assert b[:4] == b'dex\n' and u32(b, 32) == len(b)
    count, table = u32(b, 56), u32(b, 60)
    needle = OLD_PATTERN.encode('utf-8')
    found = []
    for i in range(count):
        off = u32(b, table + i * 4)
        chars, p = uleb(b, off)
        end = b.index(0, p)
        if b[p:end] == needle: found.append((i, off, p, end, chars))
    assert len(found) == 1
    i, off, p, end, chars = found[0]
    assert chars == len(OLD_PATTERN) and p == off + 1
    new = NEW_PATTERN.encode('utf-8')
    assert len(new) == end - p and len(NEW_PATTERN) < 128
    assert re.fullmatch(NEW_PATTERN, '無法離線')
    # Verify the changed string remains sorted among its untouched neighbors.
    neighbors = []
    for j in (i - 1, i + 1):
        q = u32(b, table + j * 4)
        _, q = uleb(b, q)
        neighbors.append(bytes(b[q:b.index(0, q)]).decode('utf-8'))
    assert neighbors[0].encode('utf-16-be') < NEW_PATTERN.encode('utf-16-be') < neighbors[1].encode('utf-16-be')
    b[off] = len(NEW_PATTERN)
    b[p:end] = new
    b[12:32] = hashlib.sha1(b[32:]).digest()
    struct.pack_into('<I', b, 8, zlib.adler32(b[12:]) & 0xffffffff)
    assert len(b) == len(data)
    assert b[32:off] == data[32:off] and b[end:] == data[end:]
    return bytes(b), {'string_index': i, 'string_offset': off, 'pattern': NEW_PATTERN, 'instructions_unchanged': True}

def manifest_pool(b):
    p = 8
    while p < len(b):
        kind, header, size = struct.unpack_from('<HHI', b, p)
        if kind == 1:
            count, flags, string_start = u32(b, p + 8), u32(b, p + 16), u32(b, p + 20)
            result = []
            for i in range(count):
                q = p + string_start + u32(b, p + header + 4 * i)
                if flags & 0x100:
                    _, q = uleb(b, q)
                    n, q = uleb(b, q)
                    result.append((b[q:q + n].decode('utf-8'), q, n, 'utf-8'))
                else:
                    n = struct.unpack_from('<H', b, q)[0]
                    assert n < 0x8000
                    q += 2
                    result.append((b[q:q + n * 2].decode('utf-16-le'), q, n * 2, 'utf-16-le'))
            return result
        p += size
    raise AssertionError('missing manifest strings')

def patch_manifest(data):
    b = bytearray(data)
    pool = manifest_pool(b)
    strings = [x[0] for x in pool]
    p = 8
    changed = []
    result = {}
    while p < len(b):
        kind, header, size = struct.unpack_from('<HHI', b, p)
        if kind == 0x102:
            ext = p + header
            tag = strings[u32(b, ext + 4)]
            start, stride, n = struct.unpack_from('<HHH', b, ext + 8)
            for i in range(n):
                a = ext + start + i * stride
                name = strings[u32(b, a + 4)]
                typ, value = b[a + 15], u32(b, a + 16)
                if tag == 'manifest' and name == 'versionCode':
                    assert typ == 0x10 and value == 57
                    struct.pack_into('<I', b, a + 16, 58)
                    changed.append((a + 16, a + 20))
                    result['version_code'] = 58
                elif tag == 'manifest' and name == 'versionName':
                    assert typ == 3
                    old, q, nbytes, encoding = pool[value]
                    assert old == '3.18.1'
                    new = '3.18.2'.encode(encoding)
                    assert len(new) == nbytes
                    b[q:q + nbytes] = new
                    changed.append((q, q + nbytes))
                    result['version_name'] = '3.18.2'
                elif tag == 'manifest' and name == 'package':
                    assert typ == 3 and strings[value] == 'tw.com.deliverylaw.timer'
                    result['package'] = strings[value]
        p += size
    assert len(changed) == 2 and len(b) == len(data)
    assert all(x == y or any(start <= i < end for start, end in changed) for i, (x, y) in enumerate(zip(b, data)))
    return bytes(b), result

def export_key(keystore, signing_info):
    text = Path(signing_info).read_text()
    passwords = {}
    for line in text.splitlines():
        m = re.match(r'\s*(KeyStore 密碼|私鑰密碼)\s*[:：]\s*(.*?)\s*$', line)
        if m: passwords[m[1]] = m[2].strip('`')
    assert set(passwords) == {'KeyStore 密碼', '私鑰密碼'}
    source = '''import java.nio.file.*; import java.security.*;
class ExportKey { public static void main(String[] a) throws Exception {
KeyStore k=KeyStore.getInstance("JKS");
try(var in=Files.newInputStream(Path.of(a[0]))) {k.load(in,System.getenv("RUNLION_STOREPASS").toCharArray());}
var key=k.getKey("androiddebugkey",System.getenv("RUNLION_KEYPASS").toCharArray());
Files.write(Path.of(a[1],"key.der"),key.getEncoded());
Files.write(Path.of(a[1],"cert.der"),k.getCertificate("androiddebugkey").getEncoded());
}}'''
    with tempfile.TemporaryDirectory(prefix='runlion-key-') as temp:
        root = Path(temp)
        (root / 'ExportKey.java').write_text(source)
        env = os.environ.copy()
        env['RUNLION_STOREPASS'] = passwords['KeyStore 密碼']
        env['RUNLION_KEYPASS'] = passwords['私鑰密碼']
        process = subprocess.run(['java', str(root / 'ExportKey.java'), str(Path(keystore).resolve()), temp], env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        if process.returncode: raise RuntimeError('Unable to use existing release keystore')
        key = serialization.load_der_private_key((root / 'key.der').read_bytes(), password=None)
        cert_bytes = (root / 'cert.der').read_bytes()
    cert = x509.load_der_x509_certificate(cert_bytes)
    assert cert.fingerprint(hashes.SHA256()).hex() == CERT_SHA256
    assert cert.public_key().public_numbers() == key.public_key().public_numbers()
    return key, cert_bytes

def compact_alignment_extra(extra):
    """Drop only prior zero-filled 0xcafe padding; retain every other ZIP field."""
    result = bytearray()
    offset = 0
    while offset < len(extra):
        assert offset + 4 <= len(extra), 'Malformed local extra header'
        tag, size = struct.unpack_from('<HH', extra, offset)
        end = offset + 4 + size
        assert end <= len(extra), 'Malformed local extra payload'
        payload = extra[offset + 4:end]
        if tag != 0xcafe or any(payload):
            result += extra[offset:end]
        offset = end
    return bytes(result)

def rebuild_zip(original, replacements):
    """Keep untouched compressed entry bytes and correctly align stored assets."""
    entries = bytearray()
    central = []
    original_end, original_cd = eocd(original)
    cd_records = {}
    p = original_cd
    while p < original_end:
        assert original[p:p + 4] == b'PK\x01\x02'
        namelen, extra, comment = struct.unpack_from('<HHH', original, p + 28)
        record = original[p:p + 46 + namelen + extra + comment]
        name = original[p + 46:p + 46 + namelen].decode('utf-8')
        cd_records[name] = record
        p += len(record)
    assert p == original_end
    with zipfile.ZipFile(__import__('io').BytesIO(original)) as z:
        for info in z.infolist():
            name = info.filename
            if name.upper() == 'META-INF/MANIFEST.MF' or re.fullmatch(r'META-INF/[^/]+\.(?:SF|RSA|DSA|EC)', name, re.I):
                continue
            p = info.header_offset
            header = bytearray(original[p:p + 30])
            assert header[:4] == b'PK\x03\x04' and not info.flag_bits & 8
            namelen, extralen = struct.unpack_from('<HH', header, 26)
            namebytes = original[p + 30:p + 30 + namelen]
            extra = original[p + 30 + namelen:p + 30 + namelen + extralen]
            data_start = p + 30 + namelen + extralen
            compressed = original[data_start:data_start + info.compress_size]
            crc, size = info.CRC, info.file_size
            if name in replacements:
                raw = replacements[name]
                crc, size = zlib.crc32(raw) & 0xffffffff, len(raw)
                assert info.compress_type == zipfile.ZIP_DEFLATED
                compressor = zlib.compressobj(9, zlib.DEFLATED, -15)
                compressed = compressor.compress(raw) + compressor.flush()
            start = len(entries)
            align = (16384 if name.endswith('.so') else 4) if info.compress_type == 0 else 1
            if align > 1:
                extra = compact_alignment_extra(extra)
            if (start + 30 + namelen + len(extra)) % align:
                pad = (-(start + 30 + namelen + len(extra) + 4)) % align
                extra += struct.pack('<HH', 0xcafe, pad) + bytes(pad)
            assert len(extra) <= 65535
            struct.pack_into('<III', header, 14, crc, len(compressed), size)
            struct.pack_into('<H', header, 28, len(extra))
            assert (start + 30 + namelen + len(extra)) % align == 0
            entries += header + namebytes + extra + compressed
            record = bytearray(cd_records[name])
            struct.pack_into('<III', record, 16, crc, len(compressed), size)
            struct.pack_into('<I', record, 42, start)
            central.append(bytes(record))
    directory = b''.join(central)
    end = struct.pack('<IHHHHIIH', 0x06054b50, 0, 0, len(central), len(central), len(directory), len(entries), 0)
    return bytes(entries) + directory + end

def sign_v2(unsigned, key, cert):
    end, cd = eocd(unsigned)
    digest = content_digest((unsigned[:cd], unsigned[cd:end], unsigned[end:]))
    alg = p32(0x103)
    signed = lp(lp(alg + lp(digest))) + lp(lp(cert)) + lp(b'')
    sig = key.sign(signed, padding.PKCS1v15(), hashes.SHA256())
    pub = key.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    signer = lp(signed) + lp(lp(alg + lp(sig))) + lp(pub)
    value = lp(lp(signer))
    pairs = p64(len(value) + 4) + p32(0x7109871a) + value
    size = len(pairs) + 24
    block = p64(size) + pairs + p64(size) + b'APK Sig Block 42'
    new_end = bytearray(unsigned[end:])
    struct.pack_into('<I', new_end, 16, cd + len(block))
    return unsigned[:cd] + block + unsigned[cd:end] + new_end

def build(args):
    original = Path(args.base).read_bytes()
    assert hashlib.sha256(original).hexdigest() == BASE_SHA256
    assert verify_v2(original) == [CERT_SHA256]
    with zipfile.ZipFile(__import__('io').BytesIO(original)) as z:
        assert z.testzip() is None
        dex, dex_report = patch_dex(z.read('classes.dex'))
        manifest, manifest_report = patch_manifest(z.read('AndroidManifest.xml'))
    unsigned = rebuild_zip(original, {'classes.dex': dex, 'AndroidManifest.xml': manifest})
    key, cert = export_key(args.keystore, args.signing_info)
    signed = sign_v2(unsigned, key, cert)
    assert verify_v2(signed) == [CERT_SHA256]
    # Ensure a tampered payload is rejected, independently of the signing call.
    tampered = bytearray(signed)
    tampered[50] ^= 1
    try: verify_v2(tampered)
    except AssertionError: pass
    else: raise AssertionError('Tampered APK accepted')
    preserved = 0
    native = []
    with zipfile.ZipFile(__import__('io').BytesIO(original)) as before, zipfile.ZipFile(__import__('io').BytesIO(signed)) as after:
        assert after.testzip() is None
        for info in after.infolist():
            name = info.filename
            if name not in ('classes.dex', 'AndroidManifest.xml'):
                assert before.read(name) == after.read(name)
                preserved += 1
            if info.compress_type == 0:
                n, e = struct.unpack_from('<HH', signed, info.header_offset + 26)
                offset = info.header_offset + 30 + n + e
                assert offset % (16384 if name.endswith('.so') else 4) == 0
                if name.endswith('.so'): native.append(name)
        assert after.read('classes.dex') == dex and after.read('AndroidManifest.xml') == manifest
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(signed)
    report = {
        **manifest_report, 'apk': out.name,
        'sha256': hashlib.sha256(signed).hexdigest(), 'size_bytes': len(signed),
        'base_sha256': BASE_SHA256, 'certificate_sha256': CERT_SHA256,
        'verified_signature_scheme': 'v2', 'zip_integrity': True,
        'stored_entry_alignment': True, 'native_16kb_zip_alignment': native,
        'unchanged_noncode_entries': preserved, 'dex_patch': dex_report,
        'tampered_signature_rejected': True,
        'full_original_source_archive_available': False,
        'physical_device_tested': False, 'emulator_tested': False,
        'scope': 'Exclude the exact platform label 無法離線 from merchant candidates; continue to following merchant title. All method instructions and order ID handling are unchanged.'
    }
    Path(args.report).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['version_name', 'version_code', 'sha256', 'size_bytes', 'unchanged_noncode_entries', 'verified_signature_scheme']}, ensure_ascii=False))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--base', required=True)
    parser.add_argument('--keystore', required=True)
    parser.add_argument('--signing-info', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--report', required=True)
    build(parser.parse_args())
