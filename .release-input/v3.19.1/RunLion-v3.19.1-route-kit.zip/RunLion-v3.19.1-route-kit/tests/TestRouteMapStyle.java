package tw.com.deliverylaw.timer;
public class TestRouteMapStyle {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 public static void main(String[] args){
  check(RouteMapStyle.label(true).equals("詳細地圖"),"detailed label");check(RouteMapStyle.label(false).equals("簡易地圖"),"simple label");
  check(RouteMapStyle.DEFAULT,"first view defaults to detailed roads");
  double a=RouteMapStyle.metresPerPixel(.43,15),b=RouteMapStyle.metresPerPixel(.43,16);check(Math.abs(a/2-b)<1e-8,"zoom scale halves per level");
  check(RouteMapStyle.metresPerPixel(.43,15)<RouteMapStyle.metresPerPixel(.5,15),"Mercator latitude compensation");
  check(RouteMapStyle.scaleMetres(139)==100,"readable metric scale");check(RouteMapStyle.scaleMetres(480)==200,"scale fits available width");
  check(RouteMapStyle.scaleMetres(Double.NaN)>0,"invalid size remains safe");
  System.out.println("PASS: "+checks+" detailed/simple map style checks");
 }
}
