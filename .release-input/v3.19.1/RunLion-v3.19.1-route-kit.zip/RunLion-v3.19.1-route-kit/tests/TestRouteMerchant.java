package tw.com.deliverylaw.timer;
import java.util.*;
public class TestRouteMerchant {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 public static void main(String[] args){
  check(RouteMerchantText.clean("偏好設定添好運 台中 JMall店").equals("添好運 台中 JMall店"),"reported concatenated preference label");
  check(RouteMerchantText.clean("偏好設定 添好運 台中 JMall店").equals("添好運 台中 JMall店"),"space separated preference label");
  check(RouteMerchantText.clean("偏好設定｜添好運 台中 JMall店").equals("添好運 台中 JMall店"),"separator");
  check(RouteMerchantText.clean("無法離線添好運 台中 JMall店").equals("添好運 台中 JMall店"),"offline prefix");
  check(RouteMerchantText.clean("偏好設定 無法離線 添好運 台中 JMall店").equals("添好運 台中 JMall店"),"stacked UI labels");
  check(RouteMerchantText.clean("添好運 台中 JMall店").equals("添好運 台中 JMall店"),"normal name unchanged");
  check(RouteMerchantText.clean("無法離線").isEmpty(),"UI label alone not a merchant");
  check(RouteMerchantText.clean("偏好設定").isEmpty(),"preference label alone not a merchant");
  check(RouteMerchantText.clean(null).isEmpty(),"null safety");
  check(RouteMerchantText.clean("小店的偏好設定餐盒").equals("小店的偏好設定餐盒"),"internal phrase retained");
  check(RouteMerchantText.clean("小店 無法離線主題店").equals("小店 無法離線主題店"),"internal offline phrase retained");
  check(RouteMerchantText.label("偏好設定添好運 台中 JMall店","").equals("添好運 台中 JMall店"),"old saved prefix clean on display");
  check(RouteMerchantText.label("添好運 台中 JMall店","不要辣").equals("添好運 台中 JMall店｜不要辣"),"note combined");
  check(RouteMerchantText.label("","偏好設定備註").equals("偏好設定備註"),"note-only text unmodified");
  check(RouteMerchantText.label("無法離線","備註").equals("備註"),"no orphan separator");
  OrderGrabMerchant.Selection s=RouteMerchantText.selection(new OrderGrabMerchant.Selection("偏好設定添好運",Arrays.asList("偏好設定添好運","添好運","偏好設定","別間店")));
  check(s.storeName.equals("添好運"),"selected merchant cleaned");check(s.candidates.equals(Arrays.asList("添好運","別間店")),"candidate labels cleaned and duplicates removed");
  s=RouteMerchantText.selection(new OrderGrabMerchant.Selection("",Arrays.asList("偏好設定甲店","乙店")));check(s.storeName.isEmpty()&&s.candidates.size()==2,"ambiguous selection remains explicit");
  List<String> ids=Arrays.asList("TEST-12345");OrderGrabParser.Result r=RouteMerchantText.result(new OrderGrabParser.Result("Uber","偏好設定添好運","2726",ids));
  check(r.storeName.equals("添好運"),"OCR parsed result cleaned");check(r.numbers==ids,"full order IDs untouched");check(r.reference.equals("2726"),"Panda reference untouched");check(r.platform.equals("Uber"),"platform unchanged");
  System.out.println("PASS: "+checks+" merchant prefix/name/note checks");
 }
}
