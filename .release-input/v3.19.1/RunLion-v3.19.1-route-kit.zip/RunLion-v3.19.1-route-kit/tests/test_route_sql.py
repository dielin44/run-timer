"""Exercise production schema/query SQL on real SQLite, independent of Android UI."""
from pathlib import Path
import re,sqlite3,json
src=(Path(__file__).resolve().parents[1]/'src/tw/com/deliverylaw/timer/RouteTrace.java').read_text()
d=sqlite3.connect(':memory:');checks=[]
for sql in re.findall(r'd\.execSQL\("(CREATE [^"]+)"\)',src):d.execute(sql)
def check(value,label):assert value,label;checks.append(label)
check({r[0] for r in d.execute("SELECT name FROM sqlite_master WHERE type='table'")}=={'points','route_orders'},'separate local route tables')
# Taipei midnight; repeated labels are deliberately independent of coordinates.
midnight=1792080000000
for i,t in enumerate([midnight-2000,midnight-1000,midnight,midnight+1000,midnight+2000]):
 d.execute('INSERT INTO points(t,e,lat,lon,acc,seg) VALUES(?,?,?,?,?,?)',(t,10000+i*1000,24+i*.0001,120,10,1))
query=re.search(r'rawQuery\("(SELECT t,e,lat,lon,acc,seg FROM points[^"]+)"',src).group(1)
check(len(d.execute(query,(midnight-86400000,midnight)).fetchall())==2,'previous day excludes midnight')
check(len(d.execute(query,(midnight,midnight+86400000)).fetchall())==3,'new day includes midnight once')
check(len(d.execute(query,(midnight-1000,midnight+1001)).fetchall())==3,'selected cross-midnight interval')
check(len(d.execute(query,(midnight-2000,midnight+2001)).fetchall())==5,'whole order crosses date boundary')
check(len(d.execute(query,(midnight+86400000,midnight+172800000)).fetchall())==0,'empty future day is empty')
sql='INSERT OR REPLACE INTO route_orders(k,s,p,f,c,n,r,store,platform,seq) VALUES(?,?,?,?,?,?,?,?,?,?)'
d.execute(sql,('a',midnight-2000,midnight,midnight+1000,0,'TEST-A','12','測試店','熊貓',1))
d.execute(sql,('b',midnight-1000,midnight+1000,0,0,'TEST-B','','測試店二','Uber',2))
d.execute(sql,('c',midnight+4000,0,midnight+5000,1,'TEST-C','','取消店','Uber',1))
check(d.execute('SELECT COUNT(*) FROM route_orders').fetchone()[0]==3,'overlapping and cancelled orders coexist')
check(d.execute('SELECT k FROM route_orders WHERE f=0').fetchall()==[('b',)],'only unfinished interval treated as active')
lo,hi=midnight-1,midnight+1
d.execute('DELETE FROM points WHERE t>=? AND t<?',(lo,hi))
shift=d.execute('SELECT COALESCE(MAX(seg),0)+1 FROM points').fetchone()[0]
d.execute('UPDATE points SET seg=seg+? WHERE t>=?',(shift,hi))
remaining=d.execute('SELECT t,seg FROM points ORDER BY id').fetchall()
check(len(remaining)==4,'only requested points deleted')
check(remaining[1][1]!=remaining[2][1],'deletion creates permanent break instead of bridging missing route')
check(d.execute('SELECT COUNT(*) FROM route_orders').fetchone()[0]==3,'deleting route never deletes order records')
d.commit();d.close()
print('PASS:',len(checks),'real SQLite persistence/range checks')
(Path(__file__).resolve().parents[1]/'sql-tests.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2)+'\n')
