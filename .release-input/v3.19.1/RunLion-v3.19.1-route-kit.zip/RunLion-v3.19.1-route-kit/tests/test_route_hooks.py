"""Run assembled service callback prefix and record gates with Android API substitutes."""
import os,sys,struct,re,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
os.environ['RUNLION_DEX_PATH']=str(ROOT/'classes-fixed.dex')
sys.path.insert(0,str(ROOT/'regression/tests'))
if not (ROOT/'regression/tests').exists():sys.path.insert(0,str(ROOT/'RunLion-v3.18.5-patch-kit/tests'))
import dex_inspect as d
S='Ltw/com/deliverylaw/timer/TrackingService;';R='Ltw/com/deliverylaw/timer/RouteTrace;'
def signed(x,b):return x-(1<<b) if x&(1<<(b-1)) else x
def equal(x,y):return (0 if x is None else x)==(0 if y is None else y)
class Stop(Exception):pass
class VM:
 def __init__(self,gps=True,accept=True,wanted=True):self.gps=gps;self.accept=accept;self.wanted=wanted;self.hits=[];self.queued=0;self.prefs={'enabled':True};self.context={};self.synced=0
 def invoke(self,m,args):
  if 'SpeedMonitorStore;->gpsEnabled(' in m:return self.gps
  if m.startswith(R+'->enabled('):return self.wanted
  if m.startswith(R+'->syncCurrent('):self.synced+=1;return
  if m.startswith(R+'->prefs('):return self.prefs
  if m.startswith('Ltw/com/deliverylaw/timer/RouteTraceUi;->settings('):self.hits.append(args);raise Stop()
  if 'SpeedMonitorStore;->cancelMapPreview(' in m:return
  if 'Handler;->removeCallbacks(' in m:return
  if m.startswith('Ltw/com/deliverylaw/timer/RouteMapView;->getContext('):return self.context
  if m.startswith('Ltw/com/deliverylaw/timer/RouteMapView;->setContentDescription('):args[0]['description']=args[1];return
  if m.startswith('Ltw/com/deliverylaw/timer/RouteMapView;->invalidate('):return
  if m.startswith('Ltw/com/deliverylaw/timer/RouteMapStyle;->label('):return self.run('Ltw/com/deliverylaw/timer/RouteMapStyle;','label',args,True)
  if m.startswith('Landroid/content/SharedPreferences;->edit('):return self.prefs
  if m.startswith('Landroid/content/SharedPreferences$Editor;->putBoolean('):args[0][args[1]]=args[2];return args[0]
  if m.startswith('Landroid/content/SharedPreferences$Editor;->apply('):return
  if 'GpsFixFilter;->accept(' in m:return self.accept
  if m.startswith(R+'->record('):self.hits.append(args);raise Stop()
  if 'SystemClock;->elapsedRealtime(' in m:return 100000
  if 'System;->currentTimeMillis(' in m:return 1000000
  if 'Location;->getElapsedRealtimeNanos(' in m:return 100000000000
  if 'Location;->hasAccuracy(' in m:return True
  if 'Location;->getAccuracy(' in m:return 10.0
  if 'Location;->getLatitude(' in m:return 24.0
  if 'Location;->getLongitude(' in m:return 120.0
  if '->getApplicationContext(' in m:return args[0]
  if 'SpeedMonitorStore;->rejectedFix(' in m:return
  if 'TrackingService;->updateSpeedPresentation(' in m:return
  if 'RouteTrace$1;-><init>(' in m:return
  if 'ExecutorService;->execute(' in m:self.queued+=1;raise Stop()
  owner,name=m.split('->',1)
  if owner=='Ltw/com/deliverylaw/timer/MainActivity;':
   if name.startswith('dp('):return args[1]
   if name.startswith('text('):return {'text':args[1],'textColor':args[3]}
   if name.startswith('actionButton('):return {'text':args[1]}
   if name.startswith(('column(', 'rounded(', 'matchWrap(')):return {}
  if owner=='Landroid/graphics/Color;' and name.startswith('rgb('):return 0xff000000|(args[0]<<16)|(args[1]<<8)|args[2]
  if owner=='Ljava/lang/StringBuilder;':
   if name.startswith('<init>'):args[0]['value']=args[1] if len(args)>1 else '';return
   if name.startswith('append('):args[0]['value']+=str(args[1]);return args[0]
   if name.startswith('toString('):return args[0]['value']
  if name.startswith('<init>'):return
  if owner.startswith('Landroid/widget/'):
   if name.startswith('setTextColor('):args[0]['textColor']=args[1];return
   if name.startswith('setMaxLines('):args[0]['maxLines']=args[1];return
   if name.startswith('setSingleLine('):args[0]['singleLine']=args[1];return
   if name.startswith('setHint('):args[0]['hint']=args[1];return
   if name.startswith(('set','addView','addTextChangedListener')):return
  raise AssertionError(m)
 def run(self,owner,name,args,static=False):
  ix,_,co=next(x for x in d.classes[owner] if d.methods[x[0]].split('->')[1].startswith(name+'('));code={x[0]:x for x in d.dis(co)};regs,ins=struct.unpack_from('<HH',d.D,co);r=[0]*regs;r[regs-ins:]=args;pc=0;last=None
  try:
   for _ in range(1500):
    at,op,w,detail=code[pc];n=pc+len(w)
    if op in [1,4,7]:r[(w[0]>>8)&15]=r[(w[0]>>12)&15]
    elif op in [2,5,8]:r[w[0]>>8]=r[w[1]]
    elif op in [10,11,12]:r[w[0]>>8]=last
    elif op==14:return
    elif op in [0x0f,0x11]:return r[w[0]>>8]
    elif op==0x12:r[(w[0]>>8)&15]=signed(w[0]>>12,4)
    elif op==0x13:r[w[0]>>8]=signed(w[1],16)
    elif op==0x14:r[w[0]>>8]=signed(w[1]+(w[2]<<16),32)
    elif op==0x15:r[w[0]>>8]=struct.unpack('<f',struct.pack('<I',w[1]<<16))[0]
    elif op==0x16:r[w[0]>>8]=signed(w[1],16)
    elif op==0x17:r[w[0]>>8]=signed(w[1]+(w[2]<<16),32)
    elif op==0x1a:r[w[0]>>8]=d.strings[w[1]]
    elif op==0x22:r[w[0]>>8]={}
    elif op==0x23:r[(w[0]>>8)&15]=[None]*r[(w[0]>>12)&15]
    elif op==0x28:n=pc+signed(w[0]>>8,8)
    elif op==0x29:n=pc+signed(w[1],16)
    elif op==0x2d:x,y=r[w[1]&255],r[w[1]>>8];r[w[0]>>8]=(x>y)-(x<y)
    elif op==0x46:r[w[0]>>8]=r[w[1]&255][r[w[1]>>8]]
    elif op==0x4d:r[w[1]&255][r[w[1]>>8]]=r[w[0]>>8]
    elif op in range(0x38,0x3e):
     x=r[w[0]>>8];take=[lambda:equal(x,0),lambda:not equal(x,0),lambda:x<0,lambda:x>=0,lambda:x>0,lambda:x<=0][op-0x38]()
     if take:n=pc+signed(w[1],16)
    elif op in range(0x52,0x59):r[(w[0]>>8)&15]=r[(w[0]>>12)&15].get(d.fields[w[1]].split('->')[1].split(':')[0],0)
    elif op in range(0x59,0x60):r[(w[0]>>12)&15][d.fields[w[1]].split('->')[1].split(':')[0]]=r[(w[0]>>8)&15]
    elif op==0x60:r[w[0]>>8]=0xffffd780
    elif op==0x62:r[w[0]>>8]={}
    elif op==0x9e:r[w[0]>>8]=r[w[1]&255]//r[w[1]>>8]
    elif op==0xd8:r[w[0]>>8]=r[w[1]&255]+signed(w[1]>>8,8)
    elif op in [0x6e,0x6f,0x70,0x71,0x72,0x74,0x75,0x76,0x77,0x78]:
     if op<0x74:count=w[0]>>12;ix=[w[2]&15,(w[2]>>4)&15,(w[2]>>8)&15,(w[2]>>12)&15,(w[0]>>8)&15][:count]
     else:count=w[0]>>8;ix=list(range(w[2],w[2]+count))
     callee=d.methods[w[1]];types=re.findall(r'\[*L[^;]+;|\[*[ZBSCIFJD]',callee.split('(',1)[1].split(')',1)[0]);values=[];pos=0
     if op not in [0x71,0x77]:values.append(r[ix[0]]);pos=1
     for typ in types:values.append(r[ix[pos]]);pos+=2 if typ in ['J','D'] else 1
     last=self.invoke(callee,values)
    else:raise AssertionError((op,pc,detail))
    pc=n
   raise AssertionError('budget')
  except Stop:return
checks=[]
def check(b,s):assert b,s;checks.append(s)
for active in [False,True]:
 vm=VM();vm.run(S,'onLocationChanged',[{'routeTrackingActive':active,'gpsFixFilter':{}},{}]);check(len(vm.hits)==1,'accepted fix reaches trace when order active='+str(active))
vm=VM(gps=False);vm.run(S,'onLocationChanged',[{},{}]);check(not vm.hits,'master GPS off prevents trace')
vm=VM();vm.run(S,'onLocationChanged',[{},None]);check(not vm.hits,'null fix prevents trace')
vm=VM(accept=False);vm.run(S,'onLocationChanged',[{'gpsFixFilter':{}},{}]);check(not vm.hits,'rejected fix prevents trace')
for wanted,gps,location,expected in [(False,True,{},0),(True,False,{},0),(True,True,None,0),(True,True,{},1)]:
 vm=VM(wanted=wanted,gps=gps);vm.run(R,'record',[{},location],True);check(vm.queued==expected,'record gate '+str((wanted,gps,location is not None)))
# New application-method references resolve to shipped methods, including the un-inlined state payload.
co=next(co for ix,_,co in d.classes[R] if '->syncCurrent(' in d.methods[ix]);check(any('Snapshot;->payload:' in x[3] for x in d.dis(co)),'snapshot payload read from real field')
actor={f.split('->')[1].split(':')[0]:[None]*12 for f in d.fields if f.startswith('Ltw/com/deliverylaw/timer/MainActivity;') and ':[Landroid/widget/' in f}
vm=VM();vm.run('Ltw/com/deliverylaw/timer/MainActivity;','createOrderCard',[actor,0]);note=actor['noteInputs'][0];number=actor['orderNumberInputs'][0]
check((note['textColor']>>24)&255==255,'card merchant text has fully opaque alpha instead of 0x00000002')
check(note['maxLines']==2 and not note['singleLine'],'merchant keeps two line display')
check(number['maxLines']==2 and not number['singleLine'],'Panda ID keeps two line display')
import types
base_module=types.ModuleType('original_route_dex')
os.environ['RUNLION_DEX_PATH']=str(ROOT/'base.dex')
exec(compile((Path(d.__file__)).read_text(),str(d.__file__),'exec'),base_module.__dict__)
fixed_d=d;d=base_module
base_actor={f.split('->')[1].split(':')[0]:[None]*12 for f in d.fields if f.startswith('Ltw/com/deliverylaw/timer/MainActivity;') and ':[Landroid/widget/' in f}
VM().run('Ltw/com/deliverylaw/timer/MainActivity;','createOrderCard',[base_actor,0])
check(base_actor['noteInputs'][0]['textColor']==2,'original 3.18.5 reproduces transparent merchant color 0x00000002')
d=fixed_d
actor={'miniMapSettingsOpen':False,'handler':{},'mapPreviewEnd':{}}
vm=VM();vm.run('Ltw/com/deliverylaw/timer/MainActivity;','showMiniMapSettings',[actor]);check(len(vm.hits)==1 and vm.hits[0][0] is actor,'Map settings receives trajectory section with activity')
check(isinstance(vm.hits[0][1],dict),'trajectory controls attached to Map settings column')
root={'children':['header','speed','orders']};vm=VM();vm.run('Ltw/com/deliverylaw/timer/RouteTraceUi;','install',[{},root],True);check(root['children']==['header','speed','orders'] and vm.synced==1,'main screen synchronizes without adding route card')
for detail in [False,True]:
 original_data={};actor={'data':original_data,'cx':.835,'cy':.431,'zoom':15,'ready':True,'fitPending':False}
 vm=VM();vm.run('Ltw/com/deliverylaw/timer/RouteMapView;','setDetailed',[actor,detail]);check(actor['detailed']==detail,'map display mode changes '+str(detail))
 check(actor['data'] is original_data,'switch preserves selected route data '+str(detail))
 check((actor['cx'],actor['cy'],actor['zoom'],actor['fitPending'])==(.835,.431,15,False),'switch preserves zoom and position '+str(detail))
 check(vm.prefs=={'enabled':True,'map_detail':detail},'switch persists only map style without changing recording '+str(detail))
print('PASS:',len(checks),'assembled DEX route integration checks (Android API substitutes)')
(ROOT/'hook-tests.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2)+'\n')
