package tw.com.deliverylaw.timer;
import java.util.*;
public class TestRouteCore {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static RouteCore.Order order(long a,long p,long e){RouteCore.Order o=new RouteCore.Order();o.start=a;o.pickup=p;o.end=e;o.sequence=1;return o;}
 static long time(String s){return java.time.ZonedDateTime.parse(s).toInstant().toEpochMilli();}
 public static void main(String[] args){
  RouteCore.Filter f=new RouteCore.Filter(1);long base=time("2026-10-15T23:59:50+08:00");long e=100000;
  RouteCore.Point first=f.accept(base,e,e,24,120,10);check(first!=null,"first fix");
  check(f.accept(base+100,e+100,e+100,24.0001,120,10)==null,"subsecond throttling");
  check(f.accept(base+2000,e+2000,e+2000,24,120,10)==null,"stationary throttle");
  RouteCore.Point next=f.accept(base+2000,e+2000,e+2000,24.0001,120,10);check(next!=null,"moving fix");
  check(RouteCore.connect(first,next),"normal observations connect");
  check(f.accept(base+3000,e+3000,e+3000,25,121,10)==null,"GPS teleport excluded");
  check(f.accept(base+4000,e+4000,e+4000,24.0002,120,80)==null,"poor precision excluded");
  check(f.accept(base+4000,e+4000,e+4000,Double.NaN,120,10)==null,"NaN excluded");
  check(f.accept(base+4000,e+4000,e+4000,24,Double.POSITIVE_INFINITY,10)==null,"infinity excluded");
  check(f.accept(base+4000,e+4000,e+4000,91,120,10)==null,"invalid latitude excluded");
  check(f.accept(base+4000,e+4000,e+4000,24,181,10)==null,"invalid longitude excluded");
  check(f.accept(base+4000,e+4000,e+4000,24,120,-1)==null,"invalid accuracy excluded");
  check(f.accept(base+4000,e+4000,e-20000,24,120,10)==null,"stale fix excluded");
  check(f.accept(base+4000,e+4000,e+20000,24,120,10)==null,"future fix excluded");
  check(f.accept(base+4000,e+4000,e+2000,24.0001,120,10)==null,"duplicate elapsed excluded");
  RouteCore.Point midnight=f.accept(base+20000,e+20000,e+20000,24.001,120,10);check(midnight!=null,"cross midnight fix");check(RouteCore.connect(next,midnight),"same order can cross midnight");
  f.reset();RouteCore.Point resumed=f.accept(base+21000,e+21000,e+21000,24.0011,120,10);check(!RouteCore.connect(midnight,resumed),"off and on split without invented bridge");
  RouteCore.Point longGap=f.accept(base+100000,e+100000,e+100000,24.1,120,10);check(longGap!=null&&!RouteCore.connect(resumed,longGap),"lost GPS gap splits");
  RouteCore.Point clock=f.accept(base+200000,e+102000,e+102000,24.1001,120,10);check(clock!=null&&!RouteCore.connect(longGap,clock),"wall clock adjustment splits");
  RouteCore.Filter still=new RouteCore.Filter(1);RouteCore.Point s=still.accept(base,e,e,24,120,10);RouteCore.Point s2=still.accept(base+30000,e+30000,e+30000,24,120,10);check(s2!=null&&RouteCore.connect(s,s2),"stationary heartbeat retained");
  RouteCore.Order a=order(base,base+10000,base+30000);a.key="a";RouteCore.Order b=order(base+5000,base+20000,base+40000);b.key="b";List<RouteCore.Order> orders=Arrays.asList(a,b);
  check(RouteCore.phase(base-1,orders,null)==0,"before any order is idle");check(RouteCore.phase(base,orders,null)==1,"accept starts pickup");check(RouteCore.phase(base+10000,orders,a)==2,"pickup starts delivery");check(RouteCore.phase(base+10000,orders,b)==1,"overlap retains second pickup phase");check(RouteCore.phase(base+10000,orders,null)==2,"combined delivery priority");check(RouteCore.phase(base+30001,orders,a)==-1,"finished first order excluded");check(RouteCore.phase(base+30001,orders,b)==2,"second order continues");check(RouteCore.phase(base+40001,orders,null)==0,"after final order idle");
  a.cancelled=true;check(a.phase(base+30001)==-1,"cancel ends route at cancellation");
  a.number="abcd-1234";a.reference="#2726";a.platform="熊貓";check(a.label().contains("#2726，abcd-1234"),"Panda reference display");a.reference="";check(a.label().contains("abcd-1234")&&!a.label().contains("#"),"full ID fallback");
  TimeZone tz=TimeZone.getTimeZone("Asia/Taipei");long d=RouteCore.dayStart(base,tz);check(d==time("2026-10-15T00:00:00+08:00"),"Taipei day boundary");check(RouteCore.nextDay(d,tz)==time("2026-10-16T00:00:00+08:00"),"Taipei next day");check(RouteCore.dayStart(base+20000,tz)==RouteCore.nextDay(d,tz),"daily rollover without deletion");
  TimeZone ny=TimeZone.getTimeZone("America/New_York");long dst=RouteCore.dayStart(time("2026-03-08T12:00:00-04:00"),ny);check(RouteCore.nextDay(dst,ny)-dst==23*3600000L,"calendar day handles DST");
  check(Math.abs(RouteCore.meters(24,120,24.001,120)-111.195)<.1,"distance calculation");
  System.out.println("PASS: "+checks+" GPS, per-order, idle and calendar checks");
 }
}
