package tw.com.deliverylaw.timer;
import org.json.*;
import java.util.*;
public class TestRouteOrders {
 static int checks;
 static void check(boolean b,String s){if(!b)throw new AssertionError(s);checks++;}
 static JSONObject order(long start,int seq,boolean active,long pickup,long end)throws Exception {return new JSONObject().put("startedAt",start).put("sequence",seq).put("active",active).put("pickupAt",pickup).put("completedAt",end).put("orderNumber","TEST-ID").put("storeName","測試店");}
 public static void main(String[] args)throws Exception{
  JSONObject active=order(1000,1,true,0,0),second=order(1000,2,true,1500,0);JSONObject root=new JSONObject().put("orders",new JSONArray().put(active).put(second));
  Map<String,RouteCore.Order> parsed=RouteTrace.parseOrders(root);check(parsed.size()==2,"simultaneous orders distinct");check(parsed.get("1000:1").phase(2000)==1,"unpicked order");check(parsed.get("1000:2").phase(2000)==2,"picked order");
  JSONObject completed=order(1000,1,false,1500,3000);root.put("sessionCompleted",new JSONArray().put(completed));parsed=RouteTrace.parseOrders(root);check(parsed.get("1000:1").end==3000,"stale active slot cannot reopen completed order");
  root=new JSONObject().put("history",new JSONObject().put("2026-10-15",new JSONArray().put(new JSONObject().put("orderResults",new JSONArray().put(completed)))));
  parsed=RouteTrace.parseOrders(root);check(parsed.size()==1&&parsed.get("1000:1").end==3000,"completed history schema");
  root=new JSONObject().put("activeTrips",new JSONArray().put(new JSONObject().put("completed",new JSONArray().put(completed))));check(RouteTrace.parseOrders(root).size()==1,"partially finished trip schema");
  root=new JSONObject().put("orders",new JSONArray().put(order(0,0,false,0,0)).put(order(3000,1,false,0,0)));check(RouteTrace.parseOrders(root).isEmpty(),"unused cards omitted");
  completed.put("cancelled",true);root=new JSONObject().put("sessionCompleted",new JSONArray().put(completed));parsed=RouteTrace.parseOrders(root);check(parsed.get("1000:1").cancelled,"cancel status retained");check(parsed.get("1000:1").phase(3001)==-1,"cancelled route stops");
  root=new JSONObject().put("orders",new JSONArray().put(active).put(order(5000,1,true,0,0)));check(RouteTrace.parseOrders(root).size()==2,"reused first card remains distinct");
  root=new JSONObject().put("orders",new JSONArray().put(active.put("orderNumber","MODIFIED").put("storeName","修改店名")));parsed=RouteTrace.parseOrders(root);check(parsed.get("1000:1").number.equals("MODIFIED"),"number edit keeps stable route identity");check(parsed.get("1000:1").name.equals("修改店名"),"merchant edit updates route label");
  System.out.println("PASS: "+checks+" real JSON order-state checks");
 }
}
