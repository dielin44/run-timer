import javax.tools.*;
import java.nio.file.*;
import java.util.*;
class CompileRoutes {
 public static void main(String[] a)throws Exception{
  List<String> options=new ArrayList<>(List.of("-source","8","-target","8","-encoding","UTF-8","-bootclasspath",a[0],"-d",a[1]));
  String cp=System.getenv("RUNLION_COMPILE_CLASSPATH");if(cp!=null){options.add("-classpath");options.add(cp);}
  for(int i=2;i<a.length;i++)try(var files=Files.walk(Path.of(a[i]))){files.filter(p->p.toString().endsWith(".java")).forEach(p->options.add(p.toString()));}
  int status=ToolProvider.getSystemJavaCompiler().run(null,System.out,System.err,options.toArray(new String[0]));if(status!=0)System.exit(status);
 }
}
