"""Execute changed merchant-flow DEX methods with platform/extraction API stubs."""
from pathlib import Path
import json,re
import test_previous_dex as p
ROOT=Path(__file__).resolve().parent
d=p.d;A=p.A;S=p.S
T='Ltw/com/deliverylaw/timer/OrderGrabText;'
C='Ltw/com/deliverylaw/timer/OrderGrabTextController;'
D='Ltw/com/deliverylaw/timer/OrderGrabDraft;'
R='Ltw/com/deliverylaw/timer/OrderGrabParser$Result;'
READ='Ltw/com/deliverylaw/timer/OrderGrabText$Read;'
SELECT='Ltw/com/deliverylaw/timer/OrderGrabMerchant$Selection;'
for c in [T,C]:
 for i,_,co in d.classes[c]:
  if co:p.METHODS[d.methods[i]]=(co,{x[0]:x for x in d.dis(co)})
def lst(value):return value if isinstance(value,list) else value['fields'].setdefault('items',[])
class StoreVM(p.VM):
 def __init__(self):self.find_calls=[];self.selection=p.obj(SELECT,storeName='小獅食堂',candidates=['小獅食堂']);self.closed=[];self.updates=[];self.shown=0;self.guards=[];self.saved=[]
 def invoke(self,m,args):
  owner,name=m.split('->',1)
  if owner==T and name.startswith('platform('):return {'com.ubercab.driver':'Uber','com.logistics.rider.foodpanda':'熊貓'}.get(args[0],'')
  if owner==T and name.startswith('lines('):return args[0]
  if owner=='Ltw/com/deliverylaw/timer/OrderGrabParser;' and name.startswith('parseRegion('):return p.obj(R,platform=args[1],storeName='',reference='',numbers=[] if args[2]==2 or not args[1] else ['A1B2C'])
  if owner=='Ltw/com/deliverylaw/timer/OrderGrabMerchant;' and name.startswith('find('):self.find_calls.append(args);return self.selection
  if owner in [R,READ,SELECT] and name.startswith('<init>'):
   keys=['platform','storeName','reference','numbers'] if owner==R else ['order','storeChoices'] if owner==READ else ['storeName','candidates']
   args[0]['fields'].update(dict(zip(keys,args[1:])));return
  if owner=='Ljava/lang/String;' and name.startswith('matches'):return re.fullmatch(args[1].replace(r'[\p{L}]',r'[^\W\d_]'),args[0]) is not None
  if owner in ['Ljava/util/ArrayList;','Ljava/util/LinkedHashSet;']:
   if name.startswith('<init>'):args[0]['fields']['items']=list(lst(args[1])) if len(args)>1 else [];return
   v=lst(args[0])
   if name.startswith('iterator'):return p.obj('Iterator',items=v,index=0)
   if name.startswith('addAll'):
    for x in lst(args[1]):
     if owner=='Ljava/util/ArrayList;' or x not in v:v.append(x)
    return True
   if name.startswith('add('):
    if owner=='Ljava/util/ArrayList;' or args[1] not in v:v.append(args[1])
    return True
   if name.startswith('isEmpty'):return not v
   if name.startswith('size'):return len(v)
   if name.startswith('get('):return v[args[1]]
  if owner=='Ljava/util/Collections;' and name.startswith('emptyList'):return []
  if owner==C:
   if name.startswith('update('):self.updates.append(args[1]);return
   if name.startswith('show('):self.shown+=1;return
   if name.startswith('close('):self.closed.append(args[1:]);return
  if owner==A:
   if name=='ensureNextOrderCardVisible()V':return
   if name=='ensureCurrentState()Z':return True
   if name=='saveState()Z':self.saved.append(dict(args[0]['fields']['slots'][0]['fields']));return True
  if owner in ['Landroid/widget/Button;','Landroid/widget/EditText;','Landroid/widget/TextView;']:
   f=args[0]['fields']
   for prefix,key in [('setEnabled','enabled'),('setAlpha','alpha'),('setVisibility','visibility'),('setContentDescription','description'),('setHint','hint')]:
    if name.startswith(prefix):f[key]=args[1];return
   if name.startswith('isEnabled'):return f.get('enabled',True)
   if name.startswith('setText'):
    if f.get('actor'):self.guards.append(f['actor']['fields']['programmaticInputs'])
    f['text']=args[1];return
  if owner=='Landroid/text/Editable;' and name.startswith('length'):return len(args[0])
  return super().invoke(m,args)
checks=[]
def check(actual,expected,label):assert actual==expected,(label,actual,expected);checks.append(label)
def lines():return [p.obj('Line',text='A1B2C'),p.obj('Line',text='Uber'),p.obj('Line',text='小獅食堂'),p.obj('Line',text='台中市西屯區測試路100號')]
for mode in [0,1,2]:
 vm=StoreVM();result=vm.invoke(T+'->read(Ljava/util/List;Ljava/lang/String;I)'+READ,[lines(),'com.ubercab.driver',mode])['fields']
 check(len(vm.find_calls),1,'merchant recognition called for region '+str(mode))
 check(result['order']['fields']['storeName'],'小獅食堂','visible store retained for region '+str(mode))
 check(lst(result['order']['fields']['numbers']),[] if mode==2 else ['A1B2C'],'ID scope preserved '+str(mode))
 check(result['storeChoices'],['小獅食堂'],'store candidates retained '+str(mode))
for package in ['unknown.app','com.attacker.app']:
 vm=StoreVM();result=vm.invoke(T+'->read(Ljava/util/List;Ljava/lang/String;I)'+READ,[lines(),package,1])['fields']
 check(len(vm.find_calls),0,'unsupported foreground rejected '+package)
 check(result['order']['fields']['storeName'],'','unsupported foreground no store '+package)
for store,candidates,expected_close in [('小獅食堂',['小獅食堂'],True),('',[],True),('',['小獅食堂','大獅食堂'],False)]:
 vm=StoreVM();draft=p.obj(D,number='A1B2C',storeName=store,reference='',platform='Uber',choices=[])
 controller=p.obj(C,draft=draft,storeChoices=candidates)
 vm.invoke(C+'->lambda$start$6$tw-com-deliverylaw-timer-OrderGrabTextController()V',[controller])
 check(bool(vm.closed),expected_close,'confirmation branch '+str((store,candidates)))
 check(draft['fields']['number'],'A1B2C','confirmation retains ID '+str((store,candidates)))
 if not store and candidates:check(vm.shown,1,'ambiguous store stays visible');check('店名' in vm.updates[-1],True,'ambiguous store explanation')
 if not store and not candidates:check('未讀到店名' in vm.closed[-1][1],True,'empty result says store is missing')
 if expected_close:check(vm.closed[-1][2],1,'confirmation applies explicitly')
# Execute saved form data through the existing callback into the active card.
vm=StoreVM();state=p.obj(S,active=True,finished=False,startedAt=123456,sequence=1,orderNumber='',storeName='',note='',platform='',platformReference='')
note=p.obj('EditText',text='');actor=p.obj(A,slots=[state],noteInputs=[note],orderNumberInputs=[p.obj('EditText',text='')],programmaticInputs=False,storageBlocked=False)
note['fields']['actor']=actor
saved=vm.invoke(A+'->lambda$showOrderStoreForm$10$tw-com-deliverylaw-timer-MainActivity(IJILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z',[actor,0,123456,1,'A1B2C','小獅食堂','不加辣','Uber',''])
check(saved,1,'store form save accepted')
check(state['fields']['storeName'],'小獅食堂','store saved separately')
check(state['fields']['orderNumber'],'A1B2C','number saved separately')
check(note['fields']['text'],'小獅食堂｜不加辣','card shows store and note')
check(vm.saved[-1]['storeName'],'小獅食堂','store was saved before display')
check(vm.guards,[1],'card update suppresses input watcher')
check(actor['fields']['programmaticInputs'],False,'input guard restored')
def widget():return p.obj('Widget',text='',enabled=True)
actor['fields'].update(tripLocked=True,simultaneousEntryUnlocked=False,twoOrderButton=widget(),threeOrderButton=widget(),orderButtons=[widget()],cancelButtons=[widget()],orderNumberInputs=[p.obj('EditText',text='A1B2C')])
state['fields'].update(pickedUp=False)
vm.invoke(A+'->renderControls()V',[actor])
check(note['fields']['hint'],'店名/備註','known store has normal label')
check(note['fields']['text'],'小獅食堂｜不加辣','render retains known store')
state['fields'].update(storeName='',note='')
vm.invoke(A+'->renderControls()V',[actor])
check(note['fields']['hint'],'補填店名','missing store has visible prompt')
check(note['fields']['text'],'','missing-store hint never stored as merchant name')
check(actor['fields']['programmaticInputs'],False,'render restores watcher guard')
report={'checks':len(checks),'passed':True,'tests':checks,'method':'execution of changed DEX methods with mocked window extraction and Android API; unchanged merchant ranking preserved','physical_device_tested':False}
(ROOT/'store-tests.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'store flow checks against assembled DEX')
