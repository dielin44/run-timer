"""Execute the shipped DEX instructions with model objects and Android API stubs.

This checks the assembled accounting/card code, not a duplicate Python algorithm.
It does not claim a device or emulator test.
"""
import os,sys,struct,re,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent
os.environ['RUNLION_DEX_PATH']=str(ROOT/'classes-fixed.dex')
sys.path.insert(0,str(ROOT/'tests'))
import dex_inspect as d
A='Ltw/com/deliverylaw/timer/MainActivity;'
H='Ltw/com/deliverylaw/timer/OrderCardNumber;'
R='Ltw/com/deliverylaw/timer/MainActivity$OrderResult;'
S='Ltw/com/deliverylaw/timer/MainActivity$OrderState;'
T='Ltw/com/deliverylaw/timer/MainActivity$TripRecord;'
U='Ltw/com/deliverylaw/timer/MainActivity$TripSession;'
W='Ltw/com/deliverylaw/timer/MainActivity$21;'
METHODS={d.methods[i]:(co,{x[0]:x for x in d.dis(co)}) for c in [A,H,W] for i,_,co in d.classes[c] if co}
def obj(kind,**fields):return {'kind':kind,'fields':fields}
def signed(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
def eq(a,b):
 if isinstance(a,dict) or isinstance(b,dict):return a is b
 return (0 if a is None else a)==(0 if b is None else b)
class VM:
 def invoke(self,m,args):
  owner,name=m.split('->',1)
  if owner==A and name.startswith('access$'):
   f=args[0]['fields']
   if name.startswith('access$1600'):return f.get('programmaticInputs',False)
   if name.startswith('access$200('):return f.get('storageBlocked',False)
   if name.startswith('access$1700'):return f['slots']
   if name.startswith('access$1800'):return True
   if name.startswith('access$700'):f['saves']=f.get('saves',0)+1;return True
  # External APIs and unaffected platform-dependent amount/time helpers.
  if owner==A and name=='activeBaseOrderIncome('+S+'J)D':return 0.0 if args[1]['fields'].get('cancelled') else args[1]['fields'].get('actual',45.0)
  if owner==A and name=='nonOverlappingElapsed(Ljava/util/List;)J':return sum(x['fields'].get('elapsedMs',0) for x in args[1])
  if owner==A and name=='roundedKm(D)D':return round(args[1]/1000,1)
  if owner==A and name=='parseAmount(Ljava/lang/String;D)D':
   try:return float(args[1]) if args[1] else args[2]
   except ValueError:return args[2]
  if owner=='Ltw/com/deliverylaw/timer/RouteMerchantText;':
   def cleaned(value):return re.sub(r'^(?:(?:偏好設定|無法離線)[\s　|｜:：·•\-]*)+', '', (value or '').strip()).strip()
   if name.startswith('clean('):return cleaned(args[0])
   if name.startswith('label('):
    value=cleaned(args[0]);note=args[1] or ''
    return value+('｜'+note if note else '') if value else note
  if m in METHODS:return self.execute(m,args)
  if owner in ['Ljava/util/List;','Ljava/util/Collection;']:
   if name.startswith('iterator'):return obj('Iterator',items=args[0],index=0)
   if name.startswith('isEmpty'):return not args[0]
   if name.startswith('size'):return len(args[0])
  if owner=='Ljava/util/Iterator;':
   f=args[0]['fields']
   if name.startswith('hasNext'):return f['index']<len(f['items'])
   if name.startswith('next'):x=f['items'][f['index']];f['index']+=1;return x
  if owner=='Ljava/util/Map;':
   if name.startswith('values'):return list(args[0].values())
   if name.startswith('get'):return args[0].get(args[1])
  if owner=='Ljava/lang/Integer;' and name.startswith('valueOf'):return args[0]
  if owner=='Ljava/lang/Object;' and name.startswith('toString'):return str(args[0])
  if owner=='Ljava/lang/String;':
   if name.startswith('isEmpty'):return len(args[0])==0
   if name.startswith('trim'):return args[0].strip()
   if name.startswith('equals'):return args[0]==args[1]
   if name.startswith('matches'):return re.fullmatch(args[1],args[0]) is not None
   if name.startswith('replaceFirst'):return re.sub(args[1],args[2],args[0],count=1)
   if name.startswith('replaceAll'):return re.sub(args[1],args[2],args[0])
  if owner=='Ljava/lang/StringBuilder;':
   if name.startswith('<init>'):args[0]['fields']['value']=args[1] if len(args)>1 else '';return
   if name.startswith('append'):args[0]['fields']['value']+=str(args[1]);return args[0]
   if name.startswith('toString'):return args[0]['fields']['value']
  if owner=='Ljava/lang/Math;' and name.startswith('max'):return max(args)
  if owner=='Ltw/com/deliverylaw/timer/OrderIncomeCalculator;':
   if name.startswith('direct'):return max(45,args[0],args[1] if args[2] else 45)
   if name.startswith('batchTotal'):return max(args[0],args[1]) if args[2] else args[0]
   if name.startswith('batchOrder'):return max(45,args[0],args[4]-args[1]) if args[5] and args[2]>=args[3] else max(45,args[0])
  if owner=='Ltw/com/deliverylaw/timer/NetIncomeMetrics;':
   if name.startswith('incomeExcluding'):return args[0]-args[1]-args[2]
   if name.startswith('averageHourly'):return args[0]*3600000/args[1] if args[1] else float('nan')
   if name.startswith('averagePerMinute'):return args[0]*60000/args[1] if args[1] else float('nan')
  if owner.endswith('DailyOverview;') and name.startswith('<init>'):return
  if owner=='Landroid/widget/EditText;' and name.startswith('setText'):args[0]['fields']['text']=args[1];return
  if owner=='Landroid/widget/EditText;' and name.startswith('getText'):return args[0]['fields']['text']
  raise AssertionError('Unsupported API '+m)
 def execute(self,m,args):
  co,code=METHODS[m];regs,ins,_,_=struct.unpack_from('<HHHH',d.D,co)
  r=[0]*regs
  pos=regs-ins
  sig=m.split('(',1)[1].split(')',1)[0]
  desc=re.findall(r'\[*L[^;]+;|\[*[ZBSCIFJD]',sig)
  is_static=m.startswith(H+'->') or '->validOrderCount(' in m or m.startswith('Ltw/com/deliverylaw/timer/OrderGrabText;->')
  if not is_static:r[pos]=args[0];pos+=1;args=args[1:]
  assert len(args)==len(desc),(m,args,desc)
  for typ,value in zip(desc,args):r[pos]=value;pos+=2 if typ in ['D','J'] else 1
  assert pos==regs,(m,pos,regs)
  pc=0;last=None
  for _ in range(10000):
   at,op,w,detail=code[pc];next_pc=pc+len(w)
   if op==0:pass
   elif op in [0x01,0x04,0x07]:r[(w[0]>>8)&15]=r[(w[0]>>12)&15]
   elif op in [0x02,0x05,0x08]:r[w[0]>>8]=r[w[1]]
   elif op in [0x0a,0x0b,0x0c]:r[w[0]>>8]=last
   elif op==0x0e:return None
   elif op in [0x0f,0x10,0x11]:return r[w[0]>>8]
   elif op==0x12:r[(w[0]>>8)&15]=signed(w[0]>>12,4)
   elif op==0x13:r[w[0]>>8]=signed(w[1],16)
   elif op==0x14:r[w[0]>>8]=signed(w[1]+(w[2]<<16),32)
   elif op==0x15:r[w[0]>>8]=struct.unpack('<f',struct.pack('<I',w[1]<<16))[0]
   elif op==0x16:r[w[0]>>8]=signed(w[1],16)
   elif op==0x18:r[w[0]>>8]=struct.unpack('<d',struct.pack('<4H',*w[1:]))[0]
   elif op==0x1a:r[w[0]>>8]=d.strings[w[1]]
   elif op==0x1b:r[w[0]>>8]=d.strings[w[1]+(w[2]<<16)]
   elif op==0x1f:pass
   elif op==0x21:r[(w[0]>>8)&15]=len(r[(w[0]>>12)&15])
   elif op==0x22:r[w[0]>>8]=obj(d.types[w[1]])
   elif op==0x28:next_pc=pc+signed(w[0]>>8,8)
   elif op==0x29:next_pc=pc+signed(w[1],16)
   elif op==0x2a:next_pc=pc+signed(w[1]+(w[2]<<16),32)
   elif op==0x31:
    x,y=r[w[1]&255],r[w[1]>>8];r[w[0]>>8]=(x>y)-(x<y)
   elif op in range(0x32,0x38):
    x,y=r[(w[0]>>8)&15],r[(w[0]>>12)&15]
    take=[lambda:eq(x,y),lambda:not eq(x,y),lambda:x<y,lambda:x>=y,lambda:x>y,lambda:x<=y][op-0x32]()
    if take:next_pc=pc+signed(w[1],16)
   elif op in range(0x38,0x3e):
    x=r[w[0]>>8];take=[lambda:eq(x,0),lambda:not eq(x,0),lambda:x<0,lambda:x>=0,lambda:x>0,lambda:x<=0][op-0x38]()
    if take:next_pc=pc+signed(w[1],16)
   elif op==0x46:r[w[0]>>8]=r[w[1]&255][r[w[1]>>8]]
   elif op in range(0x52,0x59):
    field=d.fields[w[1]].split('->')[1].split(':')[0];r[(w[0]>>8)&15]=r[(w[0]>>12)&15]['fields'].get(field,0)
   elif op in range(0x59,0x60):
    field=d.fields[w[1]].split('->')[1].split(':')[0];r[(w[0]>>12)&15]['fields'][field]=r[(w[0]>>8)&15]
   elif op in [0x6e,0x6f,0x70,0x71,0x72]:
    count=w[0]>>12;ix=[w[2]&15,(w[2]>>4)&15,(w[2]>>8)&15,(w[2]>>12)&15,(w[0]>>8)&15][:count]
    callee=d.methods[w[1]];typs=re.findall(r'\[*L[^;]+;|\[*[ZBSCIFJD]',callee.split('(',1)[1].split(')',1)[0]);values=[];p=0
    if op!=0x71:values.append(r[ix[0]]);p=1
    for typ in typs:values.append(r[ix[p]]);p+=2 if typ in ['D','J'] else 1
    last=self.invoke(callee,values)
   elif op in [0x74,0x75,0x76,0x77,0x78]:
    count=w[0]>>8;ix=list(range(w[2],w[2]+count));callee=d.methods[w[1]];typs=re.findall(r'\[*L[^;]+;|\[*[ZBSCIFJD]',callee.split('(',1)[1].split(')',1)[0]);values=[];p=0
    if op!=0x77:values.append(r[ix[0]]);p=1
    for typ in typs:values.append(r[ix[p]]);p+=2 if typ in ['D','J'] else 1
    last=self.invoke(callee,values)
   elif op==0x83:r[(w[0]>>8)&15]=float(r[(w[0]>>12)&15])
   elif op==0xcb:r[(w[0]>>8)&15]+=r[(w[0]>>12)&15]
   elif op==0xcd:r[(w[0]>>8)&15]*=r[(w[0]>>12)&15]
   elif op==0xce:r[(w[0]>>8)&15]/=r[(w[0]>>12)&15]
   elif op==0xab:r[w[0]>>8]=r[w[1]&255]+r[w[1]>>8]
   elif op==0xb0:r[(w[0]>>8)&15]+=r[(w[0]>>12)&15]
   elif op==0xd8:r[w[0]>>8]=r[w[1]&255]+signed(w[1]>>8,8)
   elif op==0xdf:r[w[0]>>8]=r[w[1]&255]^signed(w[1]>>8,8)
   else:raise AssertionError('Unsupported opcode '+hex(op)+' in '+m+' at '+str(pc))
   pc=next_pc
  raise AssertionError('Execution budget exceeded '+m)

vm=VM();checks=[]
def check(actual,expected,label):
 assert actual==expected,(label,actual,expected)
 checks.append(label)
def order(cancelled=False,**kw):
 values=dict(cancelled=cancelled,batchAnchor=False,sequence=1,expectedAmount='45',lawAmount=45.0,tip='',cancelIncome='')
 values.update(kw);return obj(R,**values)
def record(orders,**kw):
 values=dict(orders=orders,batchCount=0,batchExpectedTotal='',lawTotal=0.0,expectedTotal='45',tipTotal=0.0,cancelIncome=0.0,activityBonus=0.0,tripMeters=0.0,elapsedMs=6000)
 values.update(kw);return obj(T,**values)
actor=obj(A,activeTrips={},slots=[],programmaticInputs=False,orderNumberInputs=[])
def call(name,*args):return vm.invoke(A+'->'+name,[actor,*args])
def overview(records):return call('calculateDailyOverview(Ljava/util/List;)Ltw/com/deliverylaw/timer/MainActivity$DailyOverview;',records)['fields']
for reason in ['系統取消','棄單／轉單','其他']:
 item=order(True,cancelReason=reason,tip='99')
 rec=record([item],tipTotal=99.0)
 check(call('recordOrderIncome('+T+')D',rec),0.0,reason+' clears expected income')
 check(call('recordFinalIncome('+T+')D',rec),0.0,reason+' clears stale tips')
 over=overview([rec]);check(over.get('tripCount',0),0,reason+' trip count');check(over['orderCount'],0,reason+' order count');check(over['totalIncome'],0.0,reason+' overview income')
rec=record([order(True)],cancelIncome=25.0)
check(call('recordFinalIncome('+T+')D',rec),25.0,'explicit cancellation compensation retained')
check(overview([rec]).get('tripCount',0),0,'compensation never counts as delivery')
valid=order(False,expectedAmount='120',tip='30',sequence=2)
rec=record([order(True,tip='99'),valid],tipTotal=129,activityBonus=25)
check(call('recordOrderIncome('+T+')D',rec),120.0,'mixed direct income')
check(call('recordFinalIncome('+T+')D',rec),175.0,'mixed tip and activity income')
over=overview([rec]);check(over['tripCount'],1,'mixed trip count');check(over['orderCount'],1,'mixed order count');check(over['totalTips'],30.0,'mixed tips');check(over['averageHourlyExcludingBonusAndTips'],72000.0,'hourly uses corrected net income')
for cancelled_sequence in [1,2]:
 orders=[order(i==cancelled_sequence,batchAnchor=True,sequence=i) for i in [1,2]]
 rec=record(orders,batchCount=2,batchExpectedTotal='200')
 check(call('recordOrderIncome('+T+')D',rec),100.0,'mixed batch income '+str(cancelled_sequence))
 for item in orders:check(call('recordDisplayedOrderIncome('+T+R+')D',rec,item),0.0 if item['fields']['cancelled'] else 100.0,'batch card matches sum '+str(cancelled_sequence)+'/'+str(item['fields']['sequence']))
rec=record([order(True,batchAnchor=True,sequence=i) for i in [1,2,3]],batchCount=3,batchExpectedTotal='300',tipTotal=99)
check(call('recordFinalIncome('+T+')D',rec),0.0,'all batch orders cancelled')
check(overview([rec]).get('tripCount',0),0,'all batch cancelled trip count')
rec=record([order(batchAnchor=True,sequence=i) for i in [1,2,3]],batchCount=3,batchExpectedTotal='200')
check(call('recordOrderIncome('+T+')D',rec),200.0,'unchanged successful batch total')
check(sum(call('recordDisplayedOrderIncome('+T+R+')D',rec,x) for x in rec['fields']['orders']),200.0,'successful batch cards add to total')
legacy=record([],expectedTotal='50',lawTotal=60,tipTotal=10)
check(call('recordFinalIncome('+T+')D',legacy),70.0,'legacy summary-only record preserved')
check(overview([legacy])['tripCount'],1,'legacy trip retained')
# Live and persisted completed orders are counted once, and other trips ignored.
cancelled=order(True,batchAnchor=True,sequence=1)
live=obj(S,active=True,resultSaved=False,cancelled=False,batchAnchor=True,tripId=1,sequence=2,expectedAmount='',actual=45,tip='10')
session=obj(U,id=1,completed=[cancelled],batchCount=2,batchExpectedTotal='200')
actor['fields'].update(activeTrips={1:session},slots=[live])
check(call('activeOrderIncome(J)D',0),100.0,'live partial batch income')
check(call('displayedActiveOrderIncome('+S+'J)D',live,0),100.0,'live partial batch card')
check(call('activeTipIncome()D'),10.0,'live tips')
live['fields']['cancelled']=True
check(call('activeOrderIncome(J)D',0),0.0,'live all cancelled income')
check(call('activeTipIncome()D'),0.0,'live cancelled tips')
actor['fields'].update(activeTrips={1:obj(U,id=1,completed=[order(True,tip='99')],batchCount=0,batchExpectedTotal='')},slots=[])
check(call('activeOrderIncome(J)D',0),0.0,'live saved direct cancellation')
check(call('activeTipIncome()D'),0.0,'live saved direct cancellation tips')
for platform,ref,num,expected in [('熊貓','2726','abcd-12345678','#2726，abcd-12345678'),('熊貓','#2726','abcd-12345678','#2726，abcd-12345678'),('熊貓','','abcd-12345678','abcd-12345678'),('熊貓',None,'abcd-12345678','abcd-12345678'),('熊貓','abc','abcd-12345678','abcd-12345678'),('Uber','2726','A1B2C','A1B2C'),('熊貓','0007','long-id','#0007，long-id'),('熊貓','# 2726','long-id','#2726，long-id')]:
 check(vm.invoke(H+'->display(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;',[platform,ref,num]),expected,'display '+str((platform,ref)))
for value,expected in [('#2726，abcd-12345678','abcd-12345678'),('#2726, abcd-12345678','abcd-12345678'),(' A1B2C ','A1B2C'),('#A1B2C','#A1B2C'),(None,'')]:
 check(vm.invoke(H+'->raw(Ljava/lang/String;)Ljava/lang/String;',[value]),expected,'raw id '+str(value))
edit=obj('EditText',text='')
state=obj(S,platform='熊貓',platformReference='2726',orderNumber='full-id',active=True,finished=False)
actor['fields'].update(slots=[state],orderNumberInputs=[edit])
call('setOrderNumberText(ILjava/lang/String;)V',0,'full-id')
check(edit['fields']['text'],'#2726，full-id','card receives composed display')
check(actor['fields']['programmaticInputs'],False,'display update restores input guard')
call('syncOrderNumbersFromInputs()V')
check(state['fields']['orderNumber'],'full-id','save strips display prefix')
check(state['fields']['platformReference'],'2726','save retains separate panda reference')
watcher=obj(W,**{'this$0':actor,'val$i':0})
vm.invoke(W+'->afterTextChanged(Landroid/text/Editable;)V',[watcher,'#2726，new-full-id'])
check(state['fields']['orderNumber'],'new-full-id','editing card saves raw full number')
check(state['fields']['platformReference'],'2726','editing retains panda reference')
check(actor['fields']['saves'],1,'manual edit saved once')
actor['fields']['programmaticInputs']=True
vm.invoke(W+'->afterTextChanged(Landroid/text/Editable;)V',[watcher,'#2726，do-not-save'])
check(state['fields']['orderNumber'],'new-full-id','programmatic display never overwrites raw number')
check(actor['fields']['saves'],1,'programmatic display avoids extra save')
report={'checks':len(checks),'passed':True,'tests':checks,'method':'execution of assembled DEX instructions with API stubs','device_tested':False,'emulator_tested':False}
(ROOT/'test-results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('PASS',len(checks),'checks against assembled DEX')
