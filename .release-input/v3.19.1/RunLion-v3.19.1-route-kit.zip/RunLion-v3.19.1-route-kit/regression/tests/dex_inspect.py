import zipfile,struct,sys,os
from pathlib import Path
D=Path(os.environ['RUNLION_DEX_PATH']).read_bytes() if 'RUNLION_DEX_PATH' in os.environ else zipfile.ZipFile('accessibility-input/跑單大獅-v3.18.2.apk').read('classes.dex')
def u32(p):return struct.unpack_from('<I',D,p)[0]
def uleb(p):
 v=0;s=0
 while True:
  b=D[p];p+=1;v|=(b&127)<<s
  if b<128:return v,p
  s+=7
strings=[]
for i in range(u32(56)):
 p=u32(u32(60)+i*4);_,p=uleb(p);e=D.index(0,p);strings.append(D[p:e].decode('utf8','replace'))
types=[strings[u32(u32(68)+i*4)] for i in range(u32(64))]
protos=[]
for i in range(u32(72)):
 p=u32(76)+i*12;off=u32(p+8)
 args=[] if not off else [types[struct.unpack_from('<H',D,off+4+j*2)[0]] for j in range(u32(off))]
 protos.append('('+''.join(args)+')'+types[u32(p+4)])
fields=[]
for i in range(u32(80)):
 c,t,n=struct.unpack_from('<HHI',D,u32(84)+i*8);fields.append(types[c]+'->'+strings[n]+':'+types[t])
methods=[]
for i in range(u32(88)):
 c,p,n=struct.unpack_from('<HHI',D,u32(92)+i*8);methods.append(types[c]+'->'+strings[n]+protos[p])
classes={}
for i in range(u32(96)):
 p=u32(100)+i*32;ci=u32(p);cd=u32(p+24)
 if not cd:continue
 sz=[]
 for _ in range(4):v,cd=uleb(cd);sz.append(v)
 for n in sz[:2]:
  ix=0
  for _ in range(n):di,cd=uleb(cd);ac,cd=uleb(cd);ix+=di
 result=[]
 for n in sz[2:]:
  ix=0
  for _ in range(n):
   di,cd=uleb(cd);ac,cd=uleb(cd);co,cd=uleb(cd);ix+=di;result.append((ix,ac,co))
 classes[types[ci]]=result
widths={}
for a,b,n in [(0x01,0x01,1),(0x02,0x02,2),(0x03,0x03,3),(0x04,0x04,1),(0x05,0x05,2),(0x06,0x06,3),(0x07,0x07,1),(0x08,0x08,2),(0x09,0x09,3),(0x0a,0x12,1),(0x13,0x13,2),(0x14,0x14,3),(0x15,0x16,2),(0x17,0x17,3),(0x18,0x18,5),(0x19,0x1a,2),(0x1b,0x1b,3),(0x1c,0x1c,2),(0x1d,0x1e,1),(0x1f,0x20,2),(0x21,0x21,1),(0x22,0x23,2),(0x24,0x26,3),(0x27,0x28,1),(0x29,0x29,2),(0x2a,0x2c,3),(0x2d,0x3d,2),(0x44,0x6d,2),(0x6e,0x72,3),(0x74,0x78,3),(0x7b,0x8f,1),(0x90,0xaf,2),(0xb0,0xcf,1),(0xd0,0xe2,2),(0xfa,0xfb,4),(0xfc,0xfd,3),(0xfe,0xff,2)]:
 for op in range(a,b+1):widths[op]=n
def dis(co):
 if not co:return []
 regs,ins,outs,tries=struct.unpack_from('<HHHH',D,co);size=u32(co+12);w=struct.unpack_from('<'+'H'*size,D,co+16);i=0;result=[]
 while i<size:
  op=w[i]&255;n=widths.get(op,1);detail=''
  if op==0:
   if w[i]==0x100:n=4+2*w[i+1]
   elif w[i]==0x200:n=2+4*w[i+1]
   elif w[i]==0x300:n=4+(w[i+1]*(w[i+2]+(w[i+3]<<16))+1)//2
  if op==0x1a:detail=repr(strings[w[i+1]])
  elif op==0x1b:detail=repr(strings[w[i+1]+(w[i+2]<<16)])
  elif op in [0x1c,0x1f,0x20,0x22,0x23]:detail=types[w[i+1]]
  elif 0x52<=op<=0x6d:detail=fields[w[i+1]]
  elif op in [0x6e,0x6f,0x70,0x71,0x72,0x74,0x75,0x76,0x77,0x78]:detail=methods[w[i+1]]
  result.append((i,op,w[i:i+n],detail));i+=n
 return result
if __name__=='__main__':
 for name in ['Ltw/com/deliverylaw/timer/OrderGrabAccessibilityService;','Ltw/com/deliverylaw/timer/OrderGrabActivity;','Ltw/com/deliverylaw/timer/OrderGrabTextController;']:
  for ix,ac,co in classes[name]:
   m=methods[ix]
   wanted=any(x in m.split('->')[1].split('(')[0] for x in ['isConnected','isEnabled','onInterrupt','onDestroy','onServiceConnected','start','resume','Resume','direct','Direct','launch','Launch'])
   if not wanted:continue
   print('\nMETHOD',ix,m,'ACCESS',ac,'CODE_OFF',co)
   if co:print('HEADER',struct.unpack_from('<HHHHII',D,co))
   for at,op,ws,detail in dis(co): print(f'{at:04x}',f'{op:02x}',' '.join(f'{x:04x}' for x in ws),detail)
