"""Execute the patched DEX control flow against a minimal Android API harness.

This is an instruction interpreter for the changed methods, not a copied
implementation or a phone/emulator test. Unsupported instructions fail closed.
"""
import os,struct,sys,json
from pathlib import Path
os.environ.setdefault('RUNLION_DEX_PATH','accessibility-work/classes-fixed.dex')
sys.path.insert(0,str(Path(__file__).parent))
import dex_inspect as d

A='Ltw/com/deliverylaw/timer/OrderGrabActivity;'
P='Ltw/com/deliverylaw/timer/OrderGrabConnectionProbe;'
S='Ltw/com/deliverylaw/timer/OrderGrabAccessibilityService;'
COMPONENT='tw.com.deliverylaw.timer/tw.com.deliverylaw.timer.OrderGrabAccessibilityService'
METHODS={d.methods[i]:(co,dict((x[0],x) for x in d.dis(co))) for c in [A,P,S] for i,_,co in d.classes[c] if co}
def signed(n,b):return n-(1<<b) if n&(1<<(b-1)) else n
def obj(kind,**fields):return {'kind':kind,'fields':fields}
def eq(a,b):
 if isinstance(a,dict) or isinstance(b,dict):return a is b
 return (0 if a is None else a)==(0 if b is None else b)
class APIError(Exception):pass
class Harness:
 def __init__(self,setting=COMPONENT,bound=False,query_error=False):
  self.setting=setting;self.bound=bound;self.query_error=query_error;self.queue=[]
  self.started=0;self.session_finished=0;self.dialogs=[];self.begin_ok=True;self.homes=0
  self.actor=obj(A,token='keep-this-order',status=obj('TextView',text=''),direct=obj('Button',text='',enabled=True),directActive=False)
 def component(self,s):
  if '/' not in s:return None
  pkg,cls=s.split('/',1)
  if not cls:return None
  return (pkg,pkg+cls if cls.startswith('.') else cls)
 def invoke(self,m,args):
  if m==S+'->begin(Ljava/lang/String;)Z':self.started+=1;return self.bound and self.begin_ok
  if m in METHODS:return self.execute(m,args)
  owner,name=m.split('->',1)
  if owner=='Landroid/content/Context;' and name.startswith('getContentResolver'):return obj('ContentResolver')
  if owner=='Landroid/provider/Settings$Secure;':
   if self.query_error:raise APIError('secure setting unavailable')
   assert args[1]=='enabled_accessibility_services';return self.setting
  if owner=='Landroid/content/ComponentName;':
   if name.startswith('<init>'):args[0]['fields']['component']=self.component(COMPONENT);return
   if name.startswith('unflattenFromString'):return self.component(args[0])
   if name.startswith('equals'):return args[0]['fields']['component']==args[1]
  if owner=='Ljava/lang/String;' and name.startswith('split'):return args[0].split(args[1])
  if owner=='Landroid/os/Looper;':return obj('Looper')
  if owner=='Landroid/os/Handler;':
   if name.startswith('<init>'):return
   if name.startswith('postDelayed'):self.queue.append((args[1],args[2]));return 1
   if name.startswith('removeCallbacks'):self.queue=[q for q in self.queue if q[0] is not args[1]];return
  if owner in ['Landroid/widget/TextView;','Landroid/widget/Button;']:
   key='text' if name.startswith('setText(') else 'enabled' if name.startswith('setEnabled(') else None
   assert key is not None,m;args[0]['fields'][key]=args[1];return
  if owner in ['Landroid/app/Activity;',A]:
   if name.startswith('isFinishing'):return args[0]['fields'].get('finished',False)
   if name.startswith('isDestroyed'):return args[0]['fields'].get('destroyed',False)
   if name.startswith('onResume') or name.startswith('onPause') or name.startswith('<init>'):return
   if name.startswith('startActivity'):self.homes+=1;return
   if name=='finish()V':args[0]['fields']['finished']=True;return
  if owner=='Landroid/app/AlertDialog$Builder;':
   if name.startswith('<init>'):return
   if name.startswith('setTitle'):args[0]['fields']['title']=args[1]
   if name.startswith('show'):self.dialogs.append(args[0]['fields'].get('title'));return obj('AlertDialog')
   return args[0]
  if owner=='Landroid/content/Intent;':return args[0]
  if name.startswith('<init>') and owner in ['Ljava/lang/Object;','Ltw/com/deliverylaw/timer/OrderGrabActivity$$ExternalSyntheticLambda3;']:return
  if owner=='Ltw/com/deliverylaw/timer/OrderGrabSession;':self.session_finished+=1;return 1
  raise AssertionError('Unsupported API: '+m)
 def catch(self,co,pc):
  regs,ins,outs,tries=struct.unpack_from('<HHHH',d.D,co);n=d.u32(co+12)
  if not tries:raise APIError('uncaught')
  start=co+16+n*2+(2 if n&1 else 0);base=start+tries*8
  for i in range(tries):
   at,length,off=struct.unpack_from('<IHH',d.D,start+i*8)
   if at<=pc<at+length:
    p=base+off;size=shift=0
    while True:
     b=d.D[p];p+=1;size|=(b&127)<<shift;shift+=7
     if b<128:break
    if b&64:size-=1<<shift
    for _ in range(abs(size)):
     typ,p=d.uleb(p);address,p=d.uleb(p)
     if d.types[typ]=='Ljava/lang/RuntimeException;':return address
    if size<=0:address,p=d.uleb(p);return address
  raise APIError('no matching catch')
 def execute(self,m,args):
  co,code=METHODS[m];regs,ins,_,_=struct.unpack_from('<HHHH',d.D,co)
  r=[0]*regs;r[regs-ins:]=args;assert len(r)==regs,(m,args,regs,ins)
  pc=0;last=None;exception=None
  for _ in range(2000):
   at,op,w,detail=code[pc];n=len(w);next_pc=pc+n
   try:
    if op==0:pass
    elif op in [0x01,0x04,0x07]:r[(w[0]>>8)&15]=r[(w[0]>>12)&15]
    elif op in [0x02,0x05,0x08]:r[w[0]>>8]=r[w[1]]
    elif op in [0x0a,0x0b,0x0c]:r[w[0]>>8]=last
    elif op==0x0d:r[w[0]>>8]=exception
    elif op==0x0e:return None
    elif op in [0x0f,0x10,0x11]:return r[w[0]>>8]
    elif op==0x12:r[(w[0]>>8)&15]=signed(w[0]>>12,4)
    elif op==0x13:r[w[0]>>8]=signed(w[1],16)
    elif op==0x14:r[w[0]>>8]=signed(w[1]+(w[2]<<16),32)
    elif op==0x16:r[w[0]>>8]=signed(w[1],16);r[(w[0]>>8)+1]=0
    elif op==0x1a:r[w[0]>>8]=d.strings[w[1]]
    elif op==0x1b:r[w[0]>>8]=d.strings[w[1]+(w[2]<<16)]
    elif op==0x1c:r[w[0]>>8]=d.types[w[1]]
    elif op==0x1f:pass
    elif op==0x21:r[(w[0]>>8)&15]=len(r[(w[0]>>12)&15])
    elif op==0x22:r[w[0]>>8]=obj(d.types[w[1]])
    elif op==0x28:next_pc=pc+signed(w[0]>>8,8)
    elif op==0x29:next_pc=pc+signed(w[1],16)
    elif op in range(0x32,0x38):
     x,y=r[(w[0]>>8)&15],r[(w[0]>>12)&15]
     take=[lambda:eq(x,y),lambda:not eq(x,y),lambda:x<y,lambda:x>=y,lambda:x>y,lambda:x<=y][op-0x32]()
     if take:next_pc=pc+signed(w[1],16)
    elif op in range(0x38,0x3e):
     x=r[w[0]>>8]
     take=[lambda:eq(x,0),lambda:not eq(x,0),lambda:x<0,lambda:x>=0,lambda:x>0,lambda:x<=0][op-0x38]()
     if take:next_pc=pc+signed(w[1],16)
    elif op==0x46:r[w[0]>>8]=r[w[1]&255][r[w[1]>>8]]
    elif op in range(0x52,0x59):
     field=d.fields[w[1]].split('->')[1].split(':')[0];r[(w[0]>>8)&15]=r[(w[0]>>12)&15]['fields'].get(field,0)
    elif op in range(0x59,0x60):
     field=d.fields[w[1]].split('->')[1].split(':')[0];r[(w[0]>>12)&15]['fields'][field]=r[(w[0]>>8)&15]
    elif op==0x62:
     assert d.fields[w[1]]==S+'->instance:'+S
     r[w[0]>>8]=obj(S) if self.bound else None
    elif op in [0x6e,0x6f,0x70,0x71,0x72]:
     count=w[0]>>12;indexes=[w[2]&15,(w[2]>>4)&15,(w[2]>>8)&15,(w[2]>>12)&15,(w[0]>>8)&15][:count]
     last=self.invoke(d.methods[w[1]],[r[i] for i in indexes])
    elif op==0xd8:r[w[0]>>8]=r[w[1]&255]+signed(w[1]>>8,8)
    elif op==0xdf:r[w[0]>>8]=r[w[1]&255]^signed(w[1]>>8,8)
    else:raise AssertionError('Unsupported opcode '+hex(op)+' in '+m)
   except APIError as err:exception=err;next_pc=self.catch(co,pc)
   pc=next_pc
  raise AssertionError('Execution budget exceeded: '+m)
 def call(self,name,*args):return self.invoke(A+'->'+name,[self.actor,*args])
 def tick(self):
  p,delay=self.queue.pop(0);assert delay==250;self.invoke(P+'->run()V',[p])
 def drain(self):
  for _ in range(30):
   if not self.queue:return
   self.tick()
  raise AssertionError('Unbounded retry')
 @property
 def text(self):return self.actor['fields']['status']['fields']['text']
 @property
 def enabled(self):return bool(self.actor['fields']['direct']['fields']['enabled'])

checks=0
def check(x,msg):
 global checks
 assert x,msg;checks+=1

for setting,expected in [(None,0),('',0),(COMPONENT,1),('tw.com.deliverylaw.timer/.OrderGrabAccessibilityService',1),('x/y:'+COMPONENT,1),('tw.com.deliverylaw.timer/OtherService',0),('evil.pkg/tw.com.deliverylaw.timer.OrderGrabAccessibilityService',0),('malformed:'+COMPONENT,1)]:
 h=Harness(setting=setting);check(h.invoke(P+'->state(Landroid/content/Context;)I',[h.actor])==expected,'exact component matching')
h=Harness(query_error=True);check(h.invoke(P+'->state(Landroid/content/Context;)I',[h.actor])==3,'query failure distinguished')
h=Harness(setting=None,bound=True,query_error=True);check(h.invoke(P+'->state(Landroid/content/Context;)I',[h.actor])==2,'live service takes precedence')

h=Harness();h.call('onResume()V');check('已開啟' in h.text and not h.dialogs,'enabled state recognized on resume')
h.bound=True;h.tick();check(h.started==0 and h.enabled,'resume polling never starts capture');check('已連線' in h.text,'late binding updates status')

h=Harness();h.call('onResume()V');h.call('startText()V');check(not h.enabled and not h.dialogs,'explicit start waits without enable dialog')
h.bound=True;h.tick();check(h.started==1 and h.homes==1,'pending explicit start resumes after binding');check(not h.queue,'retry cancelled after success')

h=Harness();h.call('onResume()V');h.call('startText()V');h.call('startText()V');check(len(h.queue)==1,'duplicate starts replace existing probe');h.bound=True;h.tick();check(h.started==1,'duplicate wait does not duplicate begin')

h=Harness();h.call('onResume()V');h.call('startText()V');h.call('onPause()V');check(not h.queue,'pause removes callback');h.bound=True;check(h.started==0,'paused page does not start');check(h.actor['fields']['token']=='keep-this-order','pause retains input token')

h=Harness();h.call('onResume()V');h.call('startText()V');h.drain();check(h.started==0 and h.session_finished==0 and h.enabled,'timeout retains session and permits retry');check('已開啟' in h.text and '尚未連線' in h.text,'timeout explains actual enabled state');check(not h.dialogs,'timeout never shows disabled consent');h.call('startText()V');h.bound=True;h.tick();check(h.started==1,'retry after timeout can start')

h=Harness(query_error=True);h.call('onResume()V');h.call('startText()V');h.drain();check('無法確認' in h.text and '尚未開啟' not in h.text,'query failure never falsely declares disabled')
h=Harness(setting=None);h.call('onResume()V');h.call('startText()V');check(h.dialogs==['啟用直接抓單'] and not h.queue and h.started==0,'actually disabled retains consent/settings flow')
h=Harness();h.call('onResume()V');h.call('startText()V');h.setting=None;h.tick();check(not h.queue and h.enabled and h.started==0,'disable during wait stops pending start')
h=Harness(bound=True);h.begin_ok=False;h.call('onResume()V');h.call('startText()V');check(h.started==1 and h.session_finished==0 and not h.actor['fields'].get('finished'),'begin failure keeps page/session');check('原輸入保留' in h.text,'begin failure retains input hint')

print('PASS',checks,'checks against assembled DEX; no phone/emulator claims')
Path(os.environ.get('RUNLION_CONNECTION_REPORT','accessibility-work/connection-tests.json')).write_text(json.dumps({'checks':checks,'passed':True,'method':'patched DEX instruction interpreter with mocked Android API','device_tested':False},ensure_ascii=False,indent=2)+'\n')
