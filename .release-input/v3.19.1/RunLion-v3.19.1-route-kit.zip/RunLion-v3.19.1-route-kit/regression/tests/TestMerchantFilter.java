import java.util.*;
class TestMerchantFilter {
  static String oldPattern = "(?:導航|開始導航|結束導航|返回導航|開啟導航|路線|地圖|目前位置|左轉|右轉|直行|繼續直行|迴轉|靠左|靠右|目的地|確認訂單|完成取單|完成取餐|顯示更多|商家|餐廳|地址|備註|店家照片|商家照片|照片|圖片)";
  static String newPattern = "(?:導航|開始導航|結束導航|返回導航|開啟導航|路線|地圖|目前位置|左轉|右轉|直行|繼續直行|迴轉|靠左|靠右|目的地|確認訂單|完成取[單餐]|顯示更多|商家|餐廳|地址|備註|(?:[店商]家)?照片|圖片|無法離線)(?:|)";
  static int checks;
  static void check(boolean condition, String name) {checks++; if(!condition) throw new AssertionError(name);}
  static String firstTitle(String... lines) {
    for(String line:lines) for(String s:line.split("\\n")) {
      s=s.trim(); if(!s.isEmpty() && !s.matches(newPattern)) return s;
    }
    return "";
  }
  public static void main(String[] args) {
    for(String s:new String[] {"導航","開始導航","結束導航","返回導航","開啟導航","路線","地圖","目前位置","左轉","右轉","直行","繼續直行","迴轉","靠左","靠右","目的地","確認訂單","完成取單","完成取餐","顯示更多","商家","餐廳","地址","備註","店家照片","商家照片","照片","圖片"}) {
      check(s.matches(oldPattern), "old label "+s);
      check(s.matches(newPattern), "preserved exclusion "+s);
    }
    check(!"無法離線".matches(oldPattern), "reproduce old defect");
    check("無法離線".matches(newPattern), "exclude offline warning");
    for(String s:new String[] {"東海商圈 掌門人雞蛋糕","掌門人雞蛋糕","雞蛋糕 (中山路店)","麥當勞 台中中港店","Louisa Coffee","無法離線小吃","無法離線餐廳","阿寶早午餐","胖老爹美式炸雞","清心福全 河南店"}) check(!s.matches(newPattern), "retain store "+s);
    check(firstTitle("無法離線", "掌門人雞蛋糕").equals("掌門人雞蛋糕"), "warning before store");
    check(firstTitle("導航", "無法離線", "雞蛋糕 (中山路店)", "地址").equals("雞蛋糕 (中山路店)"), "navigation and branch");
    check(firstTitle("無法離線\n掌門人雞蛋糕").equals("掌門人雞蛋糕"), "parent node with line break");
    check(firstTitle("無法離線", "導航").equals(""), "warning only never becomes store");
    check(firstTitle("無法離線", "Louisa Coffee").equals("Louisa Coffee"), "Latin name after warning");
    check(firstTitle("無法離線", "  東海商圈 掌門人雞蛋糕  ").equals("東海商圈 掌門人雞蛋糕"), "trimmed long name");
    check(firstTitle("無法離線小吃").equals("無法離線小吃"), "exact status exclusion avoids deleting longer shop names");
    System.out.println("PASS MerchantStatusFilter: "+checks+" checks");
  }
}
