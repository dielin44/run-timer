"""Narrow hooks: preserve GPS filtering, mileage and accounting implementation."""
from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
ORIGINAL=ROOT/'original-smali/tw/com/deliverylaw/timer'
OUTPUT=ROOT/'patched-smali/tw/com/deliverylaw/timer'
OUTPUT.mkdir(parents=True,exist_ok=True)
for generated in OUTPUT.glob('*.smali'):generated.unlink()
changes=[]
def edit(filename,signature,transform):
 p=OUTPUT/(filename+'.smali');source=p.read_text() if p.exists() else (ORIGINAL/(filename+'.smali')).read_text()
 pattern=r'(?ms)^\.method '+re.escape(signature)+r'\n.*?^\.end method'
 m=re.search(pattern,source);assert m,signature
 before=m.group();after=transform(before);assert before!=after
 p.write_text(source[:m.start()]+after+source[m.end():]);changes.append(filename+'->'+signature)
def once(source,old,new):
 assert source.count(old)==1,(old,source.count(old));return source.replace(old,new,1)
edit('MainActivity','private buildScreen()V',lambda s:once(s,
 '    invoke-virtual {v0, v1}, Ltw/com/deliverylaw/timer/MainActivity;->setContentView(Landroid/view/View;)V',
 '    invoke-static {v0, v1}, Ltw/com/deliverylaw/timer/RouteTraceUi;->install(Landroid/app/Activity;Landroid/view/View;)V\n\n    invoke-virtual {v0, v1}, Ltw/com/deliverylaw/timer/MainActivity;->setContentView(Landroid/view/View;)V'))
edit('MainActivity','private showMiniMapSettings()V',lambda s:once(s,
 '    .line 1061\n    invoke-direct {v8, v1}, Ltw/com/deliverylaw/timer/MainActivity;->dp(I)I',
 '    invoke-static {v8, v0}, Ltw/com/deliverylaw/timer/RouteTraceUi;->settings(Landroid/app/Activity;Landroid/widget/LinearLayout;)V\n\n    .line 1061\n    invoke-direct {v8, v1}, Ltw/com/deliverylaw/timer/MainActivity;->dp(I)I'))
edit('MainActivity','private saveState(Ljava/lang/String;)Z',lambda s:once(s,
 '    iput-wide v2, p0, Ltw/com/deliverylaw/timer/MainActivity;->stateRevision:J',
 '    iput-wide v2, p0, Ltw/com/deliverylaw/timer/MainActivity;->stateRevision:J\n\n    iget-object v2, p1, Ltw/com/deliverylaw/timer/RunStateStore$Snapshot;->payload:Ljava/lang/String;\n\n    invoke-static {p0, v2}, Ltw/com/deliverylaw/timer/RouteTrace;->sync(Landroid/content/Context;Ljava/lang/String;)V'))
edit('MainActivity','private toggleGpsMonitoring()V',lambda s:once(s,
 '    invoke-static {p0}, Ltw/com/deliverylaw/timer/SpeedMonitorStore;->clearProjection(Landroid/content/Context;)V',
 '    invoke-static {p0}, Ltw/com/deliverylaw/timer/RouteTrace;->gap(Landroid/content/Context;)V\n\n    invoke-static {p0}, Ltw/com/deliverylaw/timer/SpeedMonitorStore;->clearProjection(Landroid/content/Context;)V'))
edit('MainActivity','public onRequestPermissionsResult(I[Ljava/lang/String;[I)V',lambda s:re.sub(r'(    \.registers \d+\n)',r'\1\n    invoke-static {p0, p1}, Ltw/com/deliverylaw/timer/RouteTrace;->permissionResult(Landroid/app/Activity;I)V\n',s,count=1))
edit('TrackingService','public onLocationChanged(Landroid/location/Location;)V',lambda s:once(s,
 '    iput-wide v14, v0, Ltw/com/deliverylaw/timer/TrackingService;->lastAcceptedFixElapsed:J',
 '    iput-wide v14, v0, Ltw/com/deliverylaw/timer/TrackingService;->lastAcceptedFixElapsed:J\n\n    invoke-static/range {p0 .. p1}, Ltw/com/deliverylaw/timer/RouteTrace;->record(Landroid/content/Context;Landroid/location/Location;)V'))
for signature in ['public onDestroy()V','public onProviderDisabled(Ljava/lang/String;)V']:
 edit('TrackingService',signature,lambda s:re.sub(r'(    \.registers \d+\n)',r'\1\n    invoke-static {p0}, Ltw/com/deliverylaw/timer/RouteTrace;->gap(Landroid/content/Context;)V\n',s,count=1))
edit('TrackingService','public onStartCommand(Landroid/content/Intent;II)I',lambda s:once(s,
 '    invoke-static {p0, v1}, Ltw/com/deliverylaw/timer/TrackingStore;->reconcile(Landroid/content/Context;Ljava/lang/String;)V',
 '    invoke-static {p0, v1}, Ltw/com/deliverylaw/timer/TrackingStore;->reconcile(Landroid/content/Context;Ljava/lang/String;)V\n\n    invoke-static {p0, v1}, Ltw/com/deliverylaw/timer/RouteTrace;->sync(Landroid/content/Context;Ljava/lang/String;)V'))
edit('TrackingService','private notification()Landroid/app/Notification;',lambda s:once(s,
 '    invoke-virtual {v1, v0}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;',
 '    invoke-static {p0, v0}, Ltw/com/deliverylaw/timer/RouteTrace;->notificationLine(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;\n\n    move-result-object v0\n\n    invoke-virtual {v1, v0}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;'))
edit('MainActivity','private createOrderCard(I)Landroid/widget/LinearLayout;',lambda s:once(s,
 '    .line 692\n    iget-object v5, v0, Ltw/com/deliverylaw/timer/MainActivity;->noteInputs:[Landroid/widget/EditText;\n\n    aget-object v5, v5, v1\n\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setTextColor(I)V',
 '    .line 692\n    iget-object v5, v0, Ltw/com/deliverylaw/timer/MainActivity;->noteInputs:[Landroid/widget/EditText;\n\n    aget-object v5, v5, v1\n\n    const/4 v8, -0x1\n\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setTextColor(I)V'))
edit('MainActivity','synthetic lambda$showOrderStoreForm$10$tw-com-deliverylaw-timer-MainActivity(IJILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z',lambda s:once(s,
 '    iput-object p6, v0, Ltw/com/deliverylaw/timer/MainActivity$OrderState;->storeName:Ljava/lang/String;',
 '    invoke-static {p6}, Ltw/com/deliverylaw/timer/RouteMerchantText;->clean(Ljava/lang/String;)Ljava/lang/String;\n\n    move-result-object p6\n\n    iput-object p6, v0, Ltw/com/deliverylaw/timer/MainActivity$OrderState;->storeName:Ljava/lang/String;'))
edit('MainActivity','private orderStoreLabel(Ltw/com/deliverylaw/timer/MainActivity$OrderState;)Ljava/lang/String;',lambda s:'''\
.method private orderStoreLabel(Ltw/com/deliverylaw/timer/MainActivity$OrderState;)Ljava/lang/String;
    .registers 4
    iget-object v0, p1, Ltw/com/deliverylaw/timer/MainActivity$OrderState;->storeName:Ljava/lang/String;
    iget-object v1, p1, Ltw/com/deliverylaw/timer/MainActivity$OrderState;->note:Ljava/lang/String;
    invoke-static {v0, v1}, Ltw/com/deliverylaw/timer/RouteMerchantText;->label(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method''')
def sanitize_returns(source,method,kind):
 pattern=r'(?m)^(    return-object (v\d+))$'
 def change(m):
  r=m.group(2);return '    invoke-static/range {'+r+' .. '+r+'}, Ltw/com/deliverylaw/timer/RouteMerchantText;->'+method+'('+kind+')'+kind+'\n\n    move-result-object '+r+'\n\n'+m.group(1)
 result,count=re.subn(pattern,change,source);assert count>0;return result
edit('OrderGrabMerchant','public static find(Ljava/util/List;Ljava/util/List;)Ltw/com/deliverylaw/timer/OrderGrabMerchant$Selection;',lambda s:sanitize_returns(s,'selection','Ltw/com/deliverylaw/timer/OrderGrabMerchant$Selection;'))
for signature in ['public static parse(Ljava/util/List;Ljava/lang/String;)Ltw/com/deliverylaw/timer/OrderGrabParser$Result;','public static parseRegion(Ljava/util/List;Ljava/lang/String;I)Ltw/com/deliverylaw/timer/OrderGrabParser$Result;']:
 edit('OrderGrabParser',signature,lambda s:sanitize_returns(s,'result','Ltw/com/deliverylaw/timer/OrderGrabParser$Result;'))
(ROOT/'hook-changes.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2)+'\n')
print('Patched',len(changes),'methods')
