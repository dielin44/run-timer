package tw.com.deliverylaw.timer;
import java.util.List;
public final class OrderGrabMerchant {public static final class Selection {public final String storeName;public final List<String> candidates;public Selection(String s,List<String> c){storeName=s;candidates=c;}}}
