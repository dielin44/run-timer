package tw.com.deliverylaw.timer;
import android.content.Context;
import android.graphics.Bitmap;
final class MapTileCache {static MapTileCache get(Context c){return null;}Bitmap tile(int z,int x,int y,Runnable r){return null;}}
