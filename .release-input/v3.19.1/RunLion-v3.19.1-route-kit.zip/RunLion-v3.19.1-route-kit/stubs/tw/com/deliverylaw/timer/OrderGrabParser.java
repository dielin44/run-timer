package tw.com.deliverylaw.timer;
import java.util.List;
public final class OrderGrabParser {public static final class Result {public final String platform,storeName,reference;public final List<String> numbers;public Result(String p,String s,String r,List<String> n){platform=p;storeName=s;reference=r;numbers=n;}}}
