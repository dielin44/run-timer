package tw.com.deliverylaw.timer;
import android.content.Context;
final class SpeedMonitorStore {static boolean gpsEnabled(Context c){return false;}static boolean setGpsEnabled(Context c,boolean v){return false;}}
