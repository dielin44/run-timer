package tw.com.deliverylaw.timer;
import android.content.Context;
final class RunStateStore {static RunStateStore get(Context c){return null;}Snapshot read(){return null;}static final class Snapshot {final String payload;Snapshot(){payload=null;}}}
