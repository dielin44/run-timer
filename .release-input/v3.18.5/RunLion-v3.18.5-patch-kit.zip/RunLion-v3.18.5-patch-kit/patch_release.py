from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parent
A='Ltw/com/deliverylaw/timer/MainActivity;'
S='Ltw/com/deliverylaw/timer/MainActivity$OrderState;'
C='Ltw/com/deliverylaw/timer/OrderGrabTextController;'
D='Ltw/com/deliverylaw/timer/OrderGrabDraft;'
M='Ltw/com/deliverylaw/timer/OrderGrabMerchant;'
SELECT='Ltw/com/deliverylaw/timer/OrderGrabMerchant$Selection;'
changes=[]
def replace_method(text,name,fn):
 pattern=r'(?ms)^\.method [^\n]*\b'+re.escape(name)+r'\([^\n]*\n.*?^\.end method'
 m=re.search(pattern,text);assert m,name
 new=fn(m.group());assert new!=m.group(),name
 changes.append(name)
 return text[:m.start()]+new+text[m.end():]
def swap(b,old,new):
 assert b.count(old)==1,(old,b.count(old));return b.replace(old,new)
src=ROOT/'original-smali/tw/com/deliverylaw/timer';dst=ROOT/'patched-smali/tw/com/deliverylaw/timer';dst.mkdir(parents=True,exist_ok=True)
text=(src/'OrderGrabText.smali').read_text()
def read(b):
 # Number scope continues to control IDs; visible store titles are always read.
 start=b.index('    :cond_e2\n');end=b.index('    .line 112\n',start)
 return b[:start]+f'    :cond_e2\n    invoke-static {{p0, v1}}, {M}->find(Ljava/util/List;Ljava/util/List;){SELECT}\n    move-result-object p0\n\n'+b[end:]
text=replace_method(text,'read',read);(dst/'OrderGrabText.smali').write_text(text)
text=(src/'OrderGrabTextController.smali').read_text()
def confirm(b):
 return f'''.method synthetic lambda$start$6$tw-com-deliverylaw-timer-OrderGrabTextController()V
    .registers 4
    iget-object v0, p0, {C}->draft:{D}
    iget-object v1, v0, {D}->storeName:Ljava/lang/String;
    invoke-virtual {{v1}}, Ljava/lang/String;->isEmpty()Z
    move-result v1
    if-eqz v1, :complete
    iget-object v1, p0, {C}->storeChoices:Ljava/util/ArrayList;
    invoke-virtual {{v1}}, Ljava/util/ArrayList;->isEmpty()Z
    move-result v1
    if-nez v1, :missing
    const-string v1, "請先點選正確的店名；已讀到的單號會保留"
    invoke-direct {{p0, v1}}, {C}->update(Ljava/lang/String;)V
    invoke-direct {{p0}}, {C}->show()V
    return-void
    :missing
    const-string v1, "已帶入單號；未讀到店名，請在店名欄補填，或回到店名畫面再抓一次"
    goto :apply
    :complete
    const-string v1, "請確認單號與店名，正確後儲存"
    :apply
    const/4 v2, 0x1
    invoke-virtual {{p0, v0, v1, v2}}, {C}->close({D}Ljava/lang/String;Z)V
    return-void
.end method'''
text=replace_method(text,'lambda$start$6$tw-com-deliverylaw-timer-OrderGrabTextController',confirm);(dst/'OrderGrabTextController.smali').write_text(text)
text=(src/'MainActivity.smali').read_text()
def hints(b):
 marker='    .line 3092\n'
 return swap(b,marker,f'''    iget-boolean v6, v3, {S}->active:Z
    if-eqz v6, :normal_store_hint
    iget-object v6, v3, {S}->storeName:Ljava/lang/String;
    invoke-virtual {{v6}}, Ljava/lang/String;->isEmpty()Z
    move-result v6
    if-eqz v6, :normal_store_hint
    const-string v7, "補填店名"
    goto :set_store_hint
    :normal_store_hint
    const-string v7, "店名/備註"
    :set_store_hint
    iget-object v6, p0, {A}->noteInputs:[Landroid/widget/EditText;
    aget-object v6, v6, v0
    invoke-virtual {{v6, v7}}, Landroid/widget/EditText;->setHint(Ljava/lang/CharSequence;)V

'''+marker)
text=replace_method(text,'renderControls',hints)
def wrapping(b):
 old='    invoke-virtual {v5, v4}, Landroid/widget/EditText;->setSingleLine(Z)V'
 return swap(b,old,'    const/4 v8, 0x0\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setSingleLine(Z)V\n    const/4 v8, 0x2\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setMaxLines(I)V')
text=replace_method(text,'createOrderCard',wrapping)
def saving(b):
 b=swap(b,'    :cond_34\n',f'    :cond_34\n    iget-boolean v2, p0, {A}->programmaticInputs:Z\n    iput-boolean v3, p0, {A}->programmaticInputs:Z\n    :store_ui_start\n')
 old='    return v3\n\n    .line 3518'
 new=f'''    :store_ui_end
    .catchall {{:store_ui_start .. :store_ui_end}} :store_ui_failure
    iput-boolean v2, p0, {A}->programmaticInputs:Z
    return v3
    :store_ui_failure
    move-exception p1
    iput-boolean v2, p0, {A}->programmaticInputs:Z
    throw p1

    .line 3518'''
 return swap(b,old,new)
text=replace_method(text,'lambda$showOrderStoreForm$10$tw-com-deliverylaw-timer-MainActivity',saving);(dst/'MainActivity.smali').write_text(text)
(ROOT/'changes.json').write_text(json.dumps(changes,indent=2)+'\n')
print('Patched',len(changes),'methods')
