"""Build RunLion 3.18.5 from the signed intact 3.18.4 release, retaining resources."""
from pathlib import Path
import argparse,hashlib,io,json,os,struct,subprocess,sys,zipfile,zlib
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import apk_tools as apk
BASE_SHA256='833f9d7c4fe4bcb1d5ada67323b7f1c3b271d3dbb582cb01db60454d1324ee65'
def run(command,**kwargs):
 r=subprocess.run(command,check=True,capture_output=True,text=True,**kwargs)
 if r.stdout.strip():print(r.stdout.strip())
 return r.stdout
def manifest(data):
 b=bytearray(data);pool=apk.manifest_pool(b);strings=[x[0] for x in pool];p=8;changes=[];report={}
 while p<len(b):
  kind,header,size=struct.unpack_from('<HHI',b,p)
  if kind==0x102:
   ext=p+header;tag=strings[apk.u32(b,ext+4)];start,stride,n=struct.unpack_from('<HHH',b,ext+8)
   for i in range(n):
    at=ext+start+i*stride;name=strings[apk.u32(b,at+4)];typ,value=b[at+15],apk.u32(b,at+16)
    if tag=='manifest' and name=='versionCode':
     assert typ==0x10 and value==60;struct.pack_into('<I',b,at+16,61);changes.append((at+16,at+20));report['version_code']=61
    elif tag=='manifest' and name=='versionName':
     assert typ==3;old,q,nbytes,encoding=pool[value];assert old=='3.18.4';new='3.18.5'.encode(encoding);assert len(new)==nbytes;b[q:q+nbytes]=new;changes.append((q,q+nbytes));report['version_name']='3.18.5'
    elif tag=='manifest' and name=='package':
     assert typ==3 and strings[value]=='tw.com.deliverylaw.timer';report['package']=strings[value]
  p+=size
 assert len(changes)==2 and len(b)==len(data)
 assert all(x==y or any(start<=i<end for start,end in changes) for i,(x,y) in enumerate(zip(b,data)))
 return bytes(b),report
def build(args):
 base=Path(args.base).read_bytes();assert hashlib.sha256(base).hexdigest()==BASE_SHA256
 assert apk.verify_v2(base)==[apk.CERT_SHA256]
 tools=Path(args.tool_dir).resolve();deps=json.loads((ROOT/'DEPENDENCIES.json').read_text())['jars']
 for dep in deps:assert hashlib.sha256((tools/dep['name']).read_bytes()).hexdigest()==dep['sha256'],dep['name']
 cp=':'.join(str(tools/x['name']) for x in sorted(deps,key=lambda x:'fat' in x['name']))
 with zipfile.ZipFile(io.BytesIO(base)) as z:
  assert z.testzip() is None;original=z.read('classes.dex');new_manifest,version=manifest(z.read('AndroidManifest.xml'))
 (ROOT/'classes-original.dex').write_bytes(original)
 names='Ltw/com/deliverylaw/timer/MainActivity;,Ltw/com/deliverylaw/timer/OrderGrabText;,Ltw/com/deliverylaw/timer/OrderGrabTextController;'
 run(['java','-cp',cp,'org.jf.baksmali.Main','disassemble','--classes',names,'-o',str(ROOT/'original-smali'),str(ROOT/'classes-original.dex')])
 run([sys.executable,str(ROOT/'patch_release.py')])
 run(['java','-cp',cp,'org.jf.smali.Main','assemble','--api','24','-o',str(ROOT/'patched.dex'),str(ROOT/'patched-smali')])
 preservation=run(['java','-cp',cp,str(ROOT/'MergeStoreDex.java'),str(ROOT/'classes-original.dex'),str(ROOT/'patched.dex'),str(ROOT/'classes-fixed.dex')])
 dex=(ROOT/'classes-fixed.dex').read_bytes()
 assert dex[:8]==original[:8] and apk.u32(dex,32)==len(dex)
 assert dex[12:32]==hashlib.sha1(dex[32:]).digest() and apk.u32(dex,8)==zlib.adler32(dex[12:])&0xffffffff
 assert apk.NEW_PATTERN.encode() in dex
 assert apk.u32(dex,88)<65536 and apk.u32(dex,64)<65536
 run([sys.executable,str(ROOT/'test_store_dex.py')]);tests=json.loads((ROOT/'test-results.json').read_text());storetests=json.loads((ROOT/'store-tests.json').read_text())
 env=os.environ.copy();env['RUNLION_DEX_PATH']=str(ROOT/'classes-fixed.dex');env['RUNLION_CONNECTION_REPORT']=str(ROOT/'connection-tests.json')
 run([sys.executable,str(ROOT/'tests/test_connection_dex.py')],env=env)
 connection=json.loads((ROOT/'connection-tests.json').read_text())
 merchant=run(['java',str(ROOT/'tests/TestMerchantFilter.java')]);assert '75 checks' in merchant
 unsigned=apk.rebuild_zip(base,{'classes.dex':dex,'AndroidManifest.xml':new_manifest})
 key,cert=apk.export_key(args.keystore,args.signing_info)
 signed=apk.sign_v2(unsigned,key,cert);assert apk.verify_v2(signed)==[apk.CERT_SHA256]
 tampered=bytearray(signed);tampered[50]^=1
 try:apk.verify_v2(tampered)
 except AssertionError:pass
 else:raise AssertionError('Tampered signature accepted')
 preserved=0;native=[]
 with zipfile.ZipFile(io.BytesIO(base)) as before,zipfile.ZipFile(io.BytesIO(signed)) as after:
  assert after.testzip() is None
  for info in after.infolist():
   if info.filename not in ('classes.dex','AndroidManifest.xml'):assert before.read(info.filename)==after.read(info.filename);preserved+=1
   if info.compress_type==0:
    n,e=struct.unpack_from('<HH',signed,info.header_offset+26);offset=info.header_offset+30+n+e
    assert offset%(16384 if info.filename.endswith('.so') else 4)==0
    if info.filename.endswith('.so'):native.append(info.filename)
  assert after.read('classes.dex')==dex and after.read('AndroidManifest.xml')==new_manifest
 out=Path(args.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(signed)
 report={**version,'apk':out.name,'sha256':hashlib.sha256(signed).hexdigest(),'size_bytes':len(signed),'base_sha256':BASE_SHA256,
  'certificate_sha256':apk.CERT_SHA256,'verified_signature_scheme':'v2','tampered_signature_rejected':True,
  'zip_integrity':True,'stored_entry_alignment':True,'native_16kb_zip_alignment':native,'unchanged_noncode_entries':preserved,
  'dex_preservation_check':preservation.strip(),'accounting_and_card_checks':tests,'merchant_flow_checks':storetests,'connection_flow_checks':connection,
  'merchant_status_filter_checks':75,'physical_device_tested':False,'emulator_tested':False,
  'full_original_source_archive_available':False,'scope':'Number reads also recognize merchant names visible in the allowed foreground window. Require selection when merchant candidates remain ambiguous; explicitly explain missing merchant names. Merchant card permits two lines and a missing-name hint; guard programmatic store display against input watchers. Existing ranking, platform restrictions, cancellation accounting and Panda card fixes retained.'}
 Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['version_name','version_code','sha256','size_bytes','verified_signature_scheme']},ensure_ascii=False))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base',required=True);p.add_argument('--tool-dir',required=True);p.add_argument('--keystore',required=True);p.add_argument('--signing-info',required=True);p.add_argument('--output',required=True);p.add_argument('--report',required=True);build(p.parse_args())
