# 跑單大獅 v3.18.5 店名流程修正

基底：完整且已簽署的 v3.18.4 APK。套件名稱維持 tw.com.deliverylaw.timer，版本 3.18.5 / versionCode 61，使用原簽章，可直接更新並保留資料。

## 修正

- 「讀單號」原本完全跳過店名辨識。現在所有文字讀取模式都會在已授權的熊貓／Uber 前景視窗查找可見店名；單號仍遵守原本各模式的讀取範圍。
- 店名有多個候選且尚未選擇時，確認按鍵會提示先選店名，並保留已讀到的單號。已選店名可正常帶回輸入彈窗。
- 視窗裡沒有可辨識店名時，回到輸入彈窗會明確提示「未讀到店名」與補填方式。卡片空白店名欄顯示「補填店名」，不會把提示文字當成店名存入。
- 店名／備註欄允許兩行顯示。保存後更新店名文字時加上程式輸入保護，避免文字監聽又修改已保存資料，結束或例外時恢復原保護狀態。
- 保留原有店名排序、地址／導航／無法離線等排除規則、兩平台限制、使用者觸發讀取及無障礙流程。
- 保留 v3.18.4 取消單統計與熊貓「#編號，完整單號」顯示修正。

## 驗證

39 項店名流程檢查執行組譯後 DEX 指令，涵蓋各讀取模式、禁止平台、候選確認、部分讀取、保存到卡片、單號與店名分存、文字監聽保護及缺少店名提示。視窗文字抽取及平台 API 使用替身；原有店名排序未改動。

另通過 64 項取消單／熊貓編號檢查、30 項無障礙流程檢查及 75 項店名排除檢查，共 208 項。确认 8,498 個其他類別及 397 個其他方法不變，只修改 5 個方法，未新增類別。502 個非程式資源內容保留。

驗證 DEX、ZIP、原 APK v2 簽章、竄改拒絕、4 byte 與原生程式庫 ZIP 16 KiB 對齊。VERIFICATION.json 記錄交付 APK 的大小、SHA-256 與詳細結果。

尚未在手機或模擬器實測。使用者截圖顯示卡片店名空白，無法單靠該圖確認 Uber 原畫面是否暴露店名文字、使用了哪個讀取模式或是否有候選未選。這版修正可確認的讀取漏點與顯示流程，未宣稱已在該手機重現全部原因。若平台完全不提供可讀店名，仍需滑到店名可見位置再讀或手動填寫。

## 重建

這是以完整 APK 針對性修補的可重建套件，不是完整 Java 專案。套件不含私鑰、密碼或建置工具 JAR。

需要 Java 17、Python 3.10 以上、Git 及 Python cryptography。工具版本、來源與 SHA-256 在 DEPENDENCIES.json。

```bash
python3 download_dependencies.py tools
python3 build_release.py \
  --base /absolute/path/RunLion-v3.18.4.apk \
  --tool-dir tools \
  --keystore /absolute/path/RunLion-signing.jks \
  --signing-info /absolute/path/RunLion-signing-info.txt \
  --output /absolute/path/RunLion-v3.18.5.apk \
  --report /absolute/path/VERIFICATION.json
```
