from pathlib import Path
import re,shutil,json
ROOT=Path(__file__).resolve().parent
A='Ltw/com/deliverylaw/timer/MainActivity;'
R='Ltw/com/deliverylaw/timer/MainActivity$OrderResult;'
S='Ltw/com/deliverylaw/timer/MainActivity$OrderState;'
T='Ltw/com/deliverylaw/timer/MainActivity$TripRecord;'
U='Ltw/com/deliverylaw/timer/MainActivity$TripSession;'
H='Ltw/com/deliverylaw/timer/OrderCardNumber;'
out=ROOT/'patched-smali/tw/com/deliverylaw/timer';out.mkdir(parents=True,exist_ok=True)
s=(ROOT/'original-smali/tw/com/deliverylaw/timer/MainActivity.smali').read_text()
changed=[]
def edit(name,fn):
 global s
 pattern=r'(?ms)^\.method [^\n]*\b'+re.escape(name)+r'\([^\n]*\n.*?^\.end method'
 m=re.search(pattern,s);assert m,name
 new=fn(m.group());assert new!=m.group(),name
 s=s[:m.start()]+new+s[m.end():];changed.append(name)
def swap(body,old,new):
 assert body.count(old)==1,(old,body.count(old));return body.replace(old,new)
def record_income(b):
 b=swap(b,'    .line 2962\n',f'    iget-boolean v8, v7, {R}->cancelled:Z\n    if-nez v8, :goto_2a\n\n    .line 2962\n')
 old=f'    invoke-direct {{p0, v0, v1, v2}}, {A}->parseAmount(Ljava/lang/String;D)D\n\n    move-result-wide v0\n\n    iget-object p1'
 new=f'    invoke-direct {{p0, p1}}, {A}->recordBatchExpected({T})D\n\n    move-result-wide v0\n\n    iget-object p1'
 return swap(b,old,new)
edit('recordOrderIncome',record_income)
def active_income(b):
 b=swap(b,'    .line 3186\n',f'    iget-boolean v15, v14, {R}->cancelled:Z\n    if-nez v15, :goto_52\n\n    .line 3186\n')
 b=swap(b,'    .line 3198\n',f'    iget-boolean v3, v14, {S}->cancelled:Z\n    if-nez v3, :goto_77\n\n    .line 3198\n')
 old=f'    invoke-direct {{v0, v3, v4, v5}}, {A}->parseAmount(Ljava/lang/String;D)D\n\n    move-result-wide v14'
 return swap(b,old,f'    invoke-direct {{v0, v8}}, {A}->activeBatchExpected({U})D\n\n    move-result-wide v14')
edit('activeOrderIncome',active_income)
def overview(b):
 marker='    .line 3393\n'
 b=swap(b,marker,f'    iget-object v3, v2, {T}->orders:Ljava/util/List;\n    const/4 v4, 0x0\n    invoke-static {{v3, v4}}, {A}->validOrderCount(Ljava/util/List;Z)I\n    move-result v3\n    if-gtz v3, :count_trip\n    iget-object v3, v2, {T}->orders:Ljava/util/List;\n    invoke-interface {{v3}}, Ljava/util/List;->isEmpty()Z\n    move-result v3\n    if-eqz v3, :after_count_trip\n    :count_trip\n\n'+marker)
 b=swap(b,'    .line 3394\n','    :after_count_trip\n\n    .line 3394\n')
 old='    invoke-interface {v2}, Ljava/util/List;->size()I\n\n    move-result v2'
 return swap(b,old,f'    const/4 v4, 0x0\n    invoke-static {{v2, v4}}, {A}->validOrderCount(Ljava/util/List;Z)I\n\n    move-result v2')
edit('calculateDailyOverview',overview)
def active_tips(b):
 b=swap(b,f'    iget-object v6, v6, {R}->tip:Ljava/lang/String;',f'    iget-boolean v7, v6, {R}->cancelled:Z\n    if-nez v7, :goto_1f\n    iget-object v6, v6, {R}->tip:Ljava/lang/String;')
 return swap(b,f'    iget-object v7, v7, {S}->tip:Ljava/lang/String;',f'    iget-boolean v8, v7, {S}->cancelled:Z\n    if-nez v8, :cond_4a\n    iget-object v7, v7, {S}->tip:Ljava/lang/String;')
edit('activeTipIncome',active_tips)
# Use recalculated tips for old records, screen totals, speech and exports.
reads=re.compile(r'    iget-wide (\w+), (\w+), '+re.escape(T)+r'->tipTotal:D')
for m in list(re.finditer(r'(?ms)^\.method [^\n]*\n.*?^\.end method',s)):
 if reads.search(m.group()):
  name=m.group().splitlines()[0].split('(')[0].split()[-1]
  def replace_tips(b):
   alias=re.search(r'    move-object/from16 (v\d+), p0',b)
   receiver=alias[1] if alias else 'p0'
   return reads.sub(lambda x:f'    invoke-direct {{{receiver}, {x[2]}}}, {A}->eligibleRecordTips({T})D\n    move-result-wide {x[1]}',b)
  edit(name,replace_tips)
def displayed(b):
 # The remaining batch guarantee and last-order allocation use surviving anchors.
 b=swap(b,'    move-wide v5, v1', '    move-wide v5, v1\n    const/4 v10, 0x1')
 b=swap(b,f'    iget-boolean v8, v7, {R}->batchAnchor:Z',f'    iget-boolean v8, v7, {R}->cancelled:Z\n    if-nez v8, :cond_1b\n    iget-boolean v8, v7, {R}->batchAnchor:Z')
 b=swap(b,'    .line 2991\n','    add-int/lit8 v10, v10, 0x1\n\n    .line 2991\n')
 b=swap(b,f'    iget v7, p2, {R}->sequence:I\n\n    iget v8, p1, {T}->batchCount:I',f'    move v7, v10\n    iget-object v8, p1, {T}->orders:Ljava/util/List;\n    const/4 v9, 0x1\n    invoke-static {{v8, v9}}, {A}->validOrderCount(Ljava/util/List;Z)I\n    move-result v8')
 return swap(b,f'    invoke-direct {{p0, p2, v1, v2}}, {A}->parseAmount(Ljava/lang/String;D)D\n\n    move-result-wide v9',f'    invoke-direct {{p0, p1}}, {A}->recordBatchExpected({T})D\n\n    move-result-wide v9')
edit('recordDisplayedOrderIncome',displayed)
def displayed_active(b):
 b=swap(b,'    move-wide v8, v3','    move-wide v8, v3\n    const/4 v3, 0x1')
 b=swap(b,f'    iget-boolean v11, v10, {R}->batchAnchor:Z',f'    iget-boolean v11, v10, {R}->cancelled:Z\n    if-nez v11, :cond_35\n    iget-boolean v11, v10, {R}->batchAnchor:Z')
 b=swap(b,'    .line 3235\n','    add-int/lit8 v3, v3, 0x1\n\n    .line 3235\n')
 b=swap(b,f'    iget-boolean v13, v12, {S}->batchAnchor:Z',f'    iget-boolean v13, v12, {S}->cancelled:Z\n    if-nez v13, :cond_79\n    iget-boolean v13, v12, {S}->batchAnchor:Z')
 b=swap(b,'    move-wide/from16 v13, p2\n\n    .line 3240','    add-int/lit8 v3, v3, 0x1\n    move-wide/from16 v13, p2\n\n    .line 3240')
 b=swap(b,f'    iget v1, v1, {S}->sequence:I\n\n    iget v10, v2, {U}->batchCount:I',f'    move v1, v3\n    invoke-direct {{v0, v2}}, {A}->activeBatchCount({U})I\n    move-result v10')
 return swap(b,f'    invoke-direct {{v0, v7, v3, v4}}, {A}->parseAmount(Ljava/lang/String;D)D\n\n    move-result-wide v11',f'    invoke-direct {{v0, v2}}, {A}->activeBatchExpected({U})D\n\n    move-result-wide v11')
edit('displayedActiveOrderIncome',displayed_active)
def cached_income(b):
 marker=f'    iput-wide v0, p0, {A}->lastCompletedActivityBonus:D'
 return swap(b,marker,marker+f'\n    invoke-direct {{p0, v5}}, {A}->recordOrderIncome({T})D\n    move-result-wide v0\n    iput-wide v0, p0, {A}->lastCompletedLaw:D\n    invoke-direct {{p0, v5}}, {A}->eligibleRecordTips({T})D\n    move-result-wide v0\n    iput-wide v0, p0, {A}->lastCompletedTip:D')
edit('recalculateAllActivityBonuses',cached_income)
def number_set(b):
 # Expand locals; p registers remain symbolic.
 b=swap(b,'    .registers 5','    .registers 7')
 b=swap(b,'    :try_start_5\n',f'    :try_start_5\n    iget-object v2, p0, {A}->slots:[{S}\n    aget-object v2, v2, p1\n    iget-object v3, v2, {S}->platform:Ljava/lang/String;\n    iget-object v2, v2, {S}->platformReference:Ljava/lang/String;\n    invoke-static {{v3, v2, p2}}, {H}->display(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;\n    move-result-object p2\n')
 return b
edit('setOrderNumberText',number_set)
def sync_number(b):
 return swap(b,f'    iput-object v2, v1, {S}->orderNumber:Ljava/lang/String;',f'    invoke-static {{v2}}, {H}->raw(Ljava/lang/String;)Ljava/lang/String;\n    move-result-object v2\n    iput-object v2, v1, {S}->orderNumber:Ljava/lang/String;')
edit('syncOrderNumbersFromInputs',sync_number)
def card(b):
 old='    invoke-virtual {v5, v4}, Landroid/widget/EditText;->setSingleLine(Z)V'
 assert b.count(old)==2
 b=b.replace(old, '    const/4 v8, 0x0\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setSingleLine(Z)V\n    const/4 v8, 0x2\n    invoke-virtual {v5, v8}, Landroid/widget/EditText;->setMaxLines(I)V',1)
 return b
edit('createOrderCard',card)
extra=f'''
.method private static validOrderCount(Ljava/util/List;Z)I
    .registers 6
    const/4 v0, 0x0
    invoke-interface {{p0}}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v1
    :loop
    invoke-interface {{v1}}, Ljava/util/Iterator;->hasNext()Z
    move-result v2
    if-eqz v2, :done
    invoke-interface {{v1}}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v2
    check-cast v2, {R}
    iget-boolean v3, v2, {R}->cancelled:Z
    if-nez v3, :loop
    if-eqz p1, :count
    iget-boolean v3, v2, {R}->batchAnchor:Z
    if-eqz v3, :loop
    :count
    add-int/lit8 v0, v0, 0x1
    goto :loop
    :done
    return v0
.end method

.method private scaleBatchExpected(Ljava/lang/String;II)D
    .registers 9
    const-wide/16 v0, 0x0
    if-lez p2, :zero
    if-lez p3, :zero
    invoke-direct {{p0, p1, v0, v1}}, {A}->parseAmount(Ljava/lang/String;D)D
    move-result-wide v0
    int-to-double v2, p2
    mul-double/2addr v0, v2
    int-to-double v2, p3
    div-double/2addr v0, v2
    :zero
    return-wide v0
.end method

.method private recordBatchExpected({T})D
    .registers 7
    iget-object v0, p1, {T}->orders:Ljava/util/List;
    const/4 v1, 0x1
    invoke-static {{v0, v1}}, {A}->validOrderCount(Ljava/util/List;Z)I
    move-result v1
    iget-object v0, p1, {T}->batchExpectedTotal:Ljava/lang/String;
    iget v2, p1, {T}->batchCount:I
    invoke-direct {{p0, v0, v1, v2}}, {A}->scaleBatchExpected(Ljava/lang/String;II)D
    move-result-wide v0
    return-wide v0
.end method

.method private activeBatchExpected({U})D
    .registers 12
    iget-object v0, p1, {U}->completed:Ljava/util/List;
    const/4 v1, 0x1
    invoke-static {{v0, v1}}, {A}->validOrderCount(Ljava/util/List;Z)I
    move-result v0
    iget-object v1, p0, {A}->slots:[{S}
    array-length v2, v1
    const/4 v3, 0x0
    :loop
    if-ge v3, v2, :done
    aget-object v4, v1, v3
    iget-boolean v5, v4, {S}->active:Z
    if-eqz v5, :next
    iget-boolean v5, v4, {S}->resultSaved:Z
    if-nez v5, :next
    iget-boolean v5, v4, {S}->cancelled:Z
    if-nez v5, :next
    iget-boolean v5, v4, {S}->batchAnchor:Z
    if-eqz v5, :next
    iget v5, v4, {S}->tripId:I
    iget v6, p1, {U}->id:I
    if-ne v5, v6, :next
    add-int/lit8 v0, v0, 0x1
    :next
    add-int/lit8 v3, v3, 0x1
    goto :loop
    :done
    iget-object v1, p1, {U}->batchExpectedTotal:Ljava/lang/String;
    iget v2, p1, {U}->batchCount:I
    invoke-direct {{p0, v1, v0, v2}}, {A}->scaleBatchExpected(Ljava/lang/String;II)D
    move-result-wide v0
    return-wide v0
.end method

.method private eligibleRecordTips({T})D
    .registers 10
    iget-object v0, p1, {T}->orders:Ljava/util/List;
    invoke-interface {{v0}}, Ljava/util/List;->isEmpty()Z
    move-result v1
    if-eqz v1, :orders
    iget-wide v0, p1, {T}->tipTotal:D
    return-wide v0
    :orders
    invoke-interface {{v0}}, Ljava/util/List;->iterator()Ljava/util/Iterator;
    move-result-object v0
    const-wide/16 v1, 0x0
    const-wide/16 v3, 0x0
    :loop
    invoke-interface {{v0}}, Ljava/util/Iterator;->hasNext()Z
    move-result v5
    if-eqz v5, :done
    invoke-interface {{v0}}, Ljava/util/Iterator;->next()Ljava/lang/Object;
    move-result-object v5
    check-cast v5, {R}
    iget-boolean v6, v5, {R}->cancelled:Z
    if-nez v6, :loop
    iget-object v5, v5, {R}->tip:Ljava/lang/String;
    invoke-direct {{p0, v5, v3, v4}}, {A}->parseAmount(Ljava/lang/String;D)D
    move-result-wide v5
    add-double/2addr v1, v5
    goto :loop
    :done
    return-wide v1
.end method
'''
s+='\n'+extra
# Share the same surviving-anchor count with the per-card allocation.
active_counter=re.search(r'(?ms)^\.method private activeBatchExpected\([^\n]*\n.*?^\.end method',extra).group()
active_counter=active_counter.replace('activeBatchExpected('+U+')D','activeBatchCount('+U+')I')
active_counter=active_counter[:active_counter.index('    :done\n')]+'    :done\n    return v0\n.end method\n'
s+='\n'+active_counter
(out/'MainActivity.smali').write_text(s)
w=(ROOT/'original-smali/tw/com/deliverylaw/timer/MainActivity$21.smali').read_text()
marker='    .line 679\n'
w=swap(w,marker,f'    invoke-static {{p1}}, {H}->raw(Ljava/lang/String;)Ljava/lang/String;\n    move-result-object p1\n\n'+marker)
(out/'MainActivity$21.smali').write_text(w)
changed.append('MainActivity$21.afterTextChanged')
(ROOT/'changes.json').write_text(json.dumps(changed,indent=2))
print('Patched',len(changed),'methods')
