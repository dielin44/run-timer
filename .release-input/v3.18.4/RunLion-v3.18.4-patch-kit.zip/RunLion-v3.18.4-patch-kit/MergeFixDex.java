import java.nio.file.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import org.jf.dexlib2.iface.*;
import org.jf.dexlib2.dexbacked.*;
import org.jf.dexlib2.writer.pool.*;
import org.jf.dexlib2.writer.io.*;
import org.jf.baksmali.*;
import org.jf.baksmali.Adaptors.*;
import org.jf.baksmali.formatter.*;

class MergeFixDex {
  static final String A="Ltw/com/deliverylaw/timer/MainActivity;";
  static final String W="Ltw/com/deliverylaw/timer/MainActivity$21;";
  static final String H="Ltw/com/deliverylaw/timer/OrderCardNumber;";
  static final Set<String> EDITED=Set.of("recordOrderIncome","activeOrderIncome","calculateDailyOverview","activeTipIncome","exportSelectedDateImage","finalizeTrip","recordFinalIncome","writeExcel","recordDisplayedOrderIncome","displayedActiveOrderIncome","setOrderNumberText","syncOrderNumbersFromInputs","createOrderCard","recalculateAllActivityBonuses");
  static final Set<String> ADDED=Set.of("validOrderCount","scaleBatchExpected","recordBatchExpected","activeBatchExpected","eligibleRecordTips","activeBatchCount");
  static String dump(ClassDef c) throws Exception {
    var s=new StringWriter(); var w=new BaksmaliWriter(s);
    new ClassDefinition(new BaksmaliOptions(),c).writeTo(w); w.flush(); return s.toString();
  }
  static String normalized(ClassDef c) throws Exception {
    return dump(c).replaceAll("(?m)^(\\.field [^\\n]+) = (?:false|null|0x0|0x0L|0\\.0f|0\\.0)$", "$1");
  }
  static Map<String,String> methods(String text) {
    Map<String,String> out=new TreeMap<>();
    var m=Pattern.compile("(?ms)^\\.method ([^\\n]+)\\n.*?^\\.end method").matcher(text);
    while(m.find()) {if(out.put(m.group(1),m.group())!=null)throw new AssertionError("Duplicate method");}
    return out;
  }
  static String name(String signature) {return signature.substring(0,signature.indexOf('(')).replaceAll("^.* ","");}
  static void require(boolean b,String msg) {if(!b)throw new AssertionError(msg);}
  public static void main(String[] a) throws Exception {
    var base=new DexBackedDexFile(null,Files.readAllBytes(Path.of(a[0])));
    var delta=new DexBackedDexFile(base.getOpcodes(),Files.readAllBytes(Path.of(a[1])));
    Map<String,ClassDef> changed=new TreeMap<>();
    for(var c:delta.getClasses())changed.put(c.getType(),c);
    require(changed.keySet().equals(Set.of(A,W,H)),"Unexpected patch classes");
    var pool=new DexPool(base.getOpcodes());int originalCount=0;
    for(var c:base.getClasses()) {originalCount++;pool.internClass(changed.getOrDefault(c.getType(),c));}
    pool.internClass(changed.get(H));
    var store=new FileDataStore(new File(a[2]));
    try {pool.writeTo(store);} finally {store.close();}
    var merged=new DexBackedDexFile(base.getOpcodes(),Files.readAllBytes(Path.of(a[2])));
    Map<String,ClassDef> after=new HashMap<>(); for(var c:merged.getClasses())after.put(c.getType(),c);
    require(after.size()==originalCount+1,"Unexpected merged class count");
    int untouched=0,unchangedMethods=0;
    for(var c:base.getClasses()) {
      var actual=after.get(c.getType());require(actual!=null,"Missing "+c.getType());
      if(!Set.of(A,W).contains(c.getType())) {
        require(normalized(c).equals(normalized(actual)),"Unrelated class changed: "+c.getType());untouched++;
      } else {
        var beforeMethods=methods(dump(c));var afterMethods=methods(dump(actual));
        for(var entry:beforeMethods.entrySet()) {
          String key=entry.getKey(); require(afterMethods.containsKey(key),"Removed "+key);
          boolean expected=c.getType().equals(A)?EDITED.contains(name(key)):name(key).equals("afterTextChanged");
          if(!expected) {require(entry.getValue().equals(afterMethods.get(key)),"Unrelated method changed: "+key);unchangedMethods++;}
        }
        afterMethods.keySet().removeAll(beforeMethods.keySet());
        var names=new HashSet<String>(); for(var k:afterMethods.keySet())names.add(name(k));
        require(names.equals(c.getType().equals(A)?ADDED:Set.of()),"Unexpected additional methods: "+names);
      }
    }
    require(dump(changed.get(H)).equals(dump(after.get(H))),"Display helper roundtrip changed");
    System.out.println("PASS: "+untouched+" unrelated classes and "+unchangedMethods+" unrelated methods unchanged; 6 accounting helpers and 1 display helper added");
  }
}
