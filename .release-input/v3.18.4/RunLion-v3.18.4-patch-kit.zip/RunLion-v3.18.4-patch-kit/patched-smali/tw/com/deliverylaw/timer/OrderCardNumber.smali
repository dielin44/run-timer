.class public final Ltw/com/deliverylaw/timer/OrderCardNumber;
.super Ljava/lang/Object;
.source "OrderCardNumber.java"

.method public static raw(Ljava/lang/String;)Ljava/lang/String;
    .registers 4
    if-nez p0, :present
    const-string p0, ""
    return-object p0
    :present
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object p0
    const-string v0, "^#\\s*[0-9]+\\s*[,，]\\s*"
    const-string v1, ""
    invoke-virtual {p0, v0, v1}, Ljava/lang/String;->replaceFirst(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    move-result-object p0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object p0
    return-object p0
.end method

.method public static display(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .registers 8
    invoke-static {p2}, Ltw/com/deliverylaw/timer/OrderCardNumber;->raw(Ljava/lang/String;)Ljava/lang/String;
    move-result-object p2
    const-string v0, "熊貓"
    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z
    move-result v0
    if-eqz v0, :plain
    if-eqz p1, :plain
    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;
    move-result-object p1
    const-string v0, "#?\\s*[0-9]+"
    invoke-virtual {p1, v0}, Ljava/lang/String;->matches(Ljava/lang/String;)Z
    move-result v0
    if-eqz v0, :plain
    const-string v0, "[^0-9]"
    const-string v1, ""
    invoke-virtual {p1, v0, v1}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    move-result-object p1
    new-instance v0, Ljava/lang/StringBuilder;
    const-string v1, "#"
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z
    move-result v1
    if-nez v1, :complete
    const-string v1, "，"
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    :complete
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object p2
    :plain
    return-object p2
.end method
